# Goethe B2 · Daily-sheet generator

**How to use this kit.** Give any capable AI these four parts together, then write one line such as *"Build Day 4."* or *"Build Days 2–7, one file per day."*

| File | What it is |
| --- | --- |
| `01_generator_prompt.md` | This file: the instructions. |
| `02_toolkit.md` | The toolkit (main tab + Wortschatz tab). The source of all content. Never edit it. |
| `03_speech_log.md` | Seven speeches by the learner, English and German, with feedback. The source of his style. |
| `daily_sheets/` | Every sheet built so far (`day_01.md`, …). The newest one is the format reference. |

If you are doing a day on a date other than the one in the calendar (section 4), say so in your request: *"Build Day 9, I'm doing it on Tue 27 Oct."*

---

## 1. Your job

You are building **one printable study sheet for one day** (or the merged sheet the calendar names) for a learner preparing for the Goethe-Zertifikat B2. You work from the four inputs above and nothing else.

Output: **one Markdown file per day**, named `day_NN.md` (`day_13-14.md` for a merged sheet). If you cannot create files, return the sheet as one Markdown code block he can save under that name. Return nothing else except, at most, one line naming anything you could not find in the inputs.

Read in this order before writing: this prompt in full → the newest sheet in `daily_sheets/` → the toolkit sections the calendar row points to → the speech the calendar row names.

## 2. The learner

- **Thejus.** Exam: Goethe-Zertifikat B2, **Thursday 10 December 2026**. He prepares the Schreiben and Sprechen modules here; each module is graded on its own and needs 60 of 100 points, so Sprechen must be passed by itself.
- **Spoken German is his weakest skill.** Every sheet makes him speak, out loud, more than once.
- He studies **3 hours a day** from a printed sheet. Hören and Lesen happen outside these 3 hours (YouTube with AI questions, active text analysis); do not plan them.
- Instructions are in **English**, everything he learns is in **German**.
- **Keep his professional background out** (PhD, research, modelling). He asked for this. In the toolkit's personal anchors (§12), use only the everyday ones.

## 3. Rules every sheet follows

1. **Self-contained.** Everything he needs is printed on the sheet: frames, word lists, grammar rules, model texts, the speech he will retell, AI prompts, answers. Never write "see section 6" or "look it up in the toolkit". A short *Built from* line at the very end records your sources; it is for you, not for him.
2. **Answers inline**, hidden in `<details><summary>Answers</summary> … </details>` blocks (with a blank line after the summary line), directly under each exercise.
3. **Every palace is labelled with its exam part**, every time it is named: *Palace A · Schreiben Teil 1 (forum post)*, *Palace B · Schreiben Teil 2 (formal email)*, *Palace C · Sprechen Teil 1 (talk)*, *Palace D · Sprechen Teil 2 (discussion)*. Every frame states which exam part(s) it serves.
4. **Frames come from the style frame bank** (section 8), word for word. Never invent a new frame and never reword one. Once a frame has appeared on a sheet, it is fixed; later sheets copy it exactly.
5. **Vocabulary and grammar come from the toolkit unchanged.** Copy the day's word batch(es) from the Wortschatz tab with every row, and the day's grammar point from toolkit §13 in full.
6. **His style shapes frames, model texts and speaking tasks** (section 7). Exam requirements still win: if a task point or a Vortrag card demands something his pattern lacks (several alternatives, a verdict, a question to his partner), the sheet trains it.
7. **German must be correct B2.** Check every German sentence you write: verb position, case after prepositions, adjective endings, separable verbs, commas before subordinate clauses and zu-infinitives. Prefer sentences from the toolkit and the speech log. If a sentence of your own is doubtful, write a simpler one.
8. **Gender colours** for every noun image: der = blue and frozen in ice, die = red and burning, das = green and overgrown with grass, plural die = grey and multiplied into a crowd.
9. Blocks add up to exactly 3 hours, with clock times on every block.
10. No emoji. Plain, short English sentences. Checkboxes `- [ ]` for every task he ticks off.

## 4. The calendar

He started late, so the sheets catch up with the toolkit's 58-day plan (toolkit §4) by **merging three pairs of plan days** and trimming their production tasks. From Day 19 (Sun 1 Nov) every sheet is the plan day of the same number, on the plan's date.

**Sheets 1 to 19**

| Sheet | Date | Block 3: frame (palace · exam part) | Block 4: grammar | Block 2: words | Block 5 production (50 min) | Speech to retell |
| --- | --- | --- | --- | --- | --- | --- |
| Day 1 | Sa 17.10. | Palace A · Schreiben T1, locus 1 front door: E-1 to E-4, H-S, H-V | G1 | B1-Check A, W01 | Speaking 50 min | 2 Homeoffice |
| Day 2 | So 18.10. | Palace A · Schreiben T1, locus 2 coat rack: M-1 to M-5 | G1 drills (new items) | B1-Check B, W02 | One opinion sentence each for F8–F12, one per M-variant (20 min) + speaking (30 min) | 1 Umweltschutz |
| Day 3 | Mo 19.10. | Palace A, locus 3 kitchen: G-1 to G-4 | G2 | W03 | Gründe paragraph for F8 and F9 (20 min) + speaking (30 min) | 6 Online-Lernen |
| Day 4 | Di 20.10. | Palace A, locus 4 dining table: V-1 to V-5 | G3 | W04 | Pro and contra paragraph for F10 and F11 (25 min) + speaking (25 min) | 3 Digitale Medien |
| Day 5 | Mi 21.10. | Palace A, locus 5 window: A-1 to A-5 | G4 | W05 | Alternatives paragraph for F8 and F18 (20 min) + speaking (30 min) | 5 Wohnen |
| Day 6 | Do 22.10. | Palace A, locus 6 bookshelf: the X table | G5 | W06 | Rebuild Musterbeitrag F1 from memory **with his frames**, then compare (25 min) + speaking (25 min) | 4 Gesund leben |
| Day 7 | Fr 23.10. | Palace A, locus 7 bed: S-1 to S-3; walk Palace A twice | G6 | W07 | Timed Teil 1: F7, 50 min, no help | 7 Tourismus (in Block 6) |
| Day 8 | Sa 24.10. | Palace B · Schreiben T2, loci 1–2: Anrede, Anlass | G7 | W08 | Timed Teil 1: F8, 50 min | 2 Homeoffice (in Block 6) |
| Day 9 | So 25.10. | Palace B, locus 3: Situation, Entschuldigung | G12 | W09 | Read Musternachrichten N1 and N2 aloud and mark the frame (15 min) + speaking (35 min) | 1 Umweltschutz |
| Day 10 | Mo 26.10. | Palace B, locus 4: Verständnis zeigen, bitten | G8 | W10 | Timed Teil 2: N7, 25 min + speaking (25 min) | 6 Online-Lernen |
| Day 11 | Di 27.10. | Palace B, locus 5: Vorschlag, Angebot | G10 | W11 | Timed Teil 2: N8, 25 min + speaking (25 min) | 3 Digitale Medien |
| Day 12 | Mi 28.10. | Palace B, locus 6: Frage, Schluss, Gruß; walk Palace B | G11 | W12 | Timed Teil 2: N9, 25 min + speaking (25 min). Rebuilding N1 is dropped. | 5 Wohnen |
| **Day 13–14** | Do 29.10. | Walk Palaces A and B aloud once each; write every E, M and S variant from memory | G9 + G16 (7 + 3 items) | W13 | Timed Teil 1: F10, 50 min. Block 6: grade it and list your five most frequent error types. The full Schreiben F9 + N10 is dropped. | none |
| **Day 15–16** | Fr 30.10. | Palace C · Sprechen T1, loci 1–3: Einleitung, Alternativen, eine Möglichkeit genauer | G13 (with drills) | W15 | Shadow Mustervortrag V1 three times, then give it from six keyword lines and record (50 min). F11 is dropped. | (Vortrag instead) |
| **Day 17–18** | Sa 31.10. | Palace C, loci 4–6: Vor- und Nachteile + Bewertung, Schluss, Fragen; walk Palace C | G15 | W17 | Timed Teil 2: N11, 25 min + Vortrag *Wohnformen* with two AI questions (25 min). The *Verkehrsmittel* talk is dropped. | (Vortrag instead) |
| Day 19 | So 01.11. | Palace D · Sprechen T2, stations 1–4 | G17 | W19 | Vortrag *Weiterbildung* from keywords + Diskussion D1 | (plan) |

**Items moved by the merges.** W14 → Day 28 (Di 10.11., which has no batch). W16 → Day 38 (Fr 20.11.). W18 → Day 39 (Sa 21.11.). G14 Partizipien → Day 26, whose grammar becomes *G14 Partizipien + review G13, G15*.

**From Day 19 on:** take the row for that day from toolkit §4 and apply sections 5–9 of this prompt.

**If he falls behind again.** Never double up. Merge the next free pair from this list, keep one word batch (move the other to the next day without a batch), keep the more important grammar point, and keep one production task: **27+28, 44+45, 47+48, 54+55.** Never merge a mock day (35, 42, 46, 50, 53).

## 5. The sheet skeleton

Copy this structure exactly. `day_01.md` shows it filled in.

```
# Day N · <Weekday dd.mm.yyyy> · <one-word type: Frame day / Writing day / Speaking day / Mock day / Catch-up day>

| Day | Date | Memorise | Grammar | Words | Produce | Done |
| --- | --- | --- | --- | --- | --- | --- |
| N | <Wd dd.mm.> | <Palace X · exam part, locus: module codes> | <G-point> | <batches> | <one line> | Open |

> **Slip rule:** Missed a day? Do not double up. Do this sheet the next day and tell the generator the new date; it merges two later days to catch up.
>
> <one or two notes for today only, e.g. a baseline task, a Sunday task>

---

## Block 1 · Review · 0:00–0:20
## Block 2 · New words · 0:20–0:45
## Block 3 · Frame: <module> · 0:45–1:15 · <Palace X · exam part, locus>
## Block 4 · Grammar: <G-point> · 1:15–1:35
**Break · 1:35–1:45** — away from screens.
## Block 5 · <Production type> · 1:45–2:35
## Block 6 · Correction and Aussprache · 2:35–3:00

---

**Tomorrow, Day N+1 (<Wd dd.mm.>):** <frame> · <grammar> · <words> · <production>. Review due: <list>.

<sub>Built from: <toolkit sections, Wortschatz batches, speech-log sections, frame-bank codes></sub>
```

Separate blocks with `---`. Inside each block give a time split in minutes when it has more than one step.

## 6. Block by block

### Block 1 · Review (20 min)

- **Words due today.** Each batch is reviewed 1, 3, 7, 14 and 30 days after the date he learned it, counted on the real dates in section 4. Example: batches learned Sa 17.10. are due So 18.10., Di 20.10., Sa 24.10., Sa 31.10., Mo 16.11. List the batches due by name. He runs them in Anki or a five-compartment paper box; a card moves forward only when he recalls it instantly.
- **Palace walk.** Walk every locus learned so far aloud, once, saying each frame. Print the rows of the loci he walks (locus, module, frame text) so he can check himself without looking anything up. Recite each new palace after 1, 3 and 7 days, then once a week.
- On Day 1 this block is the palace setup instead (see `day_01.md`).

### Block 2 · New words (25 min)

- Copy the day's batch from the Wortschatz tab: heading, instruction line, the full table, every row. B1-Check batches get a tick column `✓` with `[ ]`. The only change allowed: the tab's `–` in the plural column becomes `kein Pl.`, so the sheet reads on its own.
- Below the tables write `Rows copied: <batch> n of n`, checked against the tab.
- Tasks: read each word aloud with its article, build one gender-coloured image, cover the German and recall it from the English, then write **and say aloud** one sentence each with the five hardest words.

### Block 3 · Frame (30 min) — the heart of the sheet

Use the frame bank (section 8) for the module the calendar names.

1. **Locus box:** locus name, palace with exam part, the words the image holds, the image (from the bank).
2. **Frame table:** code · when to use it · the frame · grammar to watch · which of his speeches it comes from. Add one line under the table naming the exam part(s) each frame serves.
3. **The frames filled in:** one worked example per frame, using the example in the bank.
4. **Say it first** (his speaking is weakest): read each frame aloud 3 times → say each one with a new topic, without looking, and record on the phone. Give one practice topic per frame, taken from the toolkit's task lists (F7–F18, N7–N14, Vortrag topic bank, D1–D20), with a model answer in an Answers block.
5. **Then write:** all frames from memory, correct them against the table, write them again.
6. **Cloze:** every frame with 2–5 key words blanked, answers in an Answers block.

Suggested split: 5 min read aloud + images · 10 min say with new topics · 10 min write · 5 min cloze.

For Palace B (formal email) the frames are the toolkit's own (§5 Palace B and §8 modules), unchanged; his style does not apply to the email register.

### Block 4 · Grammar (20 min)

- Copy the toolkit §13 point in full: table, bullet rules, the ✗ → ✓ error line.
- Then **10 transformations** written for this sheet, on everyday exam topics (work, environment, housing, media, health, travel, education). At least two of them should use sentences from today's frames or his speeches.
- Answers block: each answer plus the rule line it follows.
- Last task: *Checked; every miss copied into the error log with Type = <grammar type>.*
- On "drills" days (G1 drills, G13 drills) write 10 new items; never repeat earlier items.

### Block 5 · Production (50 min)

The calendar gives the split for Days 1–19. From Day 19 on, apply this table to the plan's *Produce* entry:

| Plan's task | Block 5 | Block 6 |
| --- | --- | --- |
| Copy a model text by hand | Read the model aloud and mark its frame (≤15 min); the rest is speaking practice | Speaking feedback, error log, shadowing |
| Rebuild a model text from memory | Rebuild it with his frames (25 min) + speaking practice (25 min) | Compare with the model; speaking feedback |
| Short written pieces (sentences, one or two paragraphs) | The pieces, trimmed to fit 20–25 min + speaking practice (25–30 min) | Grade the pieces with the grader prompt |
| Timed Teil 1 (50 min) | The timed task, nothing else | AI grading (10) + 10-min retell of the rotation speech + 5-min shadowing |
| Timed Teil 2 (25 min) | The timed task + 25 min speaking (the plan's Vortrag/Diskussion, or the rotation speech) | Grade both |
| Vortrag and/or Diskussion | All 50 min speaking, recorded | Voice-AI feedback |
| Full Schreiben (75 min) | Blocks 5 and 6 together become the 75-min simulation; grading moves to the next day's Block 6 | — |
| Mock day | A short sheet: timings, rules, the scoring table from toolkit §2, then the error-log analysis | — |

**Speaking practice** (whenever Block 5 has it) follows his own material, in this order:

1. Print the **German version** of the day's speech from the speech log in full, inside the sheet.
2. Read it aloud twice: slowly, then at normal speed. Mark his five steps in the margin.
3. Write a keyword card of **five lines**, one per step (model card in an Answers block).
4. Retell from the card only, recorded. Open with today's frame (or a frame learned earlier), give a clear opinion within the first three sentences, use one example only, **stop at 3:30**.
5. Listen back; note the three biggest problems in the error log.
6. Retell again with a different opening frame, recorded.

From Day 15 on, the exam formats take over: Vortrag topics from the toolkit topic bank and discussions D1–D20, as the plan says. The speeches then serve only as 10-minute warm-ups.

**Model texts in his style.** When a sheet needs a model forum post (a rebuild, a comparison after a timed task), take the toolkit model's content sentences, replace each bold frame sentence with the matching frame from section 8, keep 170–190 words, and print the frame in bold.

### Block 6 · Correction and Aussprache (25 min)

- **Grading prompts.** Copy the matching prompt from toolkit §15 into a code block and fill in the task line. For speaking, adapt prompt 2 or 3 so it also checks today's frame, e.g. *"Did my opening follow one of these frames: …?"*
- **Error log:** his three worst corrected errors, as `Date | Wrong | Right | Rule | Type`. The log is a notebook page or `error_log.md`.
- **Shadowing, 5 min:** today's frames (worked examples), or the first paragraph of today's speech or model text.
- **Sundays** (18.10., 25.10., 1.11., …): add *Rewrite your five most frequent error types as correct sentences (5 min)*.

### Tomorrow line

Name tomorrow's sheet as the calendar gives it, and list what is due for review tomorrow (words and loci).

## 7. His style

Taken from the speech log. These are the moves that make the sheets sound like him.

**His five steps** (all seven speeches):

1. **Unpack the word:** what the key word means or which feeling it gives him. *Wenn ich das Wort „Umwelt“ höre, denke ich an …* · *Das Wort „Homeoffice“ besteht aus zwei Begriffen …*
2. **Background or cause:** history, origin, why the issue exists. *aufgrund der Corona-Pandemie* · *Hätte man diese Frage in den Achtzigerjahren gestellt, …*
3. **Advantages vs. disadvantages, often split by type of person.** *Für Menschen, die gern …, ist das ideal. Für diejenigen, die lieber …*
4. **One concrete example:** protected areas, the childhood chess book, Hamburg's trees and the Marschlande, Saudi pilgrimage quotas, the weekly team meeting.
5. **"Best of both worlds" conclusion:** a balance, with the state regulating, educating or supporting. *Abschließend lässt sich festhalten, dass …* · *Der Staat sollte dafür sorgen, dass …*

**His recurring ideas** (good material for any topic): balance between two sides · the state must make clear rules · education and awareness, especially for young people · a weekly in-person meeting while others join by video · sustainability: nothing at the cost of the environment.

**His habits, which every sheet corrects:**

| Habit | What the sheet does |
| --- | --- |
| Openings run long and philosophical | Opening = at most two sentences, then a hand-off sentence. |
| The direct question sometimes goes unanswered | A clear opinion within the first three sentences; the coat-rack frames follow the front door directly. |
| Talks run over four minutes | Every retell and Vortrag has a stop time (3:30 for retells, 4:00 for the Vortrag). |
| Several examples dilute one point | One example per point. |
| Risky claims ("many studies show") | Soft claims only: *Manche Studien zeigen …* · *Ich habe den Eindruck, dass …* |

**Keep out:** his professional background; long religious examples in discussions (the Saudi quota stays one sentence); figures he cannot check.

## 8. Style frame bank

This is the only source of frames. Copy codes, frames, images and examples exactly. Palace A carries his whole five-step pattern, so its frames serve **Schreiben Teil 1** and also the matching moves of **Sprechen Teil 1**.

### Palace A · Schreiben Teil 1 (forum post) — the route

The loci are the toolkit's; the words and images are rebuilt for his frames. If he already chose his own loci, keep them.

| Suggested locus | Module (his step) | Words the image holds | Image |
| --- | --- | --- | --- |
| Front door | Einleitung (step 1: unpack the word) | Wenn ich das Wort … höre · besteht aus zwei Wörtern · bleibt ein gemeinsames Wort übrig · Was bedeutet eigentlich …? · wird viel darüber diskutiert | A giant ear is nailed to your door (hören). Say a word to it and the word (das Wort, green, grass growing from its letters) drops onto the doormat and splits in two; the halves walk off in opposite directions, each trailing its own coloured cloud of feelings. One crumb of the word stays lying on the mat, left over (übrig). Above the door a neon question mark flashes: WAS BEDEUTET EIGENTLICH? Behind the door a crowd argues loudly about it (darüber diskutiert). |
| Coat rack | Meinung (answer the question at once) | Meines Erachtens · die Auffassung vertreten · mit gemischten Gefühlen · unter der Voraussetzung, dass · nicht ob, sondern wie | A hat on the rack is embroidered M.E. (Meines Erachtens). You are a travelling salesman (Vertreter) and grab (auf-fassen) a coat labelled AUFFASSUNG. The next coat is half black, half white (gemischte Gefühle). The last coat is chained to its hook and only comes free when you show a ticket stamped VORAUSSETZUNG. A sign above the rack: NICHT OB – SONDERN WIE. |
| Kitchen | Gründe and Hintergrund (step 2: background) | mehrere Gründe: zum einen, zum anderen · Vor dreißig Jahren hätte man … nicht … können · Das liegt daran, dass · aufgrund + Genitiv | Two pots labelled 1 and 2 are full of coffee grounds (Gründe). An old radio from the 1990s crackles on the shelf: it could never have answered your question (hätte nicht … können). A cat lies (liegt) beside the pots; its name tag says DARAN. A sack of flour stands on the floor (Grund) stamped AUFGRUND and drags a tail of "des" and "der" behind it (Genitiv). |
| Dining table | Vor- und Nachteile (step 3: by type of person) | Für Menschen, die … · für diejenigen, die … dagegen · liegen auf der Hand · nicht unterschätzen · aus Sicht + Genitiv | Two guests at the table. One sits happily inside a soap bubble (Menschen, die gern allein arbeiten); the other, diejenigen, groans under a tower of plates. An open hand lies on the tablecloth holding the advantages for all to see (auf der Hand liegen). A tiny lead weight that everyone underestimates tips the table. The boss's glasses lie by the salt (aus Sicht des Arbeitgebers). |
| Window | Lösung and Alternativen (step 5: your solution) | das Beste aus beiden Welten verbinden · Eine sinnvolle Alternative wäre · Statt … ganz zu verbieten · wünschenswert, wenn … würde | Outside, a city and a village float side by side like two globes; you build a bridge and join their best halves (das Beste aus beiden Welten). The road below forks and the second path glows: SINNVOLL. Instead of nailing the window shut (statt … zu verbieten), you fit a turnstile with a counter (regeln). A shooting star (Wunsch) crosses the sky wearing a crown (Würde → würde). |
| Bookshelf | Extra-Leitpunkte (step 4: your example + your recurring ideas) | Ein gutes Beispiel dafür · der Staat ist dafür verantwortlich · aufgeklärt werden · auf Kosten + Genitiv · zur Folge haben | Your childhood chess book glows on the shelf (ein gutes Beispiel). A statue of the state (der Staat, blue and frozen) carries the whole shelf on its back (verantwortlich). A lamp switches on above a child's head (aufgeklärt werden). A fish skeleton hangs from a price tag (auf Kosten der Umwelt). Footprints walk out of one book (zur Folge haben). |
| Bed | Schluss (step 5: balance and the state) | Abschließend lässt sich festhalten · ein Gleichgewicht zwischen … und … · dafür sorgen, dass · Entscheidend ist jedoch | A judge in pyjamas locks the bedroom door (ab-schließen) and holds the verdict tight in both hands (fest-halten). A see-saw balances on the duvet, a city on one end and a village on the other (Gleichgewicht). A nurse tucks you in (dafür sorgen). The judge bangs a gavel: ENTSCHEIDEND. |

### Locus 1 · Front door · Einleitung

Serves **Schreiben Teil 1** (the opening paragraph) and **Sprechen Teil 1** (the lines after your greeting). Not used in Sprechen Teil 2. Rule: at most two sentences of E, then a hand-off.

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| E-1 Ein Wort, ein Gefühl | the topic is one key word | Wenn ich das Wort „…“ höre, denke ich zuerst an … Für mich bedeutet es vor allem, … zu … | wenn-clause first, so the main clause starts with its verb (höre, denke); denken an + Akkusativ; zu-infinitive at the end | 1, 4, 5 |
| E-2 Zwei Wörter | a compound or two-word topic | Der Begriff „…“ besteht aus zwei Wörtern, die bei mir ganz unterschiedliche Gefühle auslösen: Bei „…“ denke ich an …, bei „…“ hingegen an … | bestehen aus + Dativ (Wörtern); relative clause, verb last (auslösen); hingegen in the middle | 2, 3 |
| E-3 Der gemeinsame Kern | an "X or Y" topic | Wenn man „…“ und „…“ nebeneinanderstellt, bleibt ein gemeinsames Wort übrig: „…“. Für mich bedeutet …, … zu … | nebeneinander\|stellen and übrig\|bleiben: joined in the wenn-clause, split in the main clause | 5, 6 |
| E-4 Die Frage | "curse or blessing?" or "why do people do X?" topics | Was bedeutet eigentlich „…“? Warum …? Mir fallen dafür vor allem drei Gründe ein: … | ein\|fallen + Dativ: *mir fallen drei Gründe ein*, the verb agrees with Gründe; with one reason: *mir fällt ein Grund ein* | 7 |
| H-S Übergang (Schreiben) | closes every forum-post Einleitung | Weil dieses Thema so viele Menschen betrifft, wird zurzeit viel darüber diskutiert. Im Folgenden möchte ich meine Sichtweise schildern. | weil-clause first (verb, comma, verb); passive without a subject: *wird … diskutiert*; darüber | toolkit E-A, E-C |
| H-V Übergang (Vortrag) | follows E in the talk | Zuerst stelle ich verschiedene Möglichkeiten vor. Danach gehe ich auf eine davon genauer ein. Anschließend nenne ich Vor- und Nachteile und bewerte sie, und zum Schluss sage ich, wie ich persönlich dazu stehe. *(Follow the order printed on the card.)* | vor\|stellen, ein\|gehen auf: prefix at the end; indirect question *wie ich dazu stehe* | toolkit §10 |

Worked examples:

- **E-1 · Umwelt:** Wenn ich das Wort „Umwelt“ höre, denke ich zuerst an ein Gefühl von Sicherheit. Für mich bedeutet es vor allem, im Einklang mit der Natur und den Menschen um mich herum zu leben.
- **E-2 · Homeoffice:** Der Begriff „Homeoffice“ besteht aus zwei Wörtern, die bei mir ganz unterschiedliche Gefühle auslösen: Bei „Home“ denke ich an Familie, Sicherheit und Freizeit, bei „Office“ hingegen an Konzentration, Pflichten und den eigenen Lebensunterhalt.
- **E-3 · Stadt oder Land:** Wenn man „Wohnen in der Stadt“ und „Wohnen auf dem Land“ nebeneinanderstellt, bleibt ein gemeinsames Wort übrig: „Wohnen“. Für mich bedeutet Wohnen, glücklich und gesund zu leben und seinen Pflichten nachzugehen.
- **E-4 · Tourismus:** Was bedeutet eigentlich „Tourismus“? Warum reist jemand weit weg von seiner Heimat? Mir fallen dafür vor allem drei Gründe ein: Man möchte seinen Horizont erweitern, andere Kulturen kennenlernen oder sich einfach erholen.
- **The talk opening:** Guten Tag! In meinem Vortrag geht es um das Thema „…“. + E (two sentences) + H-V.

### Locus 2 · Coat rack · Meinung

Serves **Schreiben Teil 1** (the opinion point), **Sprechen Teil 1** (the verdict) and **Sprechen Teil 2** (station 2). Rule: it always comes straight after the Einleitung.

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| M-1 Meines Erachtens | any topic | Meines Erachtens … | position 1, so the verb comes next | 2–7 |
| M-2 Auffassung | a formal tone | Ich vertrete die Auffassung, dass … | dass: verb last | toolkit M-A |
| M-3 Gemischte Gefühle | you see both sides | Ich sehe das Thema mit gemischten Gefühlen: Einerseits …, andererseits … | the verb comes straight after einerseits / andererseits | 1, 3 |
| M-4 Nur unter einer Bedingung | a conditional yes | Grundsätzlich halte ich [Akkusativ] für sinnvoll, allerdings nur unter der Voraussetzung, dass … | halten für + Akkusativ | toolkit M-D |
| M-5 Nicht ob, sondern wie | "should X be banned?" | Für mich ist die Frage nicht, ob …, sondern wie … | indirect questions: verb last; nicht …, sondern | 7 |

Worked examples:

- **M-1 · Umweltschutz:** Meines Erachtens braucht es beides, aber der Staat muss vorangehen.
- **M-2 · Homeoffice:** Ich vertrete die Auffassung, dass Homeoffice an einigen Tagen pro Woche für alle möglich sein sollte.
- **M-3 · Digitale Medien:** Ich sehe das Thema mit gemischten Gefühlen: Einerseits eröffnen digitale Medien enorme Chancen, andererseits sind Kinder kaum geschützt.
- **M-4 · Online-Lernen:** Grundsätzlich halte ich Online-Lernen für sinnvoll, allerdings nur unter der Voraussetzung, dass der persönliche Austausch nicht verloren geht.
- **M-5 · Tourismus:** Für mich ist die Frage nicht, ob wir Tourismus brauchen, sondern wie wir ihn regeln.

### Locus 3 · Kitchen · Gründe and Hintergrund

Serves **Schreiben Teil 1** (reasons), **Sprechen Teil 1** (why a form is common) and **Sprechen Teil 2** (station 3).

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| G-1 Mehrere Gründe | listing reasons | Dafür, dass …, gibt es mehrere Gründe. Zum einen … Zum anderen … | the verb comes straight after Zum einen / Zum anderen | 2; toolkit G-A |
| G-2 Früher und heute | a new development | Vor dreißig Jahren hätte man diese Frage gar nicht stellen können, denn … gab es damals noch nicht. | Konjunktiv II past with a modal: *hätte … stellen können*, two infinitives at the end | 6 |
| G-3 Ursache | explaining a cause | Das liegt vor allem daran, dass … Hinzu kommt, dass … | liegen an → daran; dass: verb last | 2, 3, 5, 6, 7 |
| G-4 Auslöser | one event changed things | Vor allem aufgrund [Genitiv] hat sich … stark verändert. | aufgrund + Genitiv; *sich verändern* takes haben | 2 |

Worked examples:

- **G-1 · Homeoffice:** Dafür, dass viele Menschen lieber zu Hause arbeiten, gibt es mehrere Gründe. Zum einen sparen sie sich den Arbeitsweg. Zum anderen können sie sich ihre Zeit freier einteilen.
- **G-2 · Online-Lernen:** Vor dreißig Jahren hätte man diese Frage gar nicht stellen können, denn Online-Unterricht gab es damals noch nicht.
- **G-3 · Tourismus:** Dass die Einheimischen protestieren, liegt vor allem daran, dass die Mieten steigen. Hinzu kommt, dass die Menschenmassen viel Lärm verursachen.
- **G-4 · Homeoffice:** Vor allem aufgrund der Corona-Pandemie hat sich unsere Arbeitswelt stark verändert.

### Locus 4 · Dining table · Vor- und Nachteile

Serves **Schreiben Teil 1**, **Sprechen Teil 1** (pros and cons) and **Sprechen Teil 2** (arguments).

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| V-1 Je nach Typ | it depends on the kind of person | Für Menschen, die gern …, ist … ideal. Für diejenigen, die lieber …, kann es dagegen ziemlich belastend sein. | relative clauses after *Menschen* and *diejenigen*: verb last | 2, 5 |
| V-2 Auf der Hand | an obvious upside, a real downside | Die Vorteile liegen auf der Hand: … Allerdings darf man die Nachteile nicht unterschätzen: … | auf der Hand liegen; Allerdings → verb next | 1, 7 |
| V-3 Zwar … aber | a short contrast | Zwar …, aber … | the verb comes straight after Zwar; aber in position 0 | toolkit V-C |
| V-4 Aus zwei Sichten | two parties (employer and staff, tourists and locals) | Aus Sicht [Genitiv] …, aus Sicht [Genitiv] hingegen … | Genitiv: aus Sicht des Arbeitgebers / der Beschäftigten | 2 |
| V-5 Vorteile der Alternativen | the task point "Vorteile dieser Möglichkeiten" | Diese Alternativen haben gleich mehrere Vorteile: Sie sind nicht nur …, sondern auch … | nicht nur …, sondern auch | toolkit V-E |

Worked examples:

- **V-1 · Homeoffice:** Für Menschen, die gern ungestört arbeiten, ist das Homeoffice ideal. Für diejenigen, die sich lieber persönlich austauschen, kann es dagegen ziemlich belastend sein.
- **V-2 · Tourismus:** Die Vorteile liegen auf der Hand: Der Tourismus bringt viel Geld in die Stadt. Allerdings darf man die Nachteile nicht unterschätzen: Viele Einheimische können sich die Mieten kaum noch leisten.
- **V-3 · Online-Lernen:** Zwar ist man online flexibler, aber der persönliche Austausch fehlt.
- **V-4 · Homeoffice:** Aus Sicht des Arbeitgebers lässt sich viel Miete sparen, aus Sicht der Beschäftigten hingegen fehlt oft der Kontakt zum Team.
- **V-5 · Einkaufen:** Diese Alternativen haben gleich mehrere Vorteile: Sie sind nicht nur günstiger, sondern auch besser für die Umwelt.

### Locus 5 · Window · Lösung and Alternativen

Serves **Schreiben Teil 1** (other possibilities, proposals), **Sprechen Teil 1** (your choice at the end) and **Sprechen Teil 2** (a compromise).

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| A-1 Das Beste aus beiden Welten | your own solution | Meines Erachtens liegt die Lösung darin, das Beste aus beiden Welten zu verbinden: … | liegen in → darin + zu-infinitive | 5, 6, 7 |
| A-2 Sinnvolle Alternative | a concrete proposal | Eine sinnvolle Alternative wäre zum Beispiel, … zu … | Konjunktiv II *wäre*; zu-infinitive at the end | 2, 6 |
| A-3 Regeln statt Verbote | "should X be banned?" | Statt … ganz zu verbieten, sollte man … klar regeln. | statt … zu + infinitive; then the main clause starts with its verb | 7 |
| A-4 Wunsch | a wish for change | Es wäre wünschenswert, wenn … würde. | *würde* at the very end | toolkit A-C |
| A-5 Andere Möglichkeiten | the task point "andere Möglichkeiten" | Es gibt durchaus andere Möglichkeiten, … zu …: Man kann zum Beispiel … Ebenso denkbar wäre es, … zu … | comma before the zu-infinitive | toolkit A-E |

Worked examples:

- **A-1 · Stadt oder Land:** Meines Erachtens liegt die Lösung darin, das Beste aus beiden Welten zu verbinden: Die Städte brauchen mehr Natur, und die Dörfer brauchen schnelles Internet.
- **A-2 · Homeoffice:** Eine sinnvolle Alternative wäre zum Beispiel, sich einmal pro Woche persönlich zu treffen, während die anderen per Videokonferenz teilnehmen.
- **A-3 · Tourismus:** Statt den Tourismus ganz zu verbieten, sollte man ihn klar regeln, zum Beispiel durch Quoten.
- **A-4 · Online-Lernen:** Es wäre wünschenswert, wenn der Staat Lehrkräfte für den Online-Unterricht gezielt schulen würde.
- **A-5 · Stress im Beruf:** Es gibt durchaus andere Möglichkeiten, Stress im Beruf zu reduzieren: Man kann zum Beispiel feste Pausen einplanen. Ebenso denkbar wäre es, flexible Arbeitszeiten einzuführen.

### Locus 6 · Bookshelf · Extra-Leitpunkte

Serves **Schreiben Teil 1** when a task point asks for something beyond opinion, reasons, pros and cons, or alternatives; also gives him content for **Sprechen**. Pick the row that matches the task wording.

| Code | The task asks for | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| X-1 | an example, your own experience | Ein gutes Beispiel dafür ist … · Ich habe selbst erlebt, dass … | da-word *dafür*; Perfekt | 3 |
| X-2 | the role of the state, responsibility | Meines Erachtens ist der Staat dafür verantwortlich, … zu … Er sollte klare Regeln schaffen. | verantwortlich für → dafür + zu-infinitive | 3, 4, 6, 7 |
| X-3 | education, protecting young people | Vor allem junge Menschen müssen über die Risiken aufgeklärt werden. | passive with a modal verb | 3 |
| X-4 | environment, sustainability | … darf nicht auf Kosten [Genitiv] gehen. | auf Kosten + Genitiv | 4 |
| X-5 | consequences, effects | Diese Entwicklung hat zur Folge, dass … Das wirkt sich vor allem auf [Akkusativ] aus. | zur Folge haben; sich aus\|wirken auf | toolkit |
| X-6 | the future | Ich gehe davon aus, dass … in Zukunft … wird. | davon aus\|gehen, dass; werden + infinitive | toolkit |
| X-7 | the situation in your country | In meinem Heimatland sieht die Situation etwas anders aus: Dort … | aus\|sehen | toolkit |
| X-8 | conditions | Das funktioniert allerdings nur, wenn … | wenn: verb last | toolkit |

Worked examples:

- **X-1 · Digitale Medien:** Ein gutes Beispiel dafür ist mein eigenes Erlebnis: Als Kind habe ich mir sehnlich ein Schachbuch gewünscht, aber es war nirgends erhältlich.
- **X-2 · Digitale Medien:** Meines Erachtens ist der Staat dafür verantwortlich, Kinder im Internet besser zu schützen. Er sollte klare Regeln schaffen.
- **X-3 · Digitale Medien:** Vor allem junge Menschen müssen über die Risiken aufgeklärt werden.
- **X-4 · Gesund leben:** Gesundes Leben darf nicht auf Kosten der Umwelt gehen.
- **X-5 · Tourismus:** Diese Entwicklung hat zur Folge, dass die Mieten steigen. Das wirkt sich vor allem auf junge Familien aus.
- **X-6 · Online-Lernen:** Ich gehe davon aus, dass sich Online-Lernen in Zukunft weiter verbreiten wird.
- **X-7 · Wohnen:** In meinem Heimatland sieht die Situation etwas anders aus: Dort leben viele Familien mit mehreren Generationen zusammen.
- **X-8 · Homeoffice:** Das funktioniert allerdings nur, wenn IT-Probleme schnell gelöst werden.

### Locus 7 · Bed · Schluss

Serves **Schreiben Teil 1** (the closing paragraph), **Sprechen Teil 1** (the end of the talk) and **Sprechen Teil 2** (station 12, where he must also say *dafür* or *dagegen*).

| Code | Use it when | Frame | Grammar to watch | From speech |
| --- | --- | --- | --- | --- |
| S-1 Festhalten und der Staat | his default ending | Abschließend lässt sich festhalten, dass … Der Staat sollte deshalb dafür sorgen, dass … | sich lassen + infinitive; dafür sorgen, dass | all 7 |
| S-2 Gleichgewicht | a balance between two sides | Alles in allem bin ich davon überzeugt, dass wir ein Gleichgewicht zwischen … und … brauchen. Entscheidend ist jedoch, dass … | überzeugt sein von → davon; zwischen + Dativ | 2, 3 |
| S-3 Regeln statt Verbote | "ban?" topics | Zusammenfassend lässt sich sagen, dass … nicht ganz verboten werden sollte. Wir brauchen aber klare Regeln, damit … | passive with a modal in a dass-clause: *verboten werden sollte*; damit: verb last | 7 |

Worked examples:

- **S-1 · Tourismus:** Abschließend lässt sich festhalten, dass Tourismus unseren Horizont erweitert. Der Staat sollte deshalb dafür sorgen, dass Einheimische und Umwelt nicht darunter leiden.
- **S-2 · Homeoffice:** Alles in allem bin ich davon überzeugt, dass wir ein Gleichgewicht zwischen Flexibilität und Produktivität brauchen. Entscheidend ist jedoch, dass niemand den Kontakt zum Team verliert.
- **S-3 · Handyverbot:** Zusammenfassend lässt sich sagen, dass Smartphones an Schulen nicht ganz verboten werden sollten. Wir brauchen aber klare Regeln, damit sich die Kinder im Unterricht konzentrieren können.
- **Sprechen Teil 2 ending:** Zusammenfassend bin ich eher dafür, weil …, aber nur, wenn der Staat klare Regeln schafft.

### Palace B · Schreiben Teil 2 (formal email)

Use the toolkit's Palace B table (§5) and the §8 modules exactly as they stand: loci, images, frames, register traps. His argumentative style does not belong in a formal email. The one place it fits is the proposal: *Alternativ könnte ich …* is his "best of both worlds" in office form.

### Palace C · Sprechen Teil 1 (talk)

Use the toolkit's Palace C route (§5) and Vortrag script (§10), with his frames inserted where they match. Add one link image at each changed locus.

| Locus | Exam move | What he says | Link image to add |
| --- | --- | --- | --- |
| Hall door | Einleitung | *Guten Tag! In meinem Vortrag geht es um das Thema „…“.* + one E-frame (two sentences at most) + H-V in the card's order | The giant ear from Palace A's front door hangs beside the four signposts. |
| Three stage steps | Mehrere Alternativen | Toolkit frames unchanged: *Die erste Möglichkeit ist … Eine zweite, sehr verbreitete Möglichkeit ist … Und schließlich gibt es noch …* (his steps lack this move, so drill it hard) | — |
| Lectern | Eine Möglichkeit genauer | *Nun möchte ich genauer auf … eingehen. Diese Möglichkeit zeichnet sich vor allem dadurch aus, dass …* + **one** concrete example (X-1) | The chess book lies open on the lectern. |
| Scales on stage | Vor- und Nachteile, Bewertung | V-1, V-2 or V-4 + *Wenn ich die Vor- und Nachteile gegeneinander abwäge, komme ich zu dem Ergebnis, dass …* | The two dinner guests (bubble and plate tower) sit in the scale pans. |
| Curtain | Schluss | A-1 or S-1 in one sentence + *Ich persönlich würde mich für … entscheiden, weil … Damit komme ich zum Ende meines Vortrags. Vielen Dank für Ihre Aufmerksamkeit!* | The bridge between two worlds is painted on the curtain. |
| Audience | Fragen | Toolkit frames unchanged (answering and asking, 12 points) | — |

Exam rules to print on Palace C sheets: follow the bullet order on the card; never skip the verdict; aim for 3:45–4:00; ask your partner one question.

### Palace D · Sprechen Teil 2 (discussion)

Use the toolkit's 12 stations, R-A-F turn, du/Sie table and Argument-Uhr (§5, §11) unchanged. His style enters through the content of the **A** in R-A-F (his recurring ideas in section 7) and through his closing line at station 12 (S-frames above). This part is his biggest gap: Palace D sheets must give at least 25 minutes of live discussion practice with the voice-AI prompt from toolkit §15, and drill reacting phrases (stations 6–9) aloud, not only on paper.

## 9. Speech rotation

| Sheet | Speech (from the speech log) | Why that one |
| --- | --- | --- |
| Day 1 | 2 Homeoffice | Uses E-2; replaces the old hand-copying of F1, also about Homeoffice. |
| Day 2 | 1 Umweltschutz | Its direct question was never answered: practise the coat rack. |
| Day 3 | 6 Online-Lernen | Its "the 80s could not answer this" line is G-2. |
| Day 4 | 3 Digitale Medien | Pros and cons split by generation; the chess-book example. |
| Day 5 | 5 Wohnen | Best of both worlds; one example only (Hamburg, not New York). |
| Day 6 | 4 Gesund leben | The state, sustainability, *auf Kosten der Umwelt*. |
| Day 7 | 7 Tourismus | Regulate instead of ban; the closing frames. |
| Days 8–12 | 2, 1, 6, 3, 5 again | Second round: each time open with a different E-frame than in round one. |
| Day 15 on | Vortrag topics and discussions from the plan | The speeches become 10-minute warm-ups. |

Always print the German version in full on the sheet. Never print the English original; he speaks from German.

## 10. Checklist before you return the sheet

- [ ] The calendar row (section 4) is followed exactly: frame, grammar, words, production, speech.
- [ ] Every palace mention carries its exam part; every frame says which exam part(s) it serves.
- [ ] Frames are copied from section 8 word for word, and match earlier sheets.
- [ ] Word batches are complete, with the `Rows copied` line; the grammar point is complete.
- [ ] Every exercise has an Answers block; no task needs another file.
- [ ] Every German sentence has been checked for verb position, case, endings and commas.
- [ ] Clock times run 0:00–3:00 without gaps; the split inside each block adds up.
- [ ] He speaks aloud in Block 1, Block 3 and Block 5 (or Block 6 on timed-writing days).
- [ ] The Tomorrow line and the review list are right for the real dates.
- [ ] Nothing about his professional background.
