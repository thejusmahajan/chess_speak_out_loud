> Exported on 17 Oct 2026 from the Claude doc "Goethe B2 – Mein Werkzeugkasten (Schreiben & Sprechen)" (https://claude.ai/code/artifact/66a7c626-a5ab-4bef-a4ca-379afcb0a324). Two tabs in one file: the main toolkit first, then the Wortschatz tab. This file is the unchanged source.

# Goethe B2 – Mein Werkzeugkasten (Schreiben & Sprechen)

Oct 13, 2026 · @Thejus

## 1. Start here: memorise frames, not texts

You memorise **frames**: short, error-free sentence shells for openings, transitions and endings. In the exam you fill them with your own content. In a Forumsbeitrag the frame should be about 60–80 words, and at least 100–110 words must be your own content on the four points.

Why this split matters: Schreiben is scored on Erfüllung, Kohärenz, Wortschatz and Strukturen. Frames win Kohärenz and supply B2 structures. Only real content wins Erfüllung, and an E in Erfüllung makes that whole task worth 0 points.

**The five rules**

1. Every Leitpunkt gets its own paragraph with 2–3 sentences of real content.
2. Put the difficult grammar into the frames you have drilled. Write content sentences you are sure of; accuracy beats ambition there.
3. Rotate the frame variants (A, B, C) so that no two of your texts look identical.
4. In Sprechen, memorise moves and connectors, never whole speeches. A polished speech followed by broken answers to follow-up questions costs you fluency and interaction points.
5. Paraphrase the wording of the task instead of copying it.

**How to use this toolkit:** section 3 is your daily 3-hour routine and section 4 tells you what to do on each date. Sections 5–12 hold what you memorise. Sections 13–14 hold the grammar and the words that make the frames work.

**What I corrected from the AI report.** It got several things right: the E-rule, the debate format of Sprechen Teil 2, notes being allowed, and the value of Nomen-Verb-Verbindungen. These points needed fixing:

| The report said | The official Goethe material shows | What you do |
| --- | --- | --- |
| circa 150 / circa 100 words | **Goethe's online practice set says mindestens 150 / 100; the printed 2025 Modellsatz says circa. Under half the words, the task scores 0** | Treat them as minimums: aim for 170–190 and 110–130 words |
| About 110 memorised words plus 40–60 words of content | Erfüllung A needs all four points treated "inhaltlich und umfänglich angemessen" | Frame about 60–80 words; content at least 100–110 words |
| The discussion should end in a consensus | The card says: "Fassen Sie am Ende zusammen: Sind Sie dafür oder dagegen?" | End by stating your own position; agreement is optional |
| Vortrag: personal experience, home country, comparison | Those are B1 presentation slides. B2 cards ask for several alternatives, one in detail, pros and cons **plus a verdict**, in varying order | Follow the bullet order printed on your card; always evaluate |
| After the Vortrag your partner asks questions | Your partner **and** an examiner ask; you must also ask your partner a question. "Fragen stellen und beantworten" is scored | Learn the 4 universal questions in section 10 |
| Teil 2 scenarios include complaints to a landlord | Goethe describes Teil 2 as "eine formelle Nachricht im beruflichen Kontext" | All models here are work situations |
| "At least one complex connector per paragraph is mandatory" | No such rule; the criterion is linking that is "angemessen" | One or two connectors per paragraph is plenty |
| Templates make you "unangreifbar" and guarantee top marks | Two raters score range and accuracy; nothing is guaranteed | Frames plus simple, correct content |
| "nachdrücklich den Standpunkt vertreten", "Wie Sie sicherlich bereits aus dem Kontext wissen", "mit größter Sorgfalt agieren", "liegt in der Tatsache begründet" | Unidiomatic or very heavy | Replaced with "die Auffassung vertreten", "Wie Sie wissen", "sorgfältiger arbeiten", "liegt darin, dass" |

## 2. The exam at a glance

Schreiben (75 minutes) and Sprechen (15 minutes after 15 minutes of preparation) are each scored out of 100 points, and you pass a module with 60. The points below come from the scoring sheets in Goethe's 2025 Modellsatz.

| Part | What you do | Length and time | Points |
| --- | --- | --- | --- |
| Schreiben Teil 1 | Forumsbeitrag on a social topic: four content points, plus an Einleitung and a Schluss | circa 150 words (online set: at least 150); 50 min suggested | 60: Erfüllung 14, Kohärenz 14, Wortschatz 16, Strukturen 16 |
| Schreiben Teil 2 | Formal message in a work situation to a named person: four points in no fixed order, Anrede and Gruß | circa 100 words (online set: at least 100); 25 min suggested | 40: Erfüllung 10, Kohärenz 10, Wortschatz 10, Strukturen 10 |
| Sprechen, warm-up | About 1 minute of small talk with the examiners | 1 min | Not graded |
| Sprechen Teil 1 | Vortrag on one of two topics. Then your partner and an examiner ask you questions, and you ask your partner a question about their talk | about 4 min per person | 44: Erfüllung 8, Kohärenz 8, Wortschatz 8, Strukturen 8, Fragen/Antworten 12 |
| Sprechen Teil 2 | Debate on a yes/no question with four keyword prompts. Exchange arguments, react, and end by saying whether you are dafür or dagegen | about 5 min together | 40: Erfüllung 10, Interaktion 10, Wortschatz 10, Strukturen 10 |
| Aussprache | Judged across both Sprechen parts | – | 16 |

The biggest single levers are Wortschatz and Strukturen in Schreiben Teil 1 (16 each), Aussprache (16) and the question round after your talk (12). The plan in section 4 trains all four every week.

**Rules that change how you work**

- Two raters score each module independently and the average counts. 60–69 = ausreichend, 70–79 = befriedigend, 80–89 = gut, 90–100 = sehr gut.
- An E in Erfüllung (fewer than half the words, or off-topic) makes that task worth 0 points, however good the German is.
- Erfüllung A means all four points are treated fully. Three points done well and one missing caps you at B.
- Schreiben: you may start with either task. No dictionaries. Write with a blue or black pen; only the answer sheet is graded, so draft on scrap paper only if you leave time to copy.
- Sprechen: you prepare alone for 15 minutes and receive the tasks for both parts. Keyword notes are allowed and you may use them in the room, but you must speak freely.
- Your speaking partner is assigned at random. Agree on du or Sie in the first seconds and keep it; the register is scored.
- Some centres run Lesen, Hören and Schreiben on a laptop with a German keyboard. Check your booking; if it is digital, practise typing ä, ö, ü and ß.
- Goethe's own B2 sample answers contain uncorrected mistakes. B2 rewards range, clarity and linking; perfection is not required.

**What the official tasks look like**

- Schreiben Teil 1: four points such as your opinion on X, reasons why X is so common, other possibilities, and the advantages of those possibilities. Model F6 in section 7 follows exactly this pattern.
- Schreiben Teil 2: a problem at work or in an internship, written to a named supervisor. Typical points: describe what you are doing, ask for understanding, make a proposal, show understanding for the company's situation.
- Sprechen Teil 1: two topic cards such as Arbeitsmodelle or Weiterbildung. Each card has three bullets — several alternatives, one in detail, pros and cons with your evaluation — printed in varying order.
- Sprechen Teil 2: a yes/no question such as „Sollen Noten abgeschafft werden?“ with four short prompts such as Motivation? or Fairness?

Sources: [Goethe Modellsatz B2 Erwachsene, 2nd edition 2025](https://www.goethe.de/pro/relaunch/prf/materialien/B2/b2_modellsatz_erwachsene.pdf) · [Online-Übungssatz Schreiben](https://bfu.goethe.de/b2_mod_2MX6/schreiben.php) · [Online-Übungssatz Sprechen](https://bfu.goethe.de/b2_mod_2MX6/sprechen.php) · [Durchführungsbestimmungen B2, as of 1 Sept 2025](https://www.goethe.de/pro/relaunch/prf/de/Durchfuehrungsbestimmungen_B2.pdf) · [Goethe-Zertifikat B2 overview](https://www.goethe.de/ins/de/de/prf/gzb2.cfm)

## 3. Daily method: the 3-hour block

Run the same 3-hour block every day; only the content changes, and section 4 tells you which content. Hören and Lesen stay outside these 3 hours, as you already train them.

| Time | Block | What you do |
| --- | --- | --- |
| 0:00–0:20 | Review | Vocabulary due today (Anki or a paper box). Walk yesterday's memory palace aloud once. |
| 0:20–0:45 | New words | Today's batch from the Wortschatz tab: read, picture, place, self-test. Write 5 sentences with the 5 hardest words. |
| 0:45–1:15 | Frames | Today's module: read it aloud 3 times, build its image at its locus, write it from memory, correct, write it again. |
| 1:15–1:35 | Grammar | Today's point from section 13, then 10 transformations (drill prompt in section 15). |
| 1:35–1:45 | Break | Away from screens. |
| 1:45–2:35 | Production | The timed task from section 4: Schreiben Teil 1 (50 min), or Teil 2 (25 min) plus a recorded Vortrag or discussion. |
| 2:35–3:00 | Correction and Aussprache | Grade the text or recording with the AI prompt in section 15. Copy 3 corrected sentences into your error log. Shadow a model text for 5 minutes. |

From day 29 the frame block shrinks to a 10-minute recital and the production block grows: one Schreiben task, one Vortrag and one discussion per day.

**Spaced repetition.** Review each batch 1, 3, 7, 14 and 30 days after you learn it. Anki schedules this for you. On paper, use a five-compartment box and move a card forward only when you recall it instantly.

**Aussprache is worth 16 points.** Shadow daily: play one sentence of a model text read aloud by a voice app, pause, and repeat it with the same melody. Record yourself once a week and compare.

### Making words stick: picture, place, use

1. **Gender colour.** Every noun image gets its colour: der = blue and frozen in ice, die = red and burning, das = green and overgrown with grass. Plural die = grey and multiplied into a crowd.
2. **Sound bridge.** Link the German sound to a word you know in English or French, then build a scene with the meaning. *die Nachfrage* (demand): a crowd keeps asking again (nach-fragen) at a shop counter.
3. **Prefix plus root.** Decode verbs from their parts (table below). You remember a verb once you can explain why its prefix fits.
4. **Place.** Each topic cluster lives in one room or street of a memory palace (section 5), one word per object.
5. **Use.** A word counts as learned only after you have written one sentence with it and said it aloud.

**Endings that reveal the gender**

| Gender | Endings | Examples |
| --- | --- | --- |
| die | -ung, -heit, -keit, -schaft, -ion, -tät, -ik, -ie, -enz, -anz, -ur | die Wirkung, die Freiheit, die Möglichkeit, die Gesellschaft, die Produktion, die Qualität, die Kritik, die Strategie, die Tendenz, die Toleranz, die Kultur |
| der | -ismus, -ling, -or, -ent (people), most -er (people and tools) | der Tourismus, der Lehrling, der Motor, der Student, der Arbeitnehmer |
| das | -chen, -lein, -ment, -um, -nis (most), Ge- + noun (many), nouns made from verbs | das Mädchen, das Argument, das Studium, das Ergebnis, das Gesetz, das Lernen |

### Prefix plus root: decoding verbs

This toolkit marks separable verbs with a bar: *ab|lehnen* means "er lehnt ab". The prefixes be-, ver-, ent-, er-, zer-, ge-, miss- and emp- never separate.

| Prefix | Core idea | Examples from your templates |
| --- | --- | --- |
| be- | acts on an object | be-rücksichtigen (put Rücksicht on: take into account), be-fürworten (give a Wort für: support), be-wirken (bring about), be-treffen (concern) |
| ver- | change, away, to the end, wrongly | ver-meiden (avoid), ver-ursachen (create the Ursache: cause), ver-ringern (make gering: reduce), ver-schwenden (waste), ver-zichten (do without) |
| ent- | out of, away from | ent-stehen (stand out of: arise), ent-lasten (take the Last away: relieve), ent-scheiden (decide), ent-wickeln (unwrap: develop) |
| er- | reach a result | er-möglichen (make möglich), er-höhen (make hoch: raise), er-leichtern (make leicht: ease), er-schweren (make schwer: hinder), er-reichen (reach) |
| ab\| | off, down, away | ab\|lehnen (lean away: reject), ab\|schaffen (abolish), ab\|nehmen (decrease), ab\|wägen (weigh up) |
| an\| | towards, onto | an\|passen (adapt), an\|bieten (offer), an\|erkennen (recognise) |
| aus\| | out, fully | aus\|wirken (work out: have an effect), aus\|reichen (reach out: suffice), aus\|bauen (expand) |
| bei\| | alongside | bei\|tragen (carry alongside: contribute) |
| ein\| | in, into | ein\|führen (lead in: introduce), ein\|wenden (turn in: object), ein\|räumen (make room: concede) |
| nach\| | after, again | nach\|holen (fetch afterwards: catch up), nach\|denken (think after: reflect) |
| vor\| | before, in front | vor\|schlagen (put in front: propose), vor\|beugen (bend before: prevent) |
| zu\| | towards, more | zu\|nehmen (increase), zu\|stimmen (vote towards: agree) |
| um\| | around, change | um\|setzen (implement), um\|steigen (switch) |
| über- (inseparable) | over, across | über-zeugen (convince), über-wiegen (outweigh), über-schätzen (overestimate) |
| unter- (inseparable) | under | unter-stützen (support from below), unter-schätzen (underestimate) |
| wider- | against | wider-sprechen (speak against: contradict) |

## 4. The 58-day plan

Day 0 is tonight, Tuesday 13 October, and the exam is on Thursday 10 December. Each row is one 3-hour block; set its Done cell when you finish it.

- **Days 1–14 (14–27 Oct):** Schreiben frames in Palaces A and B, the core grammar, argument vocabulary.
- **Days 15–28 (28 Oct–10 Nov):** Sprechen frames in Palaces C and D, the remaining grammar, topic vocabulary.
- **Days 29–42 (11–24 Nov):** one topic per day across all three tasks. Mock 1 on day 35, Mock 2 on day 42.
- **Days 43–57 (25 Nov–9 Dec):** a mock every three or four days, the error log, and no new words after day 37.

Codes: F = Forumsbeitrag task (section 7), N = Nachricht task (section 9), D = discussion question (section 11), G = grammar point (section 13), W = vocabulary batch (Wortschatz tab). Vortrag topics are in the topic bank in section 10. The two mocks use Goethe's free [Modellsatz Erwachsene](https://www.goethe.de/pro/relaunch/prf/materialien/B2/b2_modellsatz_erwachsene.pdf) and [Modellsatz Jugendliche](https://www.goethe.de/pro/relaunch/prf/materialien/B2/b2_modellsatz_jugendliche.pdf); do not open them before those days.

| Day | Date | Memorise | Grammar | Words | Produce | Done |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | Di 13.10. | Read sections 1–3; choose your four palace routes (section 5) | – | – | Baseline: write F7 without help in 50 min; keep it for day 42 | Open |
| 1 | Mi 14.10. | Palace A, locus 1: Einleitung E-A to E-D | G1 Wortstellung | W01, B1-Check A | Copy Musterbeitrag 1 by hand and colour the frame | Open |
| 2 | Do 15.10. | Palace A, locus 2: Meinung M-A to M-E | G1 drills | W02, B1-Check B | One opinion sentence each for F8–F12, one per M-variant | Open |
| 3 | Fr 16.10. | Palace A, locus 3: Gründe G-A to G-D | G2 Nebensätze I | W03 | Gründe paragraph for F7, F8, F9 | Open |
| 4 | Sa 17.10. | Palace A, locus 4: Vor- und Nachteile V-A to V-E | G3 Nebensätze II | W04 | Pro and contra paragraphs for F10, F11 | Open |
| 5 | So 18.10. | Palace A, locus 5: Alternativen A-A to A-E | G4 Konjunktiv II: Formen | W05 | Alternatives paragraph for F8, F11, F18 | Open |
| 6 | Mo 19.10. | Palace A, locus 6: extra Leitpunkte X | G5 Konjunktiv II: Gebrauch | W06 | Rebuild Musterbeitrag 1 from memory, then compare | Open |
| 7 | Di 20.10. | Palace A, locus 7: Schluss; walk Palace A twice | G6 Passiv | W07 | Timed Teil 1: F7, 50 min, then AI grading | Open |
| 8 | Mi 21.10. | Palace B, loci 1–2: Anrede, Anlass | G7 Passiversatz | W08 | Timed Teil 1: F8 | Open |
| 9 | Do 22.10. | Palace B, locus 3: Situation, Entschuldigung | G12 n-Deklination, Sie-Formen | W09 | Copy Musternachrichten 1 and 2 and colour the frame | Open |
| 10 | Fr 23.10. | Palace B, locus 4: Verständnis zeigen, bitten | G8 Infinitiv mit zu | W10 | Timed Teil 2: N7, 25 min | Open |
| 11 | Sa 24.10. | Palace B, locus 5: Vorschlag, Angebot | G10 da-/wo-Wörter | W11 | Timed Teil 2: N8 | Open |
| 12 | So 25.10. | Palace B, locus 6: Frage, Schluss, Gruß; walk Palace B | G11 Adjektivendungen | W12 | Rebuild Musternachricht 1; timed Teil 2: N9 | Open |
| 13 | Mo 26.10. | Walk Palaces A and B aloud twice | G9 Relativsätze | W13 | Timed full Schreiben, 75 min: F9 + N10 | Open |
| 14 | Di 27.10. | Write every E, M and S variant from memory | G16 Indirekte Fragen | W14 | Timed Teil 1: F10; list your five most frequent error types | Open |
| 15 | Mi 28.10. | Palace C, loci 1–2: Einleitung, Alternativen | G13 Nominalstil | W15 | Shadow Mustervortrag 1 three times, then give it from keywords and record | Open |
| 16 | Do 29.10. | Palace C, locus 3: eine Möglichkeit genauer | G13 drills | W16 | Timed Teil 1: F11 | Open |
| 17 | Fr 30.10. | Palace C, locus 4: Vor- und Nachteile, Bewertung | G14 Partizipien | W17 | Read Mustervortrag 3, then give Verkehrsmittel from keywords; AI feedback | Open |
| 18 | Sa 31.10. | Palace C, loci 5–6: Schluss, Fragen; walk Palace C | G15 Zweiteilige Konnektoren | W18 | Timed Teil 2: N11; Vortrag Wohnformen with two AI questions | Open |
| 19 | So 01.11. | Palace D, stations 1–4 | G17 Futur, Partikeln | W19 | Vortrag Weiterbildung from keywords; Diskussion D1 | Open |
| 20 | Mo 02.11. | Palace D, stations 5–8 | G18 Konjunktiv I | W20 | Timed Teil 1: F12; Diskussion D2 | Open |
| 21 | Di 03.11. | Palace D, stations 9–12; du/Sie switch | Review G1–G3 | W21 | Vortrag Sport treiben; Diskussion D3 | Open |
| 22 | Mi 04.11. | Argument-Uhr: 12 categories | Review G4–G5 | W22 | Timed Teil 2: N12; Diskussion D4 with the Argument-Uhr | Open |
| 23 | Do 05.11. | Walk Palace D; the R-A-F turn | Review G6–G7 | W23 | Two 15-minute prep drills (Familienformen + D5), then speak both | Open |
| 24 | Fr 06.11. | Personal anchors (section 12) | Review G8–G10 | W24 | Timed Teil 1: F13; Vortrag Suche nach einem Arbeitsplatz | Open |
| 25 | Sa 07.11. | Walk Palaces C and D | Review G11–G12 | W25 | Sprechen simulation: 15 min prep, Vortrag Stress-Management, questions, Diskussion D6 | Open |
| 26 | So 08.11. | Walk all four palaces | Review G13–G15 | W26 | Timed full Schreiben, 75 min: F14 + N13 | Open |
| 27 | Mo 09.11. | Re-learn your weakest module | Review G16–G18 | W27 | Vortrag Mediennutzung im Alltag; Diskussion D7 | Open |
| 28 | Di 10.11. | Recite only | Error log | – | Rewrite your 10 worst sentences; 15 min shadowing | Open |
| 29 | Mi 11.11. | 10-minute recital of Palaces A–D | Weakest point | W28 | Timed Teil 1: F15; Vortrag Sprachen lernen; Diskussion D8 | Open |
| 30 | Do 12.11. | Recital | Weakest point | W29 | Timed Teil 2: N14; Vortrag Müllvermeidung; Diskussion D9 | Open |
| 31 | Fr 13.11. | Recital | Weakest point | W30 | Timed Teil 1: F16; Vortrag Urlaubsgestaltung; Diskussion D10 | Open |
| 32 | Sa 14.11. | Recital | Weakest point | W31 | Timed Teil 2: N1 task, your own text; Vortrag Einkaufen im Alltag; Diskussion D12 | Open |
| 33 | So 15.11. | Recital | Weakest point | W32 | Timed Teil 1: F17; Vortrag Ehrenamtliche Tätigkeit; Diskussion D13 | Open |
| 34 | Mo 16.11. | Recital | Weakest point | W33 | Timed Teil 2: N2 task, your own text; Vortrag Wohnformen im Alter; Diskussion D14 | Open |
| 35 | Di 17.11. | MOCK 1 | – | – | Goethe Modellsatz Erwachsene: Schreiben 75 min, Sprechen with 15 min prep; score yourself with section 2 | Open |
| 36 | Mi 18.11. | Recital; fix Mock 1 weak spots | Weakest point | W34 | Timed Teil 1: F18; Vortrag: the Mock 1 topic you did not choose; Diskussion D11 | Open |
| 37 | Do 19.11. | Recital | Weakest point | W35, the last new batch | Timed Teil 2: N3 task, your own text; Vortrag Freizeitgestaltung; Diskussion D15 | Open |
| 38 | Fr 20.11. | Recital | Weakest point | Review only | Timed Teil 1: F1 task, your own text; Vortrag Ernährung am Arbeitsplatz; Diskussion D16 | Open |
| 39 | Sa 21.11. | Recital | Weakest point | Review only | Timed Teil 2: N4 task, your own text; Vortrag Haustiere; Diskussion D17 | Open |
| 40 | So 22.11. | Recital | Weakest point | Review only | Timed Teil 1: F2 task, your own text; Vortrag Finanzielle Absicherung im Alter; Diskussion D18 | Open |
| 41 | Mo 23.11. | Recital | Weakest point | Review only | Timed Teil 2: N5 task, your own text; Vortrag Familienformen; Diskussion D19 | Open |
| 42 | Di 24.11. | MOCK 2 | – | – | Goethe Modellsatz Jugendliche: Schreiben and Sprechen; compare with your day-0 text | Open |
| 43 | Mi 25.11. | Re-learn the palace that failed in Mock 2 | Weakest point | Error words | Timed Teil 1: F3 task, your own text; Vortrag Finanzierung des Studiums; Diskussion D20 | Open |
| 44 | Do 26.11. | Recital | Weakest point | Error words | Timed Teil 2: N6 task, your own text; Vortrag and Diskussion of your choice | Open |
| 45 | Fr 27.11. | Recital | Weakest point | Error words | Timed Teil 1: F4 task, your own text; Diskussion D1 from the other side | Open |
| 46 | Sa 28.11. | MOCK 3 | – | – | F5 task + N7 again, then Sprechen with two topic-bank topics you have not used | Open |
| 47 | So 29.11. | Analyse Mock 3 and update the error log | – | Error words | Light: two Vorträge, no writing | Open |
| 48 | Mo 30.11. | Recital | Weakest point | Error words | Timed Teil 1: F6 task, your own text; Vortrag and Diskussion from your weakest cluster | Open |
| 49 | Di 01.12. | Recital | Weakest point | Error words | Timed Teil 2: your weakest scenario; Vortrag and Diskussion | Open |
| 50 | Mi 02.12. | MOCK 4 | – | – | Timed full Schreiben on your two weakest prompts, then a Sprechen simulation | Open |
| 51 | Do 03.12. | Speed drill: write the frames of all six Musterbeiträge in 30 min | – | Error words | Analyse Mock 4 | Open |
| 52 | Fr 04.12. | Recital | Weakest point | Error words | Timed Teil 1 on a new prompt your AI invents; Vortrag and Diskussion | Open |
| 53 | Sa 05.12. | MOCK 5 | – | – | Exam-day rehearsal in the real order: Lesen 65, Hören 40, Schreiben 75, then Sprechen | Open |
| 54 | So 06.12. | Walk all four palaces | – | Error words | Light day: analyse Mock 5 | Open |
| 55 | Mo 07.12. | Recital | – | Error words | Two Vorträge and two discussions; no writing | Open |
| 56 | Di 08.12. | Recital | – | Error words | Last timed full Schreiben, 75 min; then stop producing | Open |
| 57 | Mi 09.12. | Walk Palaces A–D once | – | – | Read two Musterbeiträge and two Musternachrichten aloud; pack your ID and two blue or black pens; sleep early | Open |
| Exam | Do 10.12. | Goethe-Zertifikat B2 | – | – | Schreiben and Sprechen | – |

## 5. Memory palaces

Four palaces hold everything you recite: A (Forum) for Schreiben Teil 1, B (Büro) for Teil 2, C (Bühne) for the Vortrag and D (Café) for the discussion. Put each on a real route you know blindly — your flat, your way to work, a building you know well — and never change the order.

1. Walk the real route once and write your own locus into the first column, in order.
2. At each locus, place the image below. Make it large, absurd and moving, and colour every noun by gender (section 3).
3. Walk the palace in your head while saying the German frame aloud. Then write the frame from memory and correct it.
4. Recite each new palace after 1, 3 and 7 days, then once a week.

### Palace A — Das Forum (Schreiben Teil 1)

| Your locus | Suggested locus | Module | Words the image holds | Image |
| --- | --- | --- | --- | --- |
|  | Front door | Einleitung | viel diskutiert · Meinungen gehen weit auseinander · Sichtweise schildern | A TV on your door blares a talk show. Two neighbours stand back to back on the doormat and walk apart, stretching a rubber band. You hold up a painted sign (Schild → schildern) with a huge eye on it (Sicht). |
|  | Coat rack | Meinung | die Auffassung vertreten · fest davon überzeugt · kritisch zu bewerten | You are a travelling salesman (Vertreter) and grab (auf-fassen) a coat labelled AUFFASSUNG. The next coat is nailed tight (fest) to the wall. |
|  | Kitchen | Gründe | zum einen · zum anderen · Hinzu kommt, dass · Das liegt daran, dass | Two pots labelled 1 and 2 are full of coffee grounds (Grund). Someone walks in and tips in a third spoon: "Hinzu kommt!" A cat lies (liegt) beside them; its name tag says DARAN. |
|  | Dining table | Vor- und Nachteile | Ein großer Vorteil besteht darin · Dagegen spricht · nicht unterschätzen | A balance on the table. Left pan: a golden trophy standing (besteht) inside (darin) a glass box. Right pan: a mouth speaking against it (dagegen spricht). A tiny lead weight that everyone underestimates tips the scale. |
|  | Window | Alternativen | Eine sinnvolle Alternative wäre · Statt … zu … · wünschenswert, wenn … würde | Outside, the road forks and the second path glows with a sign: SINNVOLL. A shooting star (Wunsch) crosses the sky wearing a crown (Würde → würde). |
|  | Bookshelf | Extra-Leitpunkte | zur Folge haben · eine Rolle spielen · die Verantwortung tragen · Voraussetzung | Footprints walk out of one book (Folgen); an actor plays a role on another; a third carries a heavy load (Verantwortung tragen); a fourth stands on a pedestal (Voraussetzung). |
|  | Bed | Schluss | Alles in allem · die Vorteile überwiegen · Entscheidend ist jedoch | You stuff everything (alles) into one bag and weigh it beside the bed; the Vorteile side outweighs (überwiegt). A judge in pyjamas bangs a gavel: ENTSCHEIDEND. |

### Palace B — Das Büro (Schreiben Teil 2)

| Your locus | Suggested locus | Module | Words the image holds | Image |
| --- | --- | --- | --- | --- |
|  | Entrance | Anrede | Sehr geehrter Herr … / Sehr geehrte Frau … · comma · small letter | A doorman bows very deeply (sehr geehrt) and hands you a comma-shaped key. The next door handle is tiny: after the comma you start with a small letter. |
|  | Reception | Anlass | ich wende mich an Sie, weil … · vielen Dank für Ihre Nachricht | You turn round (wenden) to face the receptionist, who hands you an envelope stamped ANLASS. |
|  | Your desk | Situation, Entschuldigung | Zurzeit bin ich mit … beschäftigt · Mir ist ein Fehler unterlaufen · Dafür möchte ich mich entschuldigen | Three files bury your desk (beschäftigt). Coffee runs under (unter-laufen) the papers. You take off your guilt (Schuld → ent-schuldigen) like a heavy backpack. |
|  | Team room | Verständnis zeigen, bitten | Mir ist bewusst, dass … · Ich bitte Sie um Verständnis | Colleagues race past with deadlines; you hold up a sign: BEWUSST. You hand your boss an umbrella (bitten um). |
|  | Whiteboard | Vorschlag, Angebot | Ich würde vorschlagen, … zu … · Wäre es möglich, …? · Alternativ könnte ich … | You strike (schlagen) the whiteboard in front (vor) of everyone. A second marker draws an alternative route. |
|  | Exit | Frage, Schluss, Gruß | Könnten Sie mir Bescheid geben, ob …? · Für Rückfragen stehe ich Ihnen gern zur Verfügung · Mit freundlichen Grüßen | A butler stands ready at the door (zur Verfügung stehen) and waves goodbye. His greeting has no comma after it. |

### Palace C — Die Bühne (Sprechen Teil 1)

| Your locus | Suggested locus | Module | Words the image holds | Image |
| --- | --- | --- | --- | --- |
|  | Hall door | Einleitung | In meinem Vortrag geht es um … · Zuerst … Danach … Anschließend … Zum Schluss … | Four numbered signposts on the door: Zuerst, Danach, Anschließend, Zum Schluss. |
|  | Three stage steps | Mehrere Alternativen | Die erste Möglichkeit ist … · Eine zweite, ebenfalls verbreitete Form … · Und schließlich … | Each step holds one alternative; the third step closes (schließlich) like a lid. |
|  | Lectern | Eine Möglichkeit genauer | Nun möchte ich genauer auf … eingehen · zeichnet sich dadurch aus, dass … | You walk into (eingehen) the lectern with a magnifying glass; a medal (Auszeichnung) hangs on it. |
|  | Scales on stage | Vor- und Nachteile, Bewertung | Für … spricht vor allem · Problematisch finde ich · Wenn ich abwäge, komme ich zu dem Ergebnis | You weigh (abwägen) two bags and the display prints ERGEBNIS. |
|  | Curtain | Schluss | Ich persönlich würde mich für … entscheiden · Damit komme ich zum Ende · Vielen Dank für Ihre Aufmerksamkeit | The curtain falls and you bow. |
|  | Audience | Fragen | Danke für die Frage · Wenn ich Sie richtig verstehe … · Das hängt davon ab | Hands go up; each holds a question mark that you repeat back before you answer. |

### Palace D — Das Café (Sprechen Teil 2)

| Your locus | Suggested locus | Station | Words the image holds | Image |
| --- | --- | --- | --- | --- |
|  | Door | 1 Eröffnen | Sollen wir anfangen? · Wir diskutieren die Frage, ob … | You hold the café door open for your partner. |
|  | Menu board | 2 Meinung äußern | Ich bin der Meinung, dass … · Ich bin dafür / dagegen | You point firmly at your order on the board. |
|  | Coffee machine | 3 Begründen | Mein wichtigstes Argument ist … · Das liegt daran, dass … | The machine grinds the grounds (Grund) of your argument. |
|  | Cake counter | 4 Beispiel geben | Ein gutes Beispiel dafür ist … · Ich habe selbst erlebt, dass … | You hold up a sample slice: das Beispiel. |
|  | Waiter | 5 Nach der Meinung fragen | Wie siehst du das? · Was hältst du davon? | The waiter holds a microphone out to your partner. |
|  | Two chairs side by side | 6 Zustimmen und ergänzen | Da hast du völlig recht · und ich würde noch ergänzen, dass … | You pull your chair next to your partner's and add (ergänzen) a cup. |
|  | Half a cake | 7 Teilweise zustimmen | Da hast du zwar recht, aber … · Im Prinzip ja, allerdings … | You agree to eat only half. |
|  | Tipped-over chair | 8 Widersprechen | Das sehe ich etwas anders · Ich verstehe dein Argument, aber … | You tip a chair over, politely. |
|  | Magnifier on the table | 9 Nachfragen | Wie meinst du das genau? · Habe ich dich richtig verstanden, dass …? | You inspect your partner's words with a magnifier. |
|  | Hourglass | 10 Zeit gewinnen | Das ist eine gute Frage · Lass mich kurz überlegen | You turn the hourglass and win three seconds. |
|  | Bell on the counter | 11 Einbringen, zurückführen | Darf ich kurz etwas dazu sagen? · Um noch einmal auf … zurückzukommen | You ring the bell and walk back (zurückkommen) to an earlier point. |
|  | Till | 12 Zusammenfassen | Zusammenfassend bin ich dafür / dagegen, weil … | At the till you add up (zusammenfassen) the bill: dafür or dagegen. |

The **Argument-Uhr** hangs on the café wall: a clock whose 12 hours are 12 kinds of argument (section 11). Give each hour one object — 12 a heart (Gesundheit), 1 a tree (Umwelt), 2 a purse (Kosten), 3 a stopwatch (Zeit), 4 an open cage (Freiheit), 5 Justitia's scales (Gerechtigkeit), 6 a helmet (Sicherheit), 7 joined hands (Gemeinschaft), 8 a book (Bildung), 9 a factory (Wirtschaft und Arbeit), 10 a drum (Kultur und Tradition), 11 a police cap (Umsetzbarkeit und Kontrolle). In the preparation room, glance round the clock once and you have twelve directions for arguments.

**Vocabulary loci.** Give each topic cluster its own street or room — Umwelt in a park, Arbeit in an office, Bildung in a library, Gesundheit in a pharmacy — and put each word on one object there.

## 6. Schreiben Teil 1: the Forumsbeitrag frame

Write six paragraphs — Einleitung, one paragraph per Leitpunkt in the order of the task, Schluss — and build each from one memorised frame plus two or three sentences of your own content. Bold text below is the frame; everything in brackets is yours.

### The master text (Version A) — learn this one first

**Das Thema „**\[Thema\]**“ wird zurzeit viel diskutiert, und auch in meinem Umfeld gehen die Meinungen dazu weit auseinander. Deshalb möchte ich gern meine Sichtweise schildern.**

**Ich vertrete die Auffassung, dass** \[your opinion, verb at the end\]. \[One sentence saying why.\]

**Dafür, dass** \[the development\], **gibt es mehrere Gründe. Zum einen** \[reason 1, verb in position 2\]. **Zum anderen** \[reason 2\]. **Hinzu kommt, dass** \[reason 3, verb at the end\].

**Ein großer Vorteil** \[von + Dativ\] **besteht darin, dass** \[advantage\]. **Allerdings darf man die Nachteile nicht unterschätzen:** \[disadvantage\].

**Eine sinnvolle Alternative wäre meiner Meinung nach,** \[… zu + Infinitiv\]. **Es wäre außerdem wünschenswert, wenn** \[subject … infinitive\] **würde.**

**Alles in allem bin ich davon überzeugt, dass** \[your conclusion\]. **Entscheidend ist jedoch, dass** \[the condition that matters most\].

The frame is about 80 words. Your content must add at least 100 more. If a Leitpunkt asks for something else — other possibilities, consequences, your country — swap in the matching module below.

### Variant modules: rotate A, B and C

| Module | Frame | Grammar to watch |
| --- | --- | --- |
| E-A Einleitung | Das Thema „…“ wird zurzeit viel diskutiert, und auch in meinem Umfeld gehen die Meinungen dazu weit auseinander. Deshalb möchte ich gern meine Sichtweise schildern. | Passiv (wird diskutiert); auseinander\|gehen; verb after Deshalb |
| E-B Einleitung | Mit großem Interesse habe ich die Beiträge zum Thema „…“ gelesen. Da mich diese Frage auch persönlich betrifft, möchte ich mich gern an der Diskussion beteiligen. | mit großem Interesse (no article); Da-clause first, so the main clause starts with its verb |
| E-C Einleitung | Ob \[subject … verb\], ist eine Frage, die heutzutage viele Menschen beschäftigt. Im Folgenden möchte ich darlegen, wie ich dazu stehe. | ob-clause as subject; relative clause; indirect question |
| E-D Einleitung | \[Development\] gehört für viele Menschen längst zum Alltag. Doch ist das wirklich eine gute Entwicklung? Dazu möchte ich hier meine Meinung äußern. | gehören zu + Dativ; a rhetorical question |
| M-A Meinung | Ich vertrete die Auffassung, dass … | dass: verb at the end |
| M-B Meinung | Ich bin fest davon überzeugt, dass … | überzeugt sein von → davon |
| M-C Meinung | Aus meiner Sicht ist \[topic\] eher positiv / kritisch zu bewerten, weil … | sein + zu + Infinitiv |
| M-D Meinung | Grundsätzlich halte ich \[Akkusativ\] für sinnvoll, allerdings nur unter der Voraussetzung, dass … | halten für + Akkusativ |
| M-E Meinung | Ich sehe das Thema mit gemischten Gefühlen: Einerseits …, andererseits … | verb straight after einerseits / andererseits |
| G-A Gründe | Dafür, dass \[development\], gibt es mehrere Gründe. Zum einen … Zum anderen … Hinzu kommt, dass … | verb straight after Zum einen |
| G-B Gründe | Ein wesentlicher Grund dafür ist, dass … Außerdem spielt \[Nominativ\] eine wichtige Rolle. | eine Rolle spielen |
| G-C Gründe | Das liegt vor allem daran, dass … Darüber hinaus darf man nicht vergessen, dass … | liegen an → daran |
| G-D Gründe | Aufgrund \[Genitiv\] … — *Aufgrund der niedrigen Preise greifen viele Menschen zu Plastik.* | aufgrund + Genitiv |
| V-A Vor-/Nachteile | Ein großer Vorteil \[von + Dativ\] besteht darin, dass … Allerdings darf man die Nachteile nicht unterschätzen: … | bestehen in → darin |
| V-B Vor-/Nachteile | Für \[Akkusativ\] spricht vor allem, dass … Dagegen spricht jedoch, dass … | für + Akkusativ |
| V-C Vor-/Nachteile | Zwar \[verb\] …, aber … — *Zwar spart man viel Zeit, aber man fühlt sich schnell isoliert.* | verb straight after Zwar |
| V-D Nachteil | Ein Nachteil, den man nicht unterschätzen sollte, ist … | relative clause, Akkusativ den |
| V-E Vorteile der anderen Möglichkeiten | Diese Alternativen haben gleich mehrere Vorteile: Sie sind nicht nur …, sondern auch … Außerdem … | nicht nur …, sondern auch |
| A-A Alternative | Eine sinnvolle Alternative wäre meiner Meinung nach, … zu … (with a plural noun: … wären flexible Arbeitszeiten) | Konjunktiv II; the verb agrees with a plural noun |
| A-B Alternative | Statt … zu …, könnte man auch … | statt … zu + Infinitiv |
| A-C Wunsch | Es wäre wünschenswert, wenn \[subject\] … \[infinitive\] würde. | würde at the very end |
| A-D Bedingung | Wenn \[subject\] … \[infinitive\] würde, könnte man … | unreal condition |
| A-E Andere Möglichkeiten | Es gibt durchaus andere Möglichkeiten, … zu …: Man kann zum Beispiel … Ebenso denkbar wäre es, … zu … | comma before the zu-infinitive |
| S-A Schluss | Alles in allem bin ich davon überzeugt, dass … Entscheidend ist jedoch, dass … | – |
| S-B Schluss | Zusammenfassend lässt sich sagen, dass … Ich bin gespannt, wie sich das Thema in Zukunft entwickeln wird. | sich lassen + Infinitiv; Futur |
| S-C Schluss | Abschließend möchte ich betonen, dass … Ich bin gespannt auf weitere Meinungen zu diesem Thema. | gespannt sein auf + Akkusativ |

### Extra Leitpunkte (Palace A, the bookshelf)

| When the task asks … | Use |
| --- | --- |
| Folgen, Auswirkungen | Diese Entwicklung hat zur Folge, dass … Das wirkt sich vor allem auf \[Akkusativ\] aus. |
| Bedeutung, Rolle | \[X\] spielt für viele Menschen eine immer wichtigere Rolle, denn … |
| Eigene Erfahrungen, ein Beispiel | Ich habe selbst die Erfahrung gemacht, dass … Ein gutes Beispiel dafür ist … |
| Situation in Ihrem Land | In meinem Heimatland sieht die Situation etwas anders aus: Dort … |
| Verantwortung, Rolle des Staates | Meiner Ansicht nach tragen vor allem \[Nominativ Plural\] die Verantwortung dafür, dass … Die Politik sollte dafür sorgen, dass … |
| Bedingungen, Voraussetzungen | Das funktioniert allerdings nur, wenn … Eine wichtige Voraussetzung dafür ist, dass … |
| Zukunft, Entwicklung | Ich gehe davon aus, dass sich … in Zukunft weiter verbreiten wird. |
| Begründen Sie, warum Sie dafür oder dagegen sind | Ich bin vor allem deshalb dafür / dagegen, weil … Außerdem … |

**Linking paragraphs:** *Was die Gründe betrifft, …* · *Neben den Vorteilen gibt es aber auch Nachteile.* · *Kommen wir nun zu möglichen Alternativen.* · *Vor diesem Hintergrund …*

**Paraphrase the task instead of copying it.** "Nennen Sie Gründe, warum viele Menschen trotzdem mit dem Auto fahren" becomes *Dass viele trotz guter Alternativen am Auto festhalten, hat mehrere Gründe.*

### The 50-minute routine

1. **0–3 min:** read the task, number the four points and underline each verb (äußern, nennen, begründen, vorschlagen).
2. **3–10 min:** on scrap paper, note two or three keywords per point using the Argument-Uhr. Pick your E, M and S variants and three Nomen-Verb-Verbindungen to use.
3. **10–40 min:** write directly on the answer sheet: six paragraphs, points in the task's order.
4. **40–50 min:** run the check below; estimate words as lines × words per line.

### The final check (last 10 minutes)

1. Every point has its own paragraph with at least two content sentences.
2. Verb second in main clauses; verb last after dass, weil, obwohl, wenn, ob, damit; verb straight after Deshalb, Außerdem, Zum einen, Allerdings, Zwar.
3. Every noun capitalised; articles and plurals checked.
4. Adjective endings: der wichtige Grund · ein wichtiger Grund · mit großem Interesse.
5. Prepositions and case: aufgrund + Genitiv, mit + Dativ, für + Akkusativ.
6. Commas before dass, weil, obwohl, wenn, relative pronouns and um … zu.
7. Konjunktiv II: wäre, hätte, könnte; würde + Infinitiv with the infinitive at the end.
8. At least 150 words (aim for 170–190), with an Einleitung and a Schluss.

## 7. Schreiben Teil 1: six model posts and twelve practice tasks

Each model below is 163–181 words and shows the frame in bold, so you can see how little of it is memorised and how much is content. Learn the frames; never memorise the content.

### F1 · Homeoffice für alle? (E-A, M-A, G-A, V-A, A-A, S-A)

*Äußern Sie Ihre Meinung dazu, ob alle Beschäftigten das Recht auf Homeoffice haben sollten. · Nennen Sie Gründe, warum viele Menschen lieber zu Hause arbeiten. · Nennen Sie Nachteile des Homeoffice. · Nennen Sie andere Möglichkeiten, Beruf und Privatleben besser zu vereinbaren.*

**Das Thema** Homeoffice **wird zurzeit viel diskutiert, und auch in meinem Umfeld gehen die Meinungen dazu weit auseinander. Deshalb möchte ich gern meine Sichtweise schildern.**

**Ich vertrete die Auffassung, dass** alle Beschäftigten das Recht haben sollten, zumindest an einigen Tagen pro Woche von zu Hause aus zu arbeiten – sofern ihre Tätigkeit das zulässt.

**Dafür, dass** viele Menschen lieber im Homeoffice arbeiten, **gibt es mehrere Gründe. Zum einen** sparen sie sich den täglichen Weg zur Arbeit und damit viel Zeit und Geld. **Zum anderen** können sie sich zu Hause oft besser konzentrieren, weil sie nicht ständig von Kollegen unterbrochen werden.

**Allerdings darf man die Nachteile nicht unterschätzen.** Wer ausschließlich zu Hause arbeitet, fühlt sich schnell isoliert. Außerdem fällt es vielen schwer, Arbeit und Freizeit klar zu trennen.

**Eine sinnvolle Alternative wären meiner Meinung nach** flexible Arbeitszeiten, damit Eltern zum Beispiel ihre Kinder rechtzeitig von der Kita abholen können. **Es wäre außerdem wünschenswert, wenn** mehr Firmen Teilzeitstellen für Führungskräfte anbieten **würden.**

**Alles in allem bin ich davon überzeugt, dass** die Vorteile überwiegen. **Entscheidend ist jedoch, dass** Arbeitgeber und Beschäftigte gemeinsam faire Regeln festlegen.

### F2 · Autofreie Innenstädte (E-B, M-D, G-B, V-B, A-B + A-D, S-B)

*Äußern Sie Ihre Meinung zu autofreien Innenstädten. · Nennen Sie Gründe, warum viele Städte den Autoverkehr reduzieren wollen. · Nennen Sie Vor- und Nachteile autofreier Innenstädte. · Nennen Sie andere Möglichkeiten, den Stadtverkehr umweltfreundlicher zu gestalten.*

**Mit großem Interesse habe ich die Beiträge zum Thema** „Autofreie Innenstädte“ **gelesen. Da mich diese Frage auch persönlich betrifft, möchte ich mich gern an der Diskussion beteiligen.**

**Grundsätzlich halte ich** autofreie Innenstädte **für sinnvoll, allerdings nur unter der Voraussetzung, dass** die Alternativen gut funktionieren.

**Ein wesentlicher Grund dafür, dass** viele Städte den Autoverkehr reduzieren wollen, **ist** die schlechte Luft. **Außerdem spielt** der Platzmangel **eine wichtige Rolle:** Autos brauchen viel Fläche, die für Grünflächen, Radwege oder Cafés genutzt werden könnte.

**Für** eine autofreie Innenstadt **spricht vor allem** die höhere Lebensqualität. **Dagegen spricht jedoch, dass** ältere Menschen oder Menschen mit eingeschränkter Mobilität auf das Auto angewiesen sein können. Auch viele Geschäfte befürchten, dass weniger Kunden kommen.

**Statt** Autos komplett **zu** verbieten, **könnte man auch** die Parkgebühren erhöhen und den öffentlichen Nahverkehr günstiger machen. **Wenn** Busse und Bahnen häufiger fahren **würden,** würden viele Menschen freiwillig auf ihr Auto verzichten.

**Zusammenfassend lässt sich sagen, dass** weniger Autos unseren Städten guttun würden. **Entscheidend ist jedoch, dass** niemand ausgeschlossen wird.

### F3 · Handyverbot an Schulen? (E-C, M-C, G-C, V-A, own proposal, S-C)

*Äußern Sie Ihre Meinung zu einem Handyverbot an Schulen. · Nennen Sie Gründe, warum Smartphones für Jugendliche so wichtig sind. · Nennen Sie Vorteile digitaler Medien im Unterricht. · Machen Sie Vorschläge, wie Schulen Medienkompetenz fördern können.*

**Ob** Smartphones an Schulen verboten werden sollten, **ist eine Frage, die heutzutage viele** Eltern und Lehrkräfte **beschäftigt. Im Folgenden möchte ich darlegen, wie ich dazu stehe.**

**Aus meiner Sicht ist** ein generelles Handyverbot **eher kritisch zu bewerten.** Ich halte es aber für richtig, dass die Geräte während des Unterrichts ausgeschaltet bleiben.

Dass Smartphones für Jugendliche so wichtig sind, **liegt vor allem daran, dass** sie darüber ständig mit ihren Freunden in Kontakt bleiben. **Darüber hinaus darf man nicht vergessen, dass** soziale Netzwerke für viele junge Menschen ein wichtiger Teil ihrer Identität sind.

Im Unterricht können digitale Medien durchaus nützlich sein. **Ein großer Vorteil besteht darin, dass** Schüler Informationen schnell recherchieren und in ihrem eigenen Tempo lernen können. Zudem lassen sich Lern-Apps gut an das jeweilige Niveau anpassen.

Meiner Meinung nach sollten Schulen Medienkompetenz als eigenes Unterrichtsfach anbieten. In diesem Fach könnten Jugendliche lernen, wie man Falschmeldungen erkennt und die eigenen Daten schützt.

**Abschließend möchte ich betonen, dass** Verbote allein das Problem nicht lösen. Wichtiger ist, dass junge Menschen einen verantwortungsvollen Umgang mit digitalen Medien lernen.

### F4 · Weniger Fleisch essen? (E-A, M-B, G-A, V-D style, A-A, S-A)

*Äußern Sie Ihre Meinung dazu, ob Fleisch teurer werden sollte. · Nennen Sie Gründe, warum immer mehr Menschen auf Fleisch verzichten. · Nennen Sie Nachteile einer fleischlosen Ernährung. · Nennen Sie andere Möglichkeiten, sich umweltbewusst zu ernähren.*

**Das Thema** Fleischkonsum **wird zurzeit viel diskutiert, und auch in meinem** Freundeskreis **gehen die Meinungen dazu weit auseinander. Deshalb möchte ich gern meine Sichtweise schildern.**

**Ich bin fest davon überzeugt, dass** Fleisch teurer werden sollte, denn der niedrige Preis spiegelt nicht die wahren Kosten für Umwelt und Tiere wider.

Dass immer mehr Menschen auf Fleisch verzichten, **hat mehrere Gründe. Zum einen** wissen viele inzwischen, unter welchen Bedingungen Tiere in der Massentierhaltung leben. **Zum anderen spielt auch** der Klimaschutz **eine wichtige Rolle,** weil die Fleischproduktion große Mengen an Treibhausgasen verursacht.

**Allerdings** hat eine fleischlose Ernährung auch Nachteile. Wer sich nicht gut informiert, nimmt unter Umständen zu wenig Eisen oder Vitamin B12 zu sich. Außerdem sind Ersatzprodukte oft teuer, was für Familien mit wenig Geld ein Problem ist.

**Eine sinnvolle Alternative wäre meiner Meinung nach,** vor allem regionale und saisonale Produkte **zu** kaufen. Man könnte zudem Fleisch bewusster genießen, zum Beispiel nur am Wochenende.

**Alles in allem bin ich der Meinung, dass** wir weniger, aber besseres Fleisch essen sollten. **Entscheidend ist jedoch, dass** gesunde Ernährung für alle bezahlbar bleibt.

### F5 · Ein soziales Pflichtjahr? (E-B, M-A, G-B, own Nachteile, A-B, S-B)

*Äußern Sie Ihre Meinung zu einem sozialen Pflichtjahr für junge Menschen. · Nennen Sie Gründe, warum sich viele Menschen ehrenamtlich engagieren. · Nennen Sie Nachteile eines Pflichtjahres. · Nennen Sie andere Möglichkeiten, junge Menschen für soziales Engagement zu begeistern.*

**Mit großem Interesse habe ich die Diskussion zum Thema** „Soziales Pflichtjahr“ **verfolgt. Da mich diese Frage auch persönlich beschäftigt, möchte ich mich gern daran beteiligen.**

**Ich vertrete die Auffassung, dass** ein freiwilliges soziales Jahr sinnvoller ist als eine Pflicht. Engagement, zu dem man gezwungen wird, ist meiner Meinung nach selten nachhaltig.

Für ehrenamtliches Engagement **gibt es viele Gründe. Ein wesentlicher Grund ist, dass** Menschen anderen helfen und etwas Sinnvolles tun möchten. **Hinzu kommt, dass** man dabei neue Kontakte knüpft und wertvolle Erfahrungen sammelt.

Ein Pflichtjahr hätte jedoch auch klare Nachteile. Junge Menschen würden ein Jahr später ins Studium oder in den Beruf starten. Außerdem besteht die Gefahr, dass unmotivierte Helfer mehr schaden als nützen, zum Beispiel in der Pflege.

**Statt** auf Zwang **zu** setzen, **könnte man** freiwillige Dienste attraktiver machen, etwa durch eine bessere Bezahlung oder Vorteile bei der Vergabe von Studienplätzen.

**Zusammenfassend lässt sich sagen, dass** soziales Engagement für die Gesellschaft sehr wertvoll ist. **Entscheidend ist jedoch, dass** es aus Überzeugung geschieht.

### F6 · Online einkaufen (E-A, M-C, G-C, A-E, V-E, S-A) — the pattern of the official task

*Äußern Sie Ihre Meinung zum Online-Shopping. · Nennen Sie Gründe, warum immer mehr Menschen online einkaufen. · Nennen Sie andere Möglichkeiten, einzukaufen. · Nennen Sie Vorteile dieser anderen Möglichkeiten.*

**Das Thema** Online-Shopping **wird zurzeit viel diskutiert, und auch in meinem Umfeld gehen die Meinungen dazu weit auseinander. Deshalb möchte ich gern meine Sichtweise schildern.**

**Aus meiner Sicht ist** Online-Shopping zwar praktisch, aber **eher kritisch zu bewerten,** wenn es zur Gewohnheit wird.

Dass immer mehr Menschen im Internet einkaufen, **liegt vor allem daran, dass** es bequem ist und Zeit spart. Man kann rund um die Uhr Preise vergleichen und bekommt die Ware direkt nach Hause geliefert. Außerdem ist das Angebot online oft viel größer als im Geschäft.

**Es gibt jedoch durchaus andere Möglichkeiten,** einzukaufen. **Man kann zum Beispiel** im Fachgeschäft um die Ecke oder auf dem Wochenmarkt einkaufen. **Ebenso denkbar sind** Second-Hand-Läden, in denen gebrauchte Kleidung und Möbel verkauft werden.

**Diese Alternativen haben gleich mehrere Vorteile:** Man wird **nicht nur** persönlich beraten, **sondern** kann die Produkte **auch** direkt anfassen und ausprobieren. **Außerdem** gibt es weniger Verpackungsmüll und Rücksendungen, was die Umwelt schont.

**Alles in allem bin ich der Meinung, dass** wir das Internet bewusster nutzen sollten. **Entscheidend ist jedoch, dass** die Geschäfte in unseren Innenstädten überleben können.

### Practice tasks F7–F18

The plan in section 4 assigns these. Write each in 50 minutes, then grade it with the prompt in section 15.

| Task | Topic | The four points |
| --- | --- | --- |
| F7 | Die Vier-Tage-Woche | Meinung zur Vier-Tage-Woche · Gründe, warum sich viele Beschäftigte mehr Freizeit wünschen · Nachteile einer kürzeren Arbeitswoche · andere Möglichkeiten, Stress im Beruf zu reduzieren |
| F8 | Kostenloser Nahverkehr | Meinung zu kostenlosen Bussen und Bahnen · Gründe, warum viele Menschen trotzdem mit dem Auto fahren · andere Möglichkeiten, den Autoverkehr zu reduzieren · Vorteile dieser Möglichkeiten |
| F9 | KI im Studium | Meinung zur Nutzung von KI-Programmen im Studium · Gründe, warum so viele Studierende KI nutzen · Gefahren dieser Entwicklung · Vorschläge, wie Hochschulen damit umgehen sollten |
| F10 | Stadt oder Land? | Meinung zum Leben auf dem Land · Gründe, warum viele junge Menschen in die Großstadt ziehen · Vorteile des Lebens auf dem Land · Möglichkeiten, ländliche Regionen attraktiver zu machen |
| F11 | Billige Mode | Meinung zu billiger Mode · Gründe, warum viele Menschen so oft neue Kleidung kaufen · andere Möglichkeiten, sich modisch zu kleiden · Vorteile dieser Möglichkeiten |
| F12 | Soziale Netzwerke für Kinder | Meinung zu einem Mindestalter für soziale Netzwerke · Gründe, warum Kinder schon früh soziale Medien nutzen · Gefahren sozialer Netzwerke für Kinder · Möglichkeiten, Kinder zu schützen |
| F13 | Lebenslanges Lernen | Meinung zur Weiterbildung im Beruf · Gründe, warum Erwachsene heute ständig dazulernen müssen · verschiedene Formen der Weiterbildung · Vorteile einer dieser Formen |
| F14 | Einsamkeit im Alter | Meinung zur Situation älterer Menschen · Gründe, warum sich viele Senioren einsam fühlen · Möglichkeiten, wie Nachbarn und Vereine helfen können · Vorteile des Kontakts zwischen Jung und Alt |
| F15 | Fernreisen | Meinung zu Fernreisen · Gründe, warum so viele Menschen jedes Jahr ins Ausland fliegen · Folgen des Massentourismus für die Reiseziele · Alternativen zum Urlaub mit dem Flugzeug |
| F16 | Bargeld abschaffen? | Meinung zur Abschaffung des Bargelds · Gründe, warum immer mehr Menschen mit Karte oder Handy bezahlen · Nachteile des bargeldlosen Bezahlens · Vorteile des Bargelds |
| F17 | Haustiere in der Stadt | Meinung zu Haustieren in der Großstadt · Gründe, warum sich so viele Menschen ein Haustier anschaffen · Probleme, die Haustiere in der Stadt verursachen können · Vorschläge für ein gutes Zusammenleben |
| F18 | Lebensmittelverschwendung | Meinung zur Verschwendung von Lebensmitteln · Gründe, warum so viele Lebensmittel im Müll landen · Möglichkeiten, Lebensmittelverschwendung zu vermeiden · Vorteile dieser Möglichkeiten |

## 8. Schreiben Teil 2: the formal message frame

Teil 2 is a formal message to a named person at work, and its four points arrive shuffled on purpose. Put them in this order: why you write → the situation → apology or request for understanding → understanding for their side → your proposal → question and close.

### The master text — learn this one first

**Sehr geehrte Frau** \[Name\]**,** / **Sehr geehrter Herr** \[Name\]**,**

**ich wende mich an Sie, weil** \[why you are writing\].

**Zurzeit bin ich mit** \[Dativ\] **beschäftigt:** \[what you are doing\]. \[The problem in one sentence.\] **Ich bitte Sie um Verständnis für meine Situation.** / **Dafür möchte ich mich entschuldigen.**

**Mir ist bewusst, dass** \[their side, e.g. zurzeit im ganzen Team sehr viel zu tun ist\].

**Ich würde deshalb vorschlagen,** \[… zu + Infinitiv\]. **Alternativ könnte ich** \[a second option\].

**Könnten Sie mir bitte kurz Bescheid geben, ob** \[your question\]? **Vielen Dank im Voraus für Ihr Verständnis.**

**Mit freundlichen Grüßen** \[Vorname Nachname\]

The frame is about 60 words; add 50–70 words of content to reach 110–130.

### Sorting the shuffled points

| Order | Function | Typical task wording |
| --- | --- | --- |
| 1 | Anlass | (always first, even when not listed) |
| 2 | Situation | Beschreiben Sie … · Erklären Sie … · Nennen Sie die Ursache … |
| 3 | Your feelings | Entschuldigen Sie sich. · Bedauern Sie … · Bitten Sie um Verständnis. |
| 4 | Their side | Zeigen Sie Verständnis für … |
| 5 | Solution | Machen Sie einen Vorschlag. · Bitten Sie um … · Bieten Sie … an. |
| 6 | Close | Fragen Sie … · Bitten Sie um Rückmeldung. · Dank und Gruß |

### Modules

| Module | Frames | Watch out |
| --- | --- | --- |
| Anrede | Sehr geehrte Frau Schulz, · Sehr geehrter Herr Ebert, · Liebe Frau Schulz, / Lieber Herr Ebert, (a colleague you know well) · Sehr geehrte Damen und Herren, (no name given) | Comma after the Anrede, then a small letter: „vielen Dank …“ |
| Anlass | ich wende mich an Sie, weil … · ich schreibe Ihnen, weil … · vielen Dank für Ihre Nachricht. · leider muss ich Ihnen mitteilen, dass … · ich wende mich mit einer Bitte an Sie: … | sich wenden an + Akkusativ |
| Situation | Zurzeit bin ich mit \[Dativ\] beschäftigt: … · Wie Sie wissen, arbeite ich gerade an \[Dativ\] … · Der Grund dafür ist, dass … · Leider bin ich am Freitag beruflich verhindert. · Leider ist mir kurzfristig etwas dazwischengekommen. · Mir ist leider ein Fehler unterlaufen: … | unterlaufen and dazwischenkommen take sein in the Perfekt |
| Entschuldigen, bedauern | Dafür möchte ich mich vielmals entschuldigen. · Es tut mir sehr leid, dass … · Ich bedauere sehr, dass … · Ich hätte Sie früher informieren sollen. | sich entschuldigen für → dafür |
| Um Verständnis bitten | Ich bitte Sie um Verständnis für meine Situation. · Ich hoffe sehr auf Ihr Verständnis. | bitten um, hoffen auf + Akkusativ |
| Verständnis zeigen | Mir ist bewusst, dass zurzeit im ganzen Team sehr viel zu tun ist. · Ich verstehe natürlich, dass die Firma gerade unter großem Zeitdruck steht. · Ich kann gut nachvollziehen, dass das für Sie unangenehm ist. | – |
| Vorschlagen, anbieten | Ich würde deshalb vorschlagen, … zu … · Wäre es möglich, … zu …? · Alternativ könnte ich … · Selbstverständlich bin ich bereit, … zu … · Als Ausgleich biete ich Ihnen an, … zu … | Separable verbs: nachzuholen, abzugeben |
| Höflich bitten | Ich wäre Ihnen sehr dankbar, wenn Sie … könnten. · Könnten Sie mir bitte … schicken? · Ich möchte Sie bitten, … zu … | Konjunktiv II |
| Fragen | Könnten Sie mir bitte kurz Bescheid geben, ob …? · Darüber hinaus hätte ich noch eine Frage: … | Indirect question: verb at the end |
| Schluss | Vielen Dank im Voraus für Ihr Verständnis. · Ich freue mich auf Ihre Antwort. · Ich würde mich über eine baldige Rückmeldung freuen. · Für Rückfragen stehe ich Ihnen gern zur Verfügung. | sich freuen auf (future) vs. über (now) |
| Gruß | Mit freundlichen Grüßen + Name after Sehr geehrte/r · Viele Grüße or Herzliche Grüße + Name after Liebe/r | No comma after Grüßen |

### Register traps

- **Herr** in the Anrede, **Herrn** everywhere else: *Sehr geehrter Herr Ebert,* but *Ich habe Herrn Krause angerufen* and *mit Herrn Becker*.
- *Sehr geehrte Frau* — never "Sehr geehrter Frau".
- Sie, Ihnen, Ihr and Ihre are always capitalised; *sich* stays small.
- Never open with "Hallo" and never switch to du.
- Give every point at least one full sentence of its own. A point merged into another sentence is easy for a rater to miss.

### The 25-minute routine

1. **0–4 min:** number the four points in the order above.
2. **4–19 min:** write directly on the answer sheet.
3. **19–25 min:** check Anrede and Gruß, Sie-forms, Herrn, verb positions, and at least 100 words.

## 9. Schreiben Teil 2: six model messages and eight practice tasks

All six models are work situations of 108–121 words, with the frame in bold. Read the task first and check how each point became its own sentence.

### N1 · Zu viel Arbeit (to a team leader)

*Sie arbeiten seit drei Monaten in einer Firma. Ihre Teamleiterin, Frau Krüger, möchte bis Freitag einen Bericht von Ihnen. Sie haben aber zwei andere dringende Aufgaben. · Beschreiben Sie Ihre aktuellen Aufgaben. · Bitten Sie um Verständnis. · Zeigen Sie Verständnis für die Situation im Team. · Machen Sie einen Vorschlag.*

**Sehr geehrte Frau** Krüger,

**ich wende mich an Sie, weil** ich den Bericht leider nicht bis Freitag fertigstellen kann.

**Zurzeit bin ich mit** zwei dringenden Aufgaben **beschäftigt:** Ich bereite die Präsentation für den Kunden Meyer vor und organisiere gleichzeitig die Schulung für die neuen Kolleginnen und Kollegen. Beides muss bis Mittwoch erledigt sein.

**Ich bitte Sie** deshalb **um Verständnis für meine Situation. Mir ist bewusst, dass zurzeit im ganzen Team sehr viel zu tun ist** und dass der Bericht wichtig ist.

**Ich würde vorschlagen,** den Bericht erst am kommenden Dienstag abzugeben. **Alternativ könnte** Herr Wolf einen Teil der Datenanalyse übernehmen, damit wir die Frist trotzdem einhalten.

**Könnten Sie mir bitte kurz Bescheid geben,** welche Lösung Ihnen lieber ist?

**Mit freundlichen Grüßen** \[Vorname Nachname\]

### N2 · Ein Fehler (to the boss)

*Ihr Chef, Herr Wagner, hatte Sie gebeten, einem Kunden bis Freitag ein Angebot zu schicken. Sie haben es vergessen, und der Kunde hat sich beschwert. · Entschuldigen Sie sich. · Erklären Sie, wie es dazu kam. · Beschreiben Sie, was Sie schon unternommen haben. · Machen Sie einen Vorschlag für die Zukunft.*

**Sehr geehrter Herr** Wagner,

**leider ist mir ein** ärgerlicher **Fehler unterlaufen:** Ich habe das Angebot für die Firma Krause nicht rechtzeitig verschickt. **Dafür möchte ich mich bei Ihnen aufrichtig entschuldigen.**

**Wie Sie wissen,** war ich letzte Woche mit dem Projektabschluss stark ausgelastet. Dabei habe ich die Frist leider übersehen. **Ich hätte Sie früher um Unterstützung bitten sollen.**

Inzwischen habe ich Herrn Krause angerufen, mich entschuldigt und ihm das Angebot heute Morgen geschickt. Er hat zum Glück Verständnis gezeigt.

**Damit so etwas nicht noch einmal passiert, schlage ich vor,** wichtige Fristen künftig in unseren gemeinsamen Teamkalender **einzutragen.**

**Ich hoffe auf Ihr Verständnis und stehe Ihnen für Rückfragen gern zur Verfügung.**

**Mit freundlichen Grüßen** \[Vorname Nachname\]

### N3 · Bitte um eine Weiterbildung (to a manager)

*Sie möchten an einer dreitägigen Weiterbildung teilnehmen. Schreiben Sie Ihrer Vorgesetzten, Frau Schulz. · Beschreiben Sie die Weiterbildung. · Erklären Sie, warum sie für Ihre Arbeit nützlich ist. · Bitten Sie um Freistellung. · Machen Sie einen Vorschlag, wie Ihre Arbeit in dieser Zeit erledigt wird.*

**Sehr geehrte Frau** Schulz,

**ich wende mich mit einer Bitte an Sie.** Vom 3. bis 5. März findet in Frankfurt ein Kurs zum Thema „Datenanalyse mit Python“ statt, an dem ich gern teilnehmen würde.

Die Weiterbildung **wäre für meine Arbeit sehr nützlich, weil** ich unsere Kundendaten dadurch schneller und genauer auswerten könnte. Davon würde das ganze Team profitieren.

**Deshalb möchte ich Sie fragen, ob Sie** mich für diese drei Tage freistellen **könnten. Ich wäre Ihnen außerdem sehr dankbar, wenn** die Firma die Kursgebühr übernehmen **würde.**

Meine laufenden Aufgaben würde ich vorher mit meinem Kollegen Herrn Becker absprechen, damit nichts liegen bleibt.

**Ich würde mich über eine baldige Rückmeldung freuen.**

**Mit freundlichen Grüßen** \[Vorname Nachname\]

### N4 · Absage mit Alternative (to a head of department)

*Ihre Abteilungsleiterin, Frau Berger, hat Sie gebeten, beim Abteilungsmeeting am Donnerstag die Ergebnisse Ihres Projekts vorzustellen. An diesem Tag haben Sie aber einen Kundentermin. · Entschuldigen Sie sich. · Erklären Sie die Situation. · Machen Sie einen Vorschlag. · Bitten Sie um Rückmeldung.*

**Sehr geehrte Frau** Berger,

**vielen Dank für** Ihr Vertrauen und die Einladung, beim Abteilungsmeeting die Ergebnisse unseres Projekts vorzustellen. **Leider muss ich Ihnen mitteilen, dass** ich am Donnerstag nicht teilnehmen kann. **Dafür möchte ich mich entschuldigen.**

**Der Grund dafür ist** ein Kundentermin in Leipzig, der schon seit Wochen feststeht und sich leider nicht verschieben lässt.

Ich würde die Präsentation aber sehr gern übernehmen. **Wäre es möglich,** sie beim nächsten Meeting **zu** halten? **Alternativ könnte ich** Ihnen die Folien vorher schicken, und meine Kollegin Frau Neumann könnte sie am Donnerstag vorstellen.

**Könnten Sie mir bitte kurz Bescheid geben,** welche Lösung Ihnen lieber ist? **Vielen Dank im Voraus für Ihr Verständnis.**

**Mit freundlichen Grüßen** \[Vorname Nachname\]

### N5 · Teilweise zusagen (to a colleague)

*Ihr Kollege, Herr Yilmaz, organisiert das Sommerfest Ihrer Firma und bittet Sie, sich um die Musik zu kümmern. Sie haben wenig Zeit, möchten aber helfen. · Bedanken Sie sich für die Anfrage. · Erklären Sie, warum Sie die Aufgabe nicht ganz übernehmen können. · Bieten Sie eine andere Hilfe an. · Fragen Sie nach Details zum Fest.*

**Lieber Herr** Yilmaz,

**vielen Dank für Ihre Anfrage,** ob ich die Musik für unser Sommerfest organisieren könnte. Ich freue mich sehr, dass Sie dabei an mich gedacht haben.

Leider bin ich in den nächsten Wochen **mit** einem wichtigen Projekt **beschäftigt,** sodass ich nicht genug Zeit habe, mich um die gesamte Musik zu kümmern.

Trotzdem würde ich Sie gern unterstützen. Ich könnte zum Beispiel am Tag des Festes beim Aufbau helfen oder Kontakt zu einem DJ aufnehmen, den ich gut kenne.

**Darüber hinaus hätte ich noch** ein paar **Fragen:** Wie viele Gäste werden erwartet, und gibt es schon ein festes Budget?

**Ich freue mich auf Ihre Antwort.**

**Viele Grüße** \[Vorname Nachname\]

### N6 · Lieferverzögerung (to a customer)

*Sie arbeiten im Kundenservice einer Möbelfirma. Die Lieferung an eine Kundin, Frau Roth, verspätet sich um zwei Wochen. · Entschuldigen Sie sich. · Erklären Sie den Grund für die Verspätung. · Nennen Sie einen neuen Liefertermin. · Bieten Sie einen Ausgleich an.*

**Sehr geehrte Frau** Roth,

**leider muss ich Ihnen mitteilen, dass** sich die Lieferung Ihres Esstisches um etwa zwei Wochen verzögert. **Dafür möchte ich mich** im Namen unserer Firma **vielmals entschuldigen.**

**Der Grund für** die Verspätung **ist** ein Engpass bei unserem Holzlieferanten. Davon sind in diesem Monat leider viele Bestellungen betroffen.

Nach aktuellem Stand können wir Ihnen den Tisch am 18. November liefern. Sollte Ihnen dieser Termin nicht passen, finden wir selbstverständlich einen anderen. Sie können Ihre Bestellung natürlich auch kostenlos stornieren, falls Ihnen das lieber ist.

**Als Ausgleich für die Unannehmlichkeiten** erhalten Sie einen Rabatt von zehn Prozent auf den Kaufpreis.

**Für Rückfragen stehe ich Ihnen jederzeit gern zur Verfügung.**

**Mit freundlichen Grüßen** \[Vorname Nachname\]

### Practice tasks N7–N14

The points are listed in shuffled order, as in the exam. Sort them first, then write in 25 minutes.

| Task | Situation | The four points (shuffled) |
| --- | --- | --- |
| N7 | Sie sollen am Montag einen neuen Kollegen einarbeiten, haben an diesem Tag aber eine Schulung. Schreiben Sie Ihrem Abteilungsleiter, Herrn Lange. | Machen Sie einen Vorschlag. · Erklären Sie das Problem. · Fragen Sie, was der neue Kollege zuerst lernen soll. · Entschuldigen Sie sich. |
| N8 | Ein Kunde, Herr Seidel, hat eine falsche Rechnung bekommen und sich beschwert. | Bieten Sie einen Ausgleich an. · Entschuldigen Sie sich. · Beschreiben Sie, was Sie jetzt tun. · Erklären Sie, wie es zu dem Fehler kam. |
| N9 | Sie möchten zwei Tage pro Woche im Homeoffice arbeiten. Schreiben Sie Ihrer Vorgesetzten, Frau Hartmann. | Zeigen Sie Verständnis für mögliche Bedenken. · Beschreiben Sie Ihre Situation. · Machen Sie einen Vorschlag für eine Testphase. · Erklären Sie, welche Vorteile das für die Firma hat. |
| N10 | Sie haben einen Termin mit einem Geschäftspartner, Herrn Dr. Kühn, vergessen. | Schlagen Sie einen neuen Termin vor. · Entschuldigen Sie sich. · Bieten Sie an, ihm wichtige Unterlagen vorab zu schicken. · Erklären Sie, wie es dazu kam. |
| N11 | Ihr Team soll ein großes Projekt bis Monatsende abschließen, aber ein Kollege ist krank. Schreiben Sie Ihrem Projektleiter, Herrn Vogel. | Bitten Sie um Unterstützung. · Zeigen Sie Verständnis für den Zeitdruck. · Beschreiben Sie die Situation. · Machen Sie einen Vorschlag. |
| N12 | Sie organisieren eine Firmenveranstaltung, und der Referent hat kurzfristig abgesagt. Schreiben Sie Ihrer Chefin, Frau Dr. Lorenz. | Bitten Sie um eine Entscheidung. · Informieren Sie über das Problem. · Entschuldigen Sie sich für die kurzfristige Nachricht. · Nennen Sie zwei mögliche Lösungen. |
| N13 | Sie machen ein Praktikum und sind krank geworden. Morgen sollten Sie eine Präsentation halten. Schreiben Sie Ihrem Betreuer, Herrn Schmitt. | Fragen Sie, was Sie von zu Hause aus erledigen können. · Informieren Sie ihn über Ihre Situation. · Schlagen Sie eine Lösung für die Präsentation vor. · Drücken Sie Ihr Bedauern aus. |
| N14 | Ihre Firma bietet einen Englischkurs für Mitarbeitende an. Schreiben Sie an Frau Becker aus der Personalabteilung. | Bitten Sie um die Anmeldung. · Fragen Sie nach Zeiten und Niveau. · Zeigen Sie Ihr Interesse. · Erklären Sie, warum der Kurs für Ihre Arbeit wichtig ist. |

## 10. Sprechen Teil 1: the Vortrag

Speak for about four minutes in five moves — introduction, alternatives, one in detail, pros and cons with a verdict, close. Then answer questions from your partner and an examiner, and ask your partner a question about their talk. That question round alone is worth 12 points.

Your card has a topic and three bullets: *Beschreiben Sie mehrere Alternativen / Formen / Bereiche* · *Beschreiben Sie eine Möglichkeit genauer* · *Nennen Sie Vor- und Nachteile und bewerten Sie diese.* The order varies. Follow the printed order and announce it in your introduction. Never skip the verdict: the card says *bewerten*, not only *nennen*.

### The script

| Time | Move | Frame |
| --- | --- | --- |
| 0:00–0:30 | Einleitung | Guten Tag! In meinem Vortrag geht es um das Thema „…“. Ich habe dieses Thema gewählt, weil … Zuerst stelle ich verschiedene \[Alternativen / Formen\] vor. Danach gehe ich auf eine davon genauer ein. Anschließend nenne ich Vor- und Nachteile und bewerte sie, und zum Schluss sage ich, wie ich persönlich dazu stehe. |
| (other order) | Einleitung | … Zuerst stelle ich verschiedene Alternativen vor. Dann nenne ich ihre Vor- und Nachteile, und danach gehe ich auf eine Möglichkeit genauer ein. |
| 0:30–1:30 | Mehrere Alternativen | Kommen wir zum ersten Punkt: Welche \[Alternativen\] gibt es? Die erste Möglichkeit ist \[X\]. Das bedeutet, dass … Eine zweite, sehr verbreitete Möglichkeit ist \[Y\]: Hier … Und schließlich gibt es noch \[Z\]. Diese Form ist vor allem für \[Gruppe\] interessant. |
| 1:30–2:30 | Eine Möglichkeit genauer | Nun möchte ich genauer auf \[X\] eingehen. Diese Möglichkeit zeichnet sich vor allem dadurch aus, dass … Konkret sieht das so aus: … Besonders geeignet ist sie für Menschen, die … |
| 2:30–3:30 | Vor- und Nachteile, Bewertung | Welche Vor- und Nachteile gibt es? Für \[X\] spricht vor allem, dass … Ein weiterer Vorteil ist, dass … Auf der anderen Seite gibt es aber auch Nachteile. Problematisch finde ich zum Beispiel, dass … Außerdem darf man nicht vergessen, dass … Wenn ich die Vor- und Nachteile gegeneinander abwäge, komme ich zu dem Ergebnis, dass … Für mich überwiegen eindeutig die Vorteile / Nachteile. |
| 3:30–4:00 | Schluss | Ich persönlich würde mich für \[X\] entscheiden, weil … / Für mich käme \[X\] eher nicht infrage, da … Damit komme ich zum Ende meines Vortrags. Vielen Dank für Ihre Aufmerksamkeit! Ich beantworte jetzt gern Ihre Fragen. |

**Gender-safe trick:** refer back with *Diese Form* or *Diese Möglichkeit*. Both are always *die*, so you never have to choose der, die or das under pressure.

### The question round (12 points)

**Answering:** paraphrase → answer → reason → example, in 20–30 seconds.

- Danke für die Frage, das ist ein wichtiger Punkt.
- Wenn ich dich richtig verstehe, möchtest du wissen, ob … (Sie-form: Wenn ich Sie richtig verstehe, möchten Sie wissen, ob …)
- Das hängt davon ab, ob … · Das kommt darauf an, wie …
- Wie ich im Vortrag schon kurz gesagt habe, …
- Darüber habe ich ehrlich gesagt noch nicht genau nachgedacht, aber ich würde sagen, dass …
- Da hast du recht, das ist ein Nachteil. Trotzdem finde ich, dass …

**Asking your partner:** while they speak, note one detail. Then: *Vielen Dank für deinen interessanten Vortrag. Du hast gesagt, dass … Könntest du das noch etwas genauer erklären?* If nothing comes, use one of these four:

1. Welche Möglichkeit würdest du persönlich wählen, und warum?
2. Glaubst du, dass \[X\] in Zukunft noch wichtiger wird?
3. Wie ist die Situation in deinem Heimatland? Ist \[X\] dort auch verbreitet?
4. Für wen ist \[X\] deiner Meinung nach am besten geeignet?

### Notes in the preparation room

Of your 15 minutes: 1 minute to choose the topic (the one where you can name three alternatives within 30 seconds), 8 minutes of Vortrag notes, 5 minutes of discussion notes, 1 minute to read everything through. Keep the Vortrag notes to six lines of keywords:

1. Thema + why you chose it (one word)
2. Alternativen: X / Y / Z
3. Genauer: X → three details
4. Two pluses, two minuses → verdict
5. Schluss: your choice + reason
6. (Filled while listening) one word for your question to your partner

### Three model talks (about four minutes each when spoken)

Read each aloud with a timer; aim for 3:45–4:15. Then give it again from six lines of keywords. Never learn the content word for word.

**V1 · Arbeitsmodelle** — *Beschreiben Sie mehrere Alternativen. · Beschreiben Sie eine Möglichkeit genauer. · Nennen Sie Vor- und Nachteile und bewerten Sie diese.*

Guten Tag! In meinem Vortrag geht es um das Thema „Arbeitsmodelle“. Ich habe dieses Thema gewählt, weil es mich gerade persönlich sehr beschäftigt. Zuerst stelle ich verschiedene Modelle vor. Danach gehe ich auf eines davon genauer ein. Anschließend nenne ich Vor- und Nachteile und bewerte sie, und zum Schluss sage ich, wie ich persönlich dazu stehe.

Kommen wir zum ersten Punkt: Welche Arbeitsmodelle gibt es? Das klassische Modell ist die Vollzeitstelle mit etwa 40 Stunden pro Woche. Eine zweite, sehr verbreitete Möglichkeit ist die Teilzeit: Hier arbeitet man weniger Stunden und verdient entsprechend weniger. Außerdem gibt es die Gleitzeit. Dabei kann man innerhalb eines bestimmten Rahmens selbst entscheiden, wann man anfängt und wann man aufhört. Und schließlich wird zurzeit viel über die Vier-Tage-Woche diskutiert.

Nun möchte ich genauer auf die Vier-Tage-Woche eingehen. Dieses Modell zeichnet sich vor allem dadurch aus, dass man nur an vier Tagen arbeitet und drei Tage frei hat. Es gibt zwei Varianten: Entweder arbeitet man an den vier Tagen länger, oder man arbeitet insgesamt weniger Stunden bei gleichem Gehalt. In Deutschland haben einige Firmen dieses Modell bereits getestet.

Welche Vor- und Nachteile gibt es? Für dieses Modell spricht vor allem, dass die Beschäftigten mehr Zeit für Familie, Hobbys und Erholung haben. Erste Studien deuten außerdem darauf hin, dass ausgeruhte Mitarbeiter produktiver sind und seltener krank werden. Auf der anderen Seite gibt es aber auch Nachteile. Problematisch finde ich zum Beispiel, dass dieses Modell nicht in allen Branchen funktioniert. In Krankenhäusern oder in der Gastronomie muss ja jeden Tag jemand da sein. Außerdem darf man nicht vergessen, dass zehn Stunden am Tag sehr anstrengend sein können. Wenn ich die Vor- und Nachteile gegeneinander abwäge, komme ich zu dem Ergebnis, dass die Vier-Tage-Woche für viele Büroberufe eine gute Lösung wäre.

Ich persönlich würde mich für dieses Modell entscheiden, weil ich den zusätzlichen freien Tag zum Lernen nutzen könnte. Damit komme ich zum Ende meines Vortrags. Vielen Dank für Ihre Aufmerksamkeit! Ich beantworte jetzt gern Ihre Fragen.

**V2 · Weiterbildung** — *Beschreiben Sie mehrere Formen. · Nennen Sie Vor- und Nachteile und bewerten Sie diese. · Beschreiben Sie eine Form genauer.* This card puts pros and cons second, so the talk follows that order.

Guten Tag! In meinem Vortrag geht es um das Thema „Weiterbildung“. Ich habe dieses Thema gewählt, weil ich selbst gerade eine berufliche Weiterbildung mache. Zuerst stelle ich verschiedene Formen vor. Dann nenne ich ihre Vor- und Nachteile, und danach gehe ich auf eine Form genauer ein. Zum Schluss sage ich, welche Form ich persönlich am besten finde.

Welche Formen der Weiterbildung gibt es? Viele Erwachsene besuchen Präsenzkurse, zum Beispiel an der Volkshochschule. Eine zweite, immer beliebtere Form sind Online-Kurse, die man von zu Hause aus machen kann. Wer einen offiziellen Abschluss möchte, kann außerdem ein Fernstudium beginnen. Und schließlich bieten viele Firmen ihren Mitarbeitern eigene Schulungen an.

Welche Vor- und Nachteile haben diese Formen? Präsenzkurse haben den großen Vorteil, dass man direkt Fragen stellen kann und andere Teilnehmer kennenlernt. Dafür sind sie zeitlich wenig flexibel. Bei Online-Kursen ist es genau umgekehrt: Man ist flexibel, aber man muss sehr diszipliniert sein. Ein Fernstudium führt zu einem anerkannten Abschluss, kostet aber viel Zeit und oft auch viel Geld. Betriebliche Schulungen sind meistens kostenlos, allerdings entscheidet oft die Firma, was man lernt.

Nun möchte ich genauer auf die Online-Kurse eingehen. Diese Form zeichnet sich vor allem dadurch aus, dass man zeitlich und räumlich unabhängig ist. Man braucht nur einen Computer und eine stabile Internetverbindung. Meistens gibt es Videos, Übungen und regelmäßige Online-Treffen mit einer Lehrkraft. Besonders geeignet ist diese Form für Menschen, die Beruf und Familie unter einen Hut bringen müssen.

Wenn ich alle Vor- und Nachteile gegeneinander abwäge, komme ich zu dem Ergebnis, dass Online-Kurse eine sehr gute Möglichkeit sind – aber nur für Menschen, die gut selbstständig lernen können. Ich persönlich bevorzuge eine Mischung aus Online- und Präsenzunterricht: Online lerne ich die Theorie, und in Präsenzphasen kann ich Fragen stellen und mit anderen diskutieren. Damit komme ich zum Ende meines Vortrags. Vielen Dank fürs Zuhören! Ich beantworte jetzt gern Ihre Fragen.

**V3 · Verkehrsmittel** — *Beschreiben Sie mehrere Alternativen. · Beschreiben Sie eine Möglichkeit genauer. · Nennen Sie Vor- und Nachteile und bewerten Sie diese.*

Guten Tag! In meinem Vortrag geht es um das Thema „Verkehrsmittel“. Dieses Thema betrifft uns alle, denn jeder von uns muss jeden Tag irgendwie zur Arbeit, zum Einkaufen oder zu Freunden kommen. Zuerst stelle ich verschiedene Verkehrsmittel vor. Danach gehe ich auf eines genauer ein, anschließend nenne ich Vor- und Nachteile, und zum Schluss sage ich meine persönliche Meinung.

Welche Möglichkeiten gibt es? Viele Menschen fahren nach wie vor mit dem eigenen Auto. Sehr verbreitet sind aber auch die öffentlichen Verkehrsmittel, also Busse, U-Bahnen und Straßenbahnen. Eine dritte Möglichkeit ist das Fahrrad, das in vielen Städten immer beliebter wird. Und schließlich gibt es seit einigen Jahren neue Angebote wie Carsharing oder E-Roller, die man per App nutzen kann.

Nun möchte ich genauer auf das Fahrrad eingehen. Diese Form der Fortbewegung zeichnet sich vor allem dadurch aus, dass sie fast nichts kostet und keine Abgase produziert. Viele Städte bauen deshalb ihre Radwege aus. In Kopenhagen oder Amsterdam zum Beispiel fährt ein großer Teil der Bevölkerung täglich mit dem Rad zur Arbeit.

Welche Vor- und Nachteile hat das Fahrrad? Für das Fahrrad spricht vor allem, dass man sich bewegt und dadurch etwas für seine Gesundheit tut. Außerdem steht man nicht im Stau und muss keinen Parkplatz suchen. Auf der anderen Seite gibt es aber auch Nachteile. Problematisch finde ich zum Beispiel, dass Radfahren bei Regen, Schnee oder Dunkelheit unangenehm und manchmal gefährlich ist. Außerdem darf man nicht vergessen, dass das Fahrrad für längere Strecken oder für ältere Menschen nicht immer geeignet ist. Wenn ich die Vor- und Nachteile gegeneinander abwäge, komme ich zu dem Ergebnis, dass das Fahrrad für kurze Strecken das beste Verkehrsmittel ist.

Ideal wäre aus meiner Sicht eine Kombination: mit dem Rad zum Bahnhof und dann mit der Bahn weiter. Dafür müssten die Städte allerdings mehr sichere Radwege und Fahrradparkplätze bauen. Ich bin jetzt am Ende meines Vortrags. Vielen Dank für Ihre Aufmerksamkeit! Haben Sie Fragen?

### Topic bank: 22 Vortrag topics

Titles in bold appear in Goethe's published materials. For each, the alternatives to name and two pluses and minuses to start from.

| Topic | Alternatives | + | − |
| --- | --- | --- | --- |
| **Arbeitsmodelle** | Vollzeit, Teilzeit, Gleitzeit, Homeoffice, Vier-Tage-Woche, Jobsharing | Flexibilität, Work-Life-Balance | weniger Gehalt, nicht in allen Branchen möglich |
| **Weiterbildung** | Präsenzkurs (VHS), Online-Kurs, Fernstudium, betriebliche Schulung | Karrierechancen, neue Kenntnisse | Kosten, Doppelbelastung |
| **Verkehrsmittel** | Auto, Bus und Bahn, Fahrrad, E-Roller, Fahrgemeinschaft, zu Fuß | Gesundheit, Umwelt | Wetter, Verspätungen |
| **Wohnformen** | allein, Wohngemeinschaft, mit Partner oder Familie, Mehrgenerationenhaus | Gesellschaft, Kosten teilen | wenig Privatsphäre, Konflikte |
| **Wohnformen im Alter** | eigene Wohnung mit Pflegedienst, bei den Kindern, betreutes Wohnen, Pflegeheim, Senioren-WG | Selbstständigkeit, Sicherheit | hohe Kosten, fremde Umgebung |
| **Finanzierung des Studiums** | Eltern, BAföG, Stipendium, Nebenjob, Studienkredit | Unabhängigkeit, Berufserfahrung | Schulden, weniger Zeit fürs Studium |
| **Gesund leben** (Bereiche) | Bewegung, Ernährung, Schlaf, Stressabbau, Vorsorge | Wohlbefinden, Leistungsfähigkeit | Zeitaufwand, Disziplin |
| **Freundschaften pflegen** | persönliche Treffen, Telefon, Messenger, soziale Netzwerke, gemeinsame Hobbys | Nähe, Kontakt über Entfernungen | Zeitmangel, Oberflächlichkeit |
| **Ernährung am Arbeitsplatz** | Kantine, mitgebrachtes Essen, Imbiss, Lieferservice, Snacks am Schreibtisch | Kosten, Kollegen treffen | ungesund, keine echte Pause |
| **Sprachen lernen** | Sprachkurs, App, Tandem, Auslandsaufenthalt, Filme und Serien | Flexibilität, echte Kommunikation | keine Korrektur, Motivation |
| **Urlaubsgestaltung** | Pauschalreise, Individualreise, Städtereise, Camping, Aktivurlaub, Urlaub zu Hause | Erholung, neue Kulturen | Kosten, Umweltbelastung |
| **Freizeitgestaltung** | Sport, Kultur, Medien, Freunde, Ehrenamt, Hobbys | Ausgleich zum Beruf, Kontakte | Kosten, Freizeitstress |
| **Ehrenamtliche Tätigkeit** | Sportverein, Tafel, Umweltschutz, Nachbarschaftshilfe, Integration | Sinn, Erfahrungen | keine Bezahlung, Zeit |
| **Sport treiben** | Verein, Fitnessstudio, allein draußen, Apps, Mannschaftssport | Gesundheit, Stressabbau | Verletzungen, Kosten |
| **Mediennutzung im Alltag** | Fernsehen, Zeitung, soziale Medien, Podcasts, Messenger | schnell, überall verfügbar | Falschmeldungen, Abhängigkeit |
| **Einkaufen im Alltag** | Supermarkt, Wochenmarkt, Online-Shopping, Fachgeschäft, Second-Hand | Bequemlichkeit, Beratung | Verpackungsmüll, Preis |
| **Familienformen** | Kernfamilie, Alleinerziehende, Patchworkfamilie, Großfamilie, Paare ohne Kinder | Unterstützung, Vielfalt | Belastung, Konflikte |
| **Stress-Management** | Pausen, Sport, Meditation, Zeitplanung, Gespräche | Gesundheit, Produktivität | Zeit, Akzeptanz im Betrieb |
| **Suche nach einem Arbeitsplatz** | Stellenportale, Kontakte und Netzwerke, Arbeitsagentur, Initiativbewerbung, Jobmessen | große Auswahl, persönlicher Kontakt | Konkurrenz, Zeitaufwand |
| **Müllvermeidung** | Mehrweg, Unverpackt-Laden, Reparieren, Second-Hand, Leihen und Teilen | Umwelt, Geld sparen | Aufwand, höhere Preise |
| **Finanzielle Absicherung im Alter** | gesetzliche Rente, Betriebsrente, Sparen, Aktien und Fonds, Immobilie | Sicherheit, Unabhängigkeit | Risiko, Inflation |
| **Haustiere** | Hund, Katze, Kleintiere, Fische | Gesellschaft, Bewegung | Kosten, Urlaub, Allergien |

Source for the titles: the published task list at [GradGermany](https://www.gradgermany.com/goethe-exam-preparation) and Goethe's two Modellsätze.

## 11. Sprechen Teil 2: the discussion

Five minutes, one yes/no question, four keyword prompts. You score on reacting to your partner and keeping the talk moving, and the card requires you to end by saying whether you are dafür or dagegen. You do not have to agree with each other.

### The R-A-F turn

Build every turn from three parts, about 20–30 seconds in total:

1. **Reagieren** — react to what your partner just said: agree, partly agree or disagree.
2. **Argumentieren** — add one new argument with a reason or an example.
3. **Fragen** — hand the turn back with a question.

*Da hast du zwar recht, aber man darf nicht vergessen, dass Noten auch motivieren können. Ich habe selbst erlebt, dass ich vor Prüfungen am meisten gelernt habe. Wie siehst du das?*

### The five minutes

1. **Open** — volunteer to start: the question, your position, one reason, a question to your partner.
2. **Three or four R-A-F rounds** — use the four prompts on the card as your agenda.
3. **New aspect** when it stalls (station 11).
4. **Summary** when the examiner signals the end (station 12): dafür or dagegen, and why.

If you both agree, go deeper instead of going quiet: *Ich bin auch dafür, aber nur unter der Bedingung, dass …* or *Kritiker würden jetzt einwenden, dass …*

### The 12 stations (Palace D)

| Station | Phrases |
| --- | --- |
| 1 Eröffnen | Sollen wir anfangen? Wir diskutieren die Frage, ob … · Ich fange einfach mal an: Ich bin eher dafür / dagegen, weil … |
| 2 Meinung äußern | Ich bin der Meinung, dass … · Ich bin klar dafür / dagegen, dass … · Für mich steht fest, dass … · Ich halte es für sinnvoll / problematisch, … zu … |
| 3 Begründen | Mein wichtigstes Argument ist, dass … · Das liegt vor allem daran, dass … · Der Grund dafür ist ganz einfach: … |
| 4 Beispiel geben | Ein gutes Beispiel dafür ist … · Ich habe selbst erlebt, dass … · Nehmen wir zum Beispiel … |
| 5 Nach der Meinung fragen | Wie siehst du das? · Was hältst du davon? · Bist du da anderer Meinung? · Was würdest du an meiner Stelle tun? |
| 6 Zustimmen und ergänzen | Da hast du völlig recht. · Genau das wollte ich auch sagen. · Da stimme ich dir zu, und ich würde noch ergänzen, dass … |
| 7 Teilweise zustimmen | Da hast du zwar recht, aber … · Im Prinzip ja, allerdings … · Das stimmt teilweise, aber man muss auch bedenken, dass … |
| 8 Widersprechen | Da bin ich anderer Meinung. · Das sehe ich etwas anders: … · Ich verstehe dein Argument, aber ich glaube nicht, dass … · Ja, aber was ist mit …? |
| 9 Nachfragen | Wie meinst du das genau? · Habe ich dich richtig verstanden, dass …? · Kannst du ein Beispiel nennen? |
| 10 Zeit gewinnen | Hm, das ist eine gute Frage. · Lass mich kurz überlegen … · Darüber habe ich ehrlich gesagt noch nicht nachgedacht, aber … |
| 11 Einbringen, zurückführen | Darf ich kurz etwas dazu sagen? · Entschuldige, wenn ich dich kurz unterbreche, aber … · Um noch einmal auf … zurückzukommen: … · Ein Punkt, über den wir noch nicht gesprochen haben, ist … |
| 12 Zusammenfassen | Zusammenfassend bin ich nach wie vor dafür / dagegen, weil … · Auch wenn mich dein Argument zu … überzeugt hat, bin ich insgesamt eher dafür / dagegen. · Wir sind uns also einig, dass …, aber bei … sehen wir das unterschiedlich. |

**Extra range for B2:** *Stell dir vor, … würde … Was wäre dann?* · *Das hängt davon ab, ob …* · *Unter bestimmten Bedingungen ja, zum Beispiel wenn …* · *Kritiker würden jetzt einwenden, dass …*

### du or Sie

Many candidates say du to each other and Sie to the examiners; the register is scored, so pick one form for your partner in the first seconds and keep it.

| du | Sie |
| --- | --- |
| Wie siehst du das? | Wie sehen Sie das? |
| Was hältst du davon? | Was halten Sie davon? |
| Da hast du recht. | Da haben Sie recht. |
| Ich stimme dir zu. | Ich stimme Ihnen zu. |
| Ich verstehe dein Argument. | Ich verstehe Ihr Argument. |
| Habe ich dich richtig verstanden? | Habe ich Sie richtig verstanden? |
| Entschuldige, wenn ich dich unterbreche. | Entschuldigen Sie, wenn ich Sie unterbreche. |
| Stell dir vor … | Stellen Sie sich vor … |
| Lass mich kurz überlegen. | Lassen Sie mich kurz überlegen. |

### The Argument-Uhr: 12 directions for arguments

In the preparation room, go once round the clock for the discussion question. Mark three or four hours that support your side and one or two your partner will probably use, so you can answer them.

| Hour | Category | Ready sentences |
| --- | --- | --- |
| 12 | Gesundheit | Das wirkt sich positiv / negativ auf die Gesundheit aus. · Auf Dauer ist das schädlich für … |
| 1 | Umwelt und Klima | Das schont die Umwelt. · Dadurch wird weniger CO₂ ausgestoßen. · Das belastet die Umwelt. |
| 2 | Geld und Kosten | Das ist mit hohen Kosten verbunden. · Damit spart man auf Dauer viel Geld. · Wer soll das bezahlen? |
| 3 | Zeit | Dadurch spart man viel Zeit. · Das ist sehr zeitaufwendig. |
| 4 | Freiheit | Jeder sollte selbst entscheiden dürfen, ob … · Das schränkt die persönliche Freiheit ein. |
| 5 | Gerechtigkeit | Das wäre ungerecht gegenüber … · Nicht alle können sich das leisten. |
| 6 | Sicherheit | Das erhöht die Sicherheit. · Das birgt Risiken, vor allem für … |
| 7 | Gemeinschaft | Das stärkt den Zusammenhalt. · Dabei geht der persönliche Kontakt verloren. |
| 8 | Bildung und Entwicklung | Dabei lernt man, Verantwortung zu übernehmen. · Das fördert die Selbstständigkeit. |
| 9 | Wirtschaft und Arbeit | Das schafft neue Arbeitsplätze. · Dadurch könnten Arbeitsplätze verloren gehen. |
| 10 | Kultur und Tradition | Das gehört zu unserer Kultur. · Traditionen sollten erhalten bleiben. |
| 11 | Umsetzbarkeit und Kontrolle | Wie soll man das kontrollieren? · In der Praxis ist das schwer umzusetzen. |

### Two model dialogues

The numbers in brackets are the stations used, and *Uhr* marks an hour of the Argument-Uhr. Practise each side with your voice AI.

**D-M1 · Sollten Flugreisen teurer werden?**

- **A:** Sollen wir anfangen? Wir diskutieren die Frage, ob Fliegen teurer werden sollte. Ich bin eher dafür, weil Flugzeuge sehr viel CO₂ ausstoßen und Billigflüge viele Menschen dazu verleiten, für ein Wochenende nach Barcelona zu fliegen. Wie siehst du das? \[1, 2, 3, 5\]
- **B:** Ich verstehe dein Argument, aber ich sehe das etwas anders. Wenn Fliegen teurer wird, können sich nur noch reiche Menschen Reisen leisten. Das finde ich ungerecht, denn Reisen erweitert den Horizont. \[8, Uhr 5\]
- **A:** Da hast du zwar recht, aber man könnte ja zwischen Kurzstrecken und Langstrecken unterscheiden. Für Strecken unter 500 Kilometern gibt es oft gute Zugverbindungen. \[7\]
- **B:** Das stimmt teilweise, aber Zugfahren ist in Deutschland oft teurer als Fliegen und dauert länger. Außerdem sind die Züge häufig verspätet. \[7, Uhr 2, Uhr 3\]
- **A:** Genau das ist doch das Problem! Deshalb sollte man mit dem Geld aus einer höheren Flugsteuer die Bahn ausbauen. Was hältst du davon? \[6, 5\]
- **B:** Das klingt sinnvoll, wenn das Geld wirklich dort ankommt. Aber was ist mit Menschen, deren Familie im Ausland lebt? Sie müssen ja fliegen, wenn sie ihre Eltern besuchen wollen. \[7, 8\]
- **A:** Das ist ein wichtiger Punkt, darüber habe ich noch nicht nachgedacht. Vielleicht könnte man für solche Fälle eine Ausnahme machen, zum Beispiel ein oder zwei Flüge pro Jahr zum normalen Preis. \[10\]
- **B:** Das wäre eine Möglichkeit, aber wie soll man das kontrollieren? Das wäre doch ein riesiger bürokratischer Aufwand. \[Uhr 11\]
- **A:** Da muss ich dir recht geben, die Umsetzung wäre nicht einfach. Trotzdem sollten wir etwas tun, denn der Klimawandel betrifft uns alle. \[6, Uhr 1\]
- *Prüferin: Bitte kommen Sie zum Schluss.*
- **A:** Zusammenfassend bin ich nach wie vor dafür, dass Kurzstreckenflüge teurer werden, weil die Bahn dafür eine echte Alternative ist. Bei Langstreckenflügen hat mich dein Argument mit den Familien im Ausland aber nachdenklich gemacht. \[12\]
- **B:** Und ich bin insgesamt eher dagegen, Fliegen generell teurer zu machen. Eine moderate Steuer auf Kurzstrecken fände ich aber akzeptabel, wenn das Geld in die Bahn fließt. \[12\]

**D-M2 · Sollen Noten abgeschafft werden?**

- **A:** Wollen wir anfangen? Wir sollen darüber diskutieren, ob Noten abgeschafft werden sollten. Was meinst du dazu? \[1, 5\]
- **B:** Ich bin ehrlich gesagt dagegen. Noten sind zwar nicht perfekt, aber sie zeigen Schülern und Eltern schnell, wo man steht. \[2, 3\]
- **A:** Das sehe ich etwas anders. Eine Note sagt nur, wie gut jemand an einem bestimmten Tag war, aber nicht, was er wirklich kann oder wo er sich verbessern muss. \[8\]
- **B:** Da hast du teilweise recht. Aber wie sollen Universitäten oder Arbeitgeber dann entscheiden, wen sie nehmen? Ohne Noten wäre das doch viel schwieriger. \[7, 5\]
- **A:** Gute Frage. Ich könnte mir vorstellen, dass Lehrkräfte stattdessen ausführliche Berichte schreiben. In manchen Ländern, zum Beispiel in Skandinavien, bekommen jüngere Kinder ja auch keine Noten. \[10, 4\]
- **B:** Das klingt gut, aber das bedeutet für die Lehrkräfte viel mehr Arbeit. Sie haben schon jetzt kaum Zeit. \[7, Uhr 3\]
- **A:** Das stimmt, dafür würde man mehr Personal brauchen. Aber ich glaube, dass Kinder ohne Notendruck mit mehr Freude lernen würden. Viele haben ja richtig Angst vor Prüfungen. \[6, Uhr 12\]
- **B:** Ein gewisser Druck kann aber auch motivieren. Ich weiß von mir selbst, dass ich ohne Noten wahrscheinlich weniger gelernt hätte. \[8, 4\]
- **A:** Das ist ein interessanter Punkt. Vielleicht liegt die Lösung in der Mitte: keine Noten in der Grundschule, aber ab einem bestimmten Alter schon. Was meinst du? \[11, 5\]
- **B:** Damit könnte ich gut leben. Dann bleibt für die Kleinen mehr Zeit zum Ausprobieren, und später gibt es trotzdem eine klare Bewertung. \[6\]
- **A:** Zusammenfassend bin ich dafür, Noten zumindest in der Grundschule abzuschaffen, weil Kinder ohne Druck mit mehr Freude lernen. \[12\]
- **B:** Ich bleibe insgesamt eher dagegen, denn ältere Schüler brauchen eine klare Rückmeldung. Für die Grundschule hast du mich aber überzeugt. \[12\]

### Discussion bank: D1–D20

Questions marked (published) appear in Goethe-style materials. The keywords are starting points; find more with the Argument-Uhr.

| # | Question | Pro | Contra |
| --- | --- | --- | --- |
| D1 | Sollten Flugreisen teurer werden? | Klimaschutz, Bahn stärken | ungerecht für Ärmere, Familien im Ausland |
| D2 | Sollen Noten abgeschafft werden? (published) | weniger Druck, individuelle Rückmeldung | Vergleichbarkeit, Motivation |
| D3 | Sollten Smartphones an Schulen verboten werden? | Konzentration, weniger Cybermobbing | Erreichbarkeit, Medienkompetenz |
| D4 | Sollte Homeoffice ein Recht für alle sein? | Zeit sparen, Vereinbarkeit | Isolation, nicht in allen Berufen möglich |
| D5 | Sollte die Vier-Tage-Woche eingeführt werden? | Erholung, Produktivität | Fachkräftemangel, lange Arbeitstage |
| D6 | Sollten Innenstädte autofrei sein? | saubere Luft, Lebensqualität | Erreichbarkeit, Einzelhandel |
| D7 | Sollten Bus und Bahn kostenlos sein? | Umwelt, soziale Teilhabe | Finanzierung, überfüllte Züge |
| D8 | Sollte es an allen Schulen Schuluniformen geben? (published) | Gemeinschaft, weniger Markendruck | Individualität, Kosten |
| D9 | Sollten Kinder im Kindergarten schon am Computer spielen? (published) | frühe Medienkompetenz | Bewegungsmangel, Abhängigkeit |
| D10 | Wahlrecht für Jugendliche? (published) | ihre Zukunft, politisches Interesse | Reife, Beeinflussbarkeit |
| D11 | Sollen Studierende ihre Professorinnen und Professoren beurteilen? (Modellsatz) | Collect your own after Mock 1 | – |
| D12 | Funktioniert ein Leben als globaler Nomade? (published) | Freiheit, Erfahrungen | Einsamkeit, fehlende Heimat |
| D13 | Ist es sinnvoll, dass Studierende in Vorlesungen Handys benutzen? (published) | Recherche, digitale Notizen | Ablenkung, Störung |
| D14 | Sollte Fleisch teurer werden? | Tierwohl, Klima | Preis für Familien, Freiheit |
| D15 | Sollten Plastikverpackungen verboten werden? | weniger Müll, Schutz der Meere | Hygiene, Haltbarkeit |
| D16 | Sollte ein soziales Pflichtjahr eingeführt werden? | Zusammenhalt, Hilfe in der Pflege | Zwang, späterer Berufsstart |
| D17 | Sollte das Bargeld abgeschafft werden? | bequem, weniger Schwarzarbeit | Datenschutz, ältere Menschen |
| D18 | Sollte KI in Schule und Studium erlaubt sein? | Effizienz, Zukunftskompetenz | Täuschung, eigenes Denken |
| D19 | Sollten soziale Netzwerke erst ab 16 erlaubt sein? | Schutz, Konzentration | schwer zu kontrollieren, Ausgrenzung |
| D20 | Sollte Werbung für ungesunde Lebensmittel verboten werden? | Gesundheit der Kinder | Freiheit, Wirtschaft |

## 12. Personal anchors

These sentences about your own life slot into many topics and give your posts and talks authentic examples, which raters remember. Adjust any detail that does not fit, and keep every one true.

**The warm-up (about one minute, not graded):** *Ich heiße Thejus. Ich habe in Frankreich promoviert und danach in Deutschland in der Forschung gearbeitet. Zurzeit mache ich eine Weiterbildung in Bioinformatik und Biostatistik, und ich lerne Deutsch, weil ich in Deutschland arbeiten möchte.*

| Anchor | Meaning | Fits topics such as |
| --- | --- | --- |
| Ich habe in Frankreich in Astrochemie promoviert und danach in Deutschland in der Forschung gearbeitet. | I did my PhD in astrochemistry in France, then worked in research in Germany. | Arbeit, Bildung, Leben im Ausland |
| In meiner Forschung habe ich marine Ökosysteme modelliert, deshalb liegt mir der Schutz der Meere besonders am Herzen. | I modelled marine ecosystems, so protecting the oceans matters a lot to me. | Umwelt, Klima, Plastik, Müllvermeidung |
| Zurzeit mache ich eine Weiterbildung in Bioinformatik und Biostatistik, um mich beruflich neu zu orientieren. | I am retraining to reorient my career. | Weiterbildung, lebenslanges Lernen, Arbeitsmodelle |
| Ich suche gerade eine Stelle im Bereich Datenanalyse und maschinelles Lernen. | I am looking for a job in data analysis and machine learning. | Suche nach einem Arbeitsplatz, Digitalisierung, KI |
| Aus eigener Erfahrung weiß ich, dass es anstrengend ist, noch einmal etwas ganz Neues anzufangen – aber es lohnt sich. | I know from experience that starting something new is hard but worth it. | Weiterbildung, Sprachen lernen, Stress |
| Als ich nach Deutschland gezogen bin, musste ich mich an vieles gewöhnen: an die Sprache, an die Bürokratie und an eine andere Mentalität. | Moving to Germany meant getting used to many things. | Leben im Ausland, Wohnen, Integration |
| Ich habe in verschiedenen Ländern gelebt und dabei gelernt, wie unterschiedlich man dasselbe Problem sehen kann. | Living in several countries taught me how differently one problem can be seen. | Any comparison or home-country point |
| In der Wissenschaft lernt man, Behauptungen mit Daten zu überprüfen. Das versuche ich auch im Alltag. | Science teaches you to check claims against data; I do that in daily life too. | Medien, Falschmeldungen, KI |
| Deutsch lerne ich jeden Tag mit Videos auf YouTube und im Gespräch mit einer KI. | I learn German daily with YouTube videos and conversations with an AI. | Sprachen lernen, Mediennutzung, Digitalisierung |
| In meiner Freizeit beschäftige ich mich mit klassischer Sanskrit-Literatur und übersetze gerade einen alten Text ins Englische. | Besides work, I study classical Sanskrit literature and am translating an old text into English. | Freizeitgestaltung, Kultur, Stress-Management |

**How to use them:** in Schreiben, an anchor turns a general point into evidence (*Ich habe selbst die Erfahrung gemacht, dass …*). In the Vortrag, one anchor in the introduction answers *Warum haben Sie dieses Thema gewählt?* before anyone asks.

## 13. Grammar behind the templates

Eighteen points cover every structure in your frames. G1, G2, G4 and G11 cause most B1-level errors, so they come first in the plan; G18 is for recognition only.

### G1 · Word order: three classes of connectors

| Class | Words | What happens | Example |
| --- | --- | --- | --- |
| Position 0 | und, aber, oder, denn, sondern, doch | Nothing changes | Homeoffice spart Zeit, aber es macht manche Menschen einsam. |
| Position 1 | deshalb, deswegen, daher, trotzdem, dennoch, außerdem, zudem, darüber hinaus, folglich, somit, allerdings, jedoch, stattdessen, sonst, zum einen, zum anderen, einerseits, andererseits, zwar | The verb comes next, then the subject | Die Mieten steigen. Deshalb ziehen viele Familien aufs Land. |
| Verb last | weil, da, dass, ob, obwohl, wenn, falls, als, während, nachdem, bevor, seitdem, sodass, damit, indem, ohne dass, je | The conjugated verb goes to the end | Viele arbeiten zu Hause, weil sie keine Zeit im Stau verlieren wollen. |

- When the subordinate clause comes first, the main clause starts with its verb: *Weil sie Zeit sparen wollen, arbeiten viele zu Hause.* (verb, comma, verb)
- *jedoch* and *allerdings* can also stand inside the clause: *Das Angebot ist jedoch teuer.* *nämlich* never stands first: *Ich bin dagegen. Es ist nämlich zu teuer.*
- Error: ✗ *Deshalb viele Familien ziehen aufs Land.* → ✓ *Deshalb ziehen viele Familien aufs Land.*

### G2 · Subordinate clauses I

| Word | Meaning | Example |
| --- | --- | --- |
| dass | that | Ich glaube nicht, dass ein Verbot hilft. |
| ob | whether | Es ist unklar, ob das funktioniert. |
| weil | because (answers warum) | Viele fahren Rad, weil es gesund ist. |
| da | since, as (a known reason, often first) | Da die Preise steigen, sparen viele Menschen. |
| obwohl | although | Viele fahren Auto, obwohl der Bus vor der Tür hält. |
| wenn / falls | if, whenever / in case | Falls der Zug ausfällt, nehme ich ein Taxi. |
| als | when (one event in the past) | Als ich nach Deutschland kam, sprach ich kaum Deutsch. |

- Modal verbs and the Perfekt: the conjugated verb is last — *…, weil man Zeit sparen kann.* · *…, weil ich die Frist übersehen habe.* Separable verbs join up: *…, dass ich die Arbeit nachhole.*
- Error: ✗ *…, weil ich habe keine Zeit.* → ✓ *…, weil ich keine Zeit habe.*

### G3 · Subordinate clauses II: purpose, means, result, contrast

| Structure | Example |
| --- | --- |
| um … zu (same subject) | Ich lerne jeden Tag, um die Prüfung zu bestehen. |
| damit (different subject) | Ich erkläre es noch einmal, damit alle es verstehen. |
| indem (by doing) | Man spart Energie, indem man weniger heizt. |
| sodass (result) | Der Zug hatte Verspätung, sodass ich den Termin verpasst habe. |
| statt … zu / ohne … zu | Statt das Auto zu nehmen, fahre ich Rad. · Viele kaufen online ein, ohne über die Folgen nachzudenken. |
| während (while, whereas) | Während Homeoffice Zeit spart, fehlt der Kontakt zu den Kollegen. |
| je … desto | Je mehr Menschen Rad fahren, desto weniger Staus gibt es. |
| seitdem | Seitdem ich im Homeoffice arbeite, habe ich mehr Zeit. |

- *je*-clause: verb last; then *desto* + comparative + verb + subject.
- Error: ✗ *Ich lerne, um ich die Prüfung bestehe.* → ✓ *Ich lerne, um die Prüfung zu bestehen.*

### G4 · Konjunktiv II: forms

- Most verbs: **würde + infinitive** — *ich würde kaufen, wir würden fahren.*
- Learn these own forms: sein → **wäre** · haben → **hätte** · können → **könnte** · müssen → **müsste** · sollen → **sollte** · dürfen → **dürfte** · wollen → **wollte** · werden → **würde** · es gibt → **es gäbe** · kommen → **käme** · finden → **fände** · wissen → **wüsste** · lassen → **ließe**
- Endings: ich wäre, du wärst, er wäre, wir wären, ihr wärt, sie wären.
- Past: **hätte / wäre + Partizip II** — *Ohne Noten hätte ich weniger gelernt.* · *Wäre ich früher losgefahren, wäre ich pünktlich gewesen.* With a modal verb: *Ich hätte Sie früher informieren sollen.*

### G5 · Konjunktiv II: uses

| Use | Examples |
| --- | --- |
| Asking politely | Könnten Sie mir bitte mitteilen, …? · Wäre es möglich, …? · Ich hätte eine Frage. · Ich wäre Ihnen dankbar, wenn … |
| Suggesting | Man könnte … · Eine Alternative wäre, … zu … · Es wäre sinnvoll, … zu … |
| Wishing | Es wäre wünschenswert, wenn mehr Firmen Teilzeit anbieten würden. |
| Unreal condition | Wenn Busse häufiger fahren würden, würden mehr Menschen das Auto stehen lassen. |
| Regret | Ich hätte Sie früher informieren sollen. |
| Condition without wenn (C1 touch) | Sollte Ihnen der Termin nicht passen, finden wir einen anderen. |

### G6 · Passive

**werden + Partizip II**; name the doer only if needed, with *von* + Dativ.

| Form | Example |
| --- | --- |
| Präsens | Neue Radwege werden gebaut. |
| Präteritum | Das Gesetz wurde 2023 eingeführt. |
| Perfekt | Das Problem ist gelöst worden. |
| With a modal verb | Plastiktüten sollten verboten werden. |
| In a subordinate clause | …, weil sie ständig unterbrochen werden. |
| Zustandspassiv (a resulting state) | Das Geschäft ist geschlossen. |

Error: ✗ *Das Problem ist gelöst geworden.* → ✓ *Das Problem ist gelöst worden.*

### G7 · Passive substitutes

- **sich lassen + infinitive** = can be done: *Das Problem lässt sich lösen.* · *Zusammenfassend lässt sich sagen, dass …*
- **sein + zu + infinitive** = can or must be done: *Das ist schwer umzusetzen.* · *Das ist kritisch zu bewerten.*
- **-bar adjectives:** lösbar, machbar, bezahlbar.
- **man:** *Man sollte das Problem schnell lösen.*

### G8 · Infinitive with zu

- After verbs (versuchen, vorhaben, anbieten, bitten, vorschlagen), nouns (die Möglichkeit, die Zeit, das Recht) and adjectives (es ist wichtig, schwer, sinnvoll): *Ich schlage vor, den Termin zu verschieben.* · *Es ist wichtig, regelmäßig Pausen zu machen.* · *Alle sollten das Recht haben, von zu Hause aus zu arbeiten.*
- Separable verbs take zu in the middle: abzuschaffen, einzuführen, nachzuholen, vorzustellen.
- No zu after modal verbs: *Ich kann morgen kommen.*
- A comma before the infinitive group is always correct.

### G9 · Relative clauses

|  | m | f | n | Plural |
| --- | --- | --- | --- | --- |
| Nom | der | die | das | die |
| Akk | den | die | das | die |
| Dat | dem | der | dem | denen |
| Gen | dessen | deren | dessen | deren |

- Gender and number come from the noun before; the case comes from the pronoun's role inside its own clause.
- With a preposition: *Das ist ein Thema, über das viel diskutiert wird.* · *die Firma, bei der ich arbeite* · *die Kollegen, mit denen ich arbeite*
- *was* after alles, etwas, nichts, das, and after a whole clause: *Alles, was man online kauft, muss verpackt werden.* · *Es kommen weniger Kunden, was für die Läden ein Problem ist.*
- *wer* = whoever: *Wer ausschließlich zu Hause arbeitet, fühlt sich schnell isoliert.*
- Error: ✗ *die Kollegen, die ich mit ihnen arbeite* → ✓ *die Kollegen, mit denen ich arbeite*

### G10 · da-/wo-words and the correlate

When a verb with a preposition is followed by a whole clause, the preposition becomes **da(r) + preposition**: *Ich bin dafür, dass …* · *Es kommt darauf an, ob …* · *Das hängt davon ab, wie …* · *Das liegt daran, dass …* · *Ich gehe davon aus, dass …* · *Das führt dazu, dass …* · *Ich freue mich darauf, … zu …*

- dar- before a vowel: darauf, darüber, daran, darin.
- Asking about things: Worauf? Wofür? Womit? About people: Auf wen? Mit wem?
- Error: ✗ *Ich freue mich auf, dass …* → ✓ *Ich freue mich darauf, dass …*

### G11 · Adjective endings

- **After der, dieser, jeder, alle** the article shows the case, so the adjective takes only -e or -en: *der wichtige Grund, die neuen Regeln, mit dem öffentlichen Nahverkehr.*
- **After ein, kein, mein, unser** the adjective shows the gender wherever the article has no ending: *ein wichtiger Grund, ein großes Problem.* Elsewhere -en or -e.
- **No article:** the adjective takes the article's ending: *frisches Obst, mit großem Interesse, aus gesundheitlichen Gründen, bei schlechtem Wetter.*

| After ein / kein | m | f | n | Plural (keine) |
| --- | --- | --- | --- | --- |
| Nom | ein großer Vorteil | eine gute Idee | ein großes Problem | keine neuen Regeln |
| Akk | einen großen Vorteil | eine gute Idee | ein großes Problem | keine neuen Regeln |
| Dat | einem großen Vorteil | einer guten Idee | einem großen Problem | keinen neuen Regeln |
| Gen | eines großen Vorteils | einer guten Idee | eines großen Problems | keiner neuen Regeln |

Chunks to learn by heart: aus meiner persönlichen Sicht · mit großem Interesse · ein großer Vorteil · einen großen Vorteil · eine sinnvolle Alternative · von großer Bedeutung · in der heutigen Zeit · die öffentlichen Verkehrsmittel · mit freundlichen Grüßen.

### G12 · n-declension, Herr / Herrn, Sie-forms

- Many masculine nouns for people add -(e)n in every case except the nominative singular: der Kunde → den, dem, des Kunden · der Kollege → den Kollegen · der Mensch → den Menschen · der Nachbar → den Nachbarn · der Student → den Studenten · der Herr → den, dem, des Herrn.
- Anrede (nominative): *Sehr geehrter Herr Ebert,* — but *an Herrn Ebert*, *mit Herrn Becker*, *Ich habe Herrn Krause angerufen.*
- Sie, Ihnen, Ihr and Ihre are always capitalised; *sich* stays small: *Bitte melden Sie sich bei mir.*

### G13 · Nominal style and genitive prepositions

| Verbal | Nominal |
| --- | --- |
| weil die Preise steigen | aufgrund der steigenden Preise |
| obwohl es viel kostet | trotz der hohen Kosten |
| wenn man das Auto nutzt | bei der Nutzung des Autos |
| um die Umwelt zu schützen | zum Schutz der Umwelt |
| während man arbeitet | während der Arbeit |

Genitive prepositions: aufgrund, wegen, trotz, während, innerhalb, außerhalb, statt, anstelle, infolge, bezüglich (letters); angesichts and hinsichtlich (C1). Use one or two per text, not everywhere.

### G14 · Participles as adjectives

- **Partizip I** (active, ongoing) = infinitive + d + ending: *die steigenden Mieten, der wachsende Verkehr, eine zunehmende Zahl.*
- **Partizip II** (passive or completed): *das geplante Verbot, die getroffene Entscheidung, gebrauchte Kleidung.*
- **Extended** (C1 style): *die in den letzten Jahren stark gestiegenen Mieten* = die Mieten, die in den letzten Jahren stark gestiegen sind. Use at most one short one per text.

### G15 · Two-part connectors

| Pair | Example |
| --- | --- |
| sowohl … als auch | Das ist sowohl gesünder als auch billiger. |
| weder … noch | Das ist weder sinnvoll noch bezahlbar. |
| nicht nur …, sondern auch | Man spart nicht nur Geld, sondern schont auch die Umwelt. |
| entweder … oder | Entweder handeln wir jetzt, oder es wird später teurer. |
| zwar …, aber | Zwar spart man Zeit, aber man ist oft allein. |
| einerseits …, andererseits | Einerseits ist das bequem, andererseits entsteht viel Müll. |

Word order: *zwar, einerseits, andererseits* and *entweder* at the start take the verb next; *sondern* and *aber* stand in position 0.

### G16 · Indirect questions

Question word or *ob*, verb at the end: *Ich möchte darlegen, wie ich dazu stehe.* · *Viele wissen, unter welchen Bedingungen Tiere leben.* · *Könnten Sie mir sagen, wann der Kurs beginnt?* · *Es ist fraglich, inwiefern ein Verbot hilft.* · *Ich frage mich, ob das gerecht ist.*

### G17 · Future, assumptions and modal particles (speaking)

- **werden + infinitive** for predictions: *In zehn Jahren werden die meisten Autos elektrisch fahren.* With *wohl* for assumptions: *Das wird wohl teuer werden.*
- Particles make speech sound natural: **ja** (we both know) — *Das ist ja das Problem.* · **doch** (emphasis; can sound impatient) — *Das ist doch klar!* · **eben / halt** (that's how it is) — *Das ist eben so.* · **eigentlich** — *Eigentlich bin ich dafür, aber …* · **mal** (softens) — *Lass uns mal überlegen.* · **schon** (concession) — *Das stimmt schon, aber …*

### G18 · Konjunktiv I (recognise only)

News and reports use it for reported speech: er sei, sie habe, es gebe, man müsse, er werde. *Der Minister sagte, das Gesetz sei notwendig* means he said so, not that it is confirmed. You need it for Lesen and Hören, not for your own texts.

## 14. Vocabulary bank

The full bank lives in its own tab: Wortschatz. It holds 35 daily batches, about 765 words, plus a 60-word B1 check, in the order of the plan in section 4.

- **B1 check (days 1–2):** 60 basics. Tick what you already use correctly, with article and plural; learn only the misses.
- **B2 core (W01–W31, days 1–32):** connectors, opinion and argument words, Nomen-Verb-Verbindungen, verbs with prepositions, formal work language, and two batches for each of the ten exam topic clusters.
- **C1 touch (W32–W35, days 33–37):** connectors, verbs and fixed expressions that lift a B2 text. Use at most one or two per text.

Every batch gives the article and plural or the verb's case and preposition, an English meaning and a short example. The tab opens with 25 worked picture hooks for the prefix-plus-root method. If you want the batches as flashcards, ask me for a CSV you can import into Anki.

## 15. AI practice, error log and exam day

Use a text chat to grade your writing and a voice AI such as Gemini Live for speaking: paste the prompt as text, then switch to voice. Treat AI scores as estimates; the corrections are what you keep.

### Six prompts to copy

**1 · Schreiben grader**

```
You are a strict examiner for the Goethe-Zertifikat B2, Schreiben. Grade my text with the official criteria Erfüllung, Kohärenz, Wortschatz and Strukturen, each A–E (Teil 1: 14/14/16/16 points; Teil 2: 10/10/10/10). Then: (1) list every error as wrong → correct, with the rule in one English sentence; (2) say which of the four task points are fully, partly or not covered; (3) return my text with minimal corrections, without rewriting my style; (4) suggest three B2 phrases that would raise my Wortschatz score, inside sentences that fit my text.
Task: [paste]
My text: [paste]
```

**2 · Vortrag partner and examiner (voice)**

```
Act as my partner and examiner in Goethe B2 Sprechen Teil 1. My topic: [topic], with the bullets [paste]. I will speak for about four minutes; do not interrupt. Then ask me one question as my partner (du) and one as the examiner (Sie), one at a time, and wait for each answer. Afterwards give feedback in English: were all three bullets covered and did I give a verdict, which connectors I used, my five most important grammar or vocabulary errors with corrections, and any pronunciation problems you noticed.
```

**3 · Discussion partner (voice)**

```
Play my partner in Goethe B2 Sprechen Teil 2. Question: [Frage]. Prompts: [Stichpunkte]. Take the opposite position to mine. Speak 2–4 sentences per turn at B2 level, react to my points, ask me questions and disagree politely at least twice. After about five minutes say „Bitte kommen Sie zum Schluss“ and let each of us summarise: dafür oder dagegen? Then give feedback in English on interaction, range and accuracy, with my five most important errors corrected.
```

**4 · Vocabulary drill**

```
Test me on these German words: [paste a batch]. Show me the English meaning; I answer with the German word including article and plural, or the verb with its preposition. Correct me. After every five words, ask me for one sentence with a word I got wrong.
```

**5 · Grammar drill**

```
Give me ten sentences to transform for this grammar point: [e.g. weil-Satz → aufgrund + Genitiv]. One at a time; wait for my answer; correct it with a one-line rule.
```

**6 · Frame drill**

```
Give me five random Goethe B2 forum topics, each with four content points. For each, I will write only my Einleitung and Meinung paragraphs using my templates. Correct the grammar and tell me whether the content really answers the point.
```

From every Hören or Lesen session, add five useful words with article and plural to the word list in your error log.

### The error log

Keep one table, add every corrected error, and each Sunday rewrite your five most frequent error types as correct sentences. Three typical first entries:

| Date | Wrong | Right | Rule | Type |
| --- | --- | --- | --- | --- |
| 14.10. | Deshalb viele Familien ziehen aufs Land. | Deshalb ziehen viele Familien aufs Land. | Position-1 connector: the verb comes next | Wortstellung |
| 15.10. | mit großer Interesse | mit großem Interesse | das Interesse; no article, so the adjective takes -em | Endung |
| 16.10. | Ich freue mich auf, dass … | Ich freue mich darauf, dass … | Preposition before a clause becomes da(r)- | Präposition |

### Exam day

**The day before:** walk the four palaces once and learn nothing new. Check the address and start time. Pack your photo ID and two blue or black pens; phones and smartwatches stay off and away.

**Schreiben, 75 minutes**

| Minutes | What you do |
| --- | --- |
| 0–3 | Read both tasks. Start with Teil 1, which carries 60 of the 100 points. |
| 3–10 | Plan Teil 1: four points, keywords from the Argument-Uhr, frame variants. |
| 10–40 | Write Teil 1 directly on the answer sheet. |
| 40–48 | Check Teil 1 with the eight-point list in section 6. |
| 48–52 | Put the four points of Teil 2 in order. |
| 52–68 | Write Teil 2. |
| 68–75 | Check Anrede, Gruß, Sie-forms, Herrn, verb positions and length. |

**Sprechen preparation, 15 minutes:** 1 minute to choose the topic · 8 minutes of Vortrag notes on six lines · 5 minutes of discussion notes (your position, three hours of the Argument-Uhr, one example, the counter-argument you expect, your closing sentence) · 1 minute to read everything through.

**In the room**

1. Warm-up: say your three-sentence introduction from section 12.
2. Agree du or Sie with your partner and keep it.
3. While your partner speaks, note one detail for your question.
4. In the discussion, build every turn with R-A-F and finish with dafür or dagegen.
5. If you go blank, say a station-10 phrase, look at your next keyword and step to the next locus.

---

<!-- TAB 2 -->

# Wortschatz: 35 daily batches

Thirty-five batches of 16–25 words each, about 765 in total, plus a 60-word B1 check. They run in the order of the 58-day plan; batches W32–W35 are the C1 touch.

**Notation.** Nouns: article, then plural after the comma (– = no plural, Pl. = plural only). Verbs: a bar marks a separable prefix (*ab|lehnen*), "ist" marks a Perfekt with sein, and the case or preposition the verb takes. (C1) marks a stretch word inside a B2 batch.

**Daily routine for one batch (25 minutes).** Read each word aloud with its article. Build one gender-coloured image per noun and put it on an object in that cluster's palace room. Cover the German column and recall it from the English. Write five sentences with the five hardest words.

## Batch index

| Batch | Day | Theme | Level |
| --- | --- | --- | --- |
| B1-Check A, B | 1–2 | Argument basics, everyday verbs | B1 check |
| W01 | 1 | Konnektoren I: position 1 | B2 |
| W02 | 2 | Subjunktionen, zweiteilige Konnektoren | B2 |
| W03 | 3 | Meinung und Bewertung | B2 |
| W04 | 4 | Argumentieren: Nomen | B2 |
| W05 | 5 | Argumentieren: Verben | B2 |
| W06 | 6 | Bewertende Adjektive und Adverbien | B2 |
| W07 | 7 | Nomen-Verb-Verbindungen I: Meinung und Diskussion | B2 |
| W08 | 8 | Formelle Kommunikation im Beruf | B2 |
| W09 | 9 | Verben mit Präpositionen I: Akkusativ | B2 |
| W10 | 10 | Verben mit Präpositionen II: Dativ | B2 |
| W11 | 11 | Nomen-Verb-Verbindungen II: Handeln | B2 |
| W12 | 12 | Nomen-Verb-Verbindungen III: Beruf | B2 |
| W13–W14 | 13–14 | Arbeit und Beruf | B2 |
| W15–W16 | 15–16 | Umwelt und Klima | B2 |
| W17 | 17 | Verkehr und Mobilität | B2 |
| W18–W19 | 18–19 | Bildung und Lernen | B2 |
| W20–W21 | 20–21 | Digitalisierung und Medien | B2 |
| W22–W23 | 22–23 | Gesundheit und Ernährung | B2 |
| W24–W25 | 24–25 | Konsum, Geld und Wirtschaft | B2 |
| W26–W27 | 26–27 | Gesellschaft, Familie und Wohnen | B2 |
| W28 | 29 | Freizeit, Reisen und Kultur | B2 |
| W29 | 30 | Staat, Regeln und Politik | B2 |
| W30 | 31 | Präpositionen mit Genitiv, Nominalstil | B2 |
| W31 | 32 | Gesprächswörter für Sprechen | B2 |
| W32–W33 | 33–34 | C1 touch: Konnektoren, Verben | C1 |
| W34–W35 | 36–37 | C1 touch: Nomen, Wendungen | C1 |

## Picture hooks: prefix plus root

Twenty-five worked examples of the method in section 3. Make your own the same way: split the word, picture each part, colour the noun.

| Word | Image |
| --- | --- |
| die Auffassung (opinion) | You grab (auf-fassen) an opinion off a high shelf; it is red and burning. |
| der Einwand (objection) | A wall (Wand) is thrown in (ein) between two speakers; blue and frozen. |
| die Ursache (cause) | The original (Ur-) thing (Sache) that started it all: a caveman striking the first spark. |
| die Voraussetzung (prerequisite) | A stepping stone set (setzen) out (aus) in front (vor) of you before you can cross. |
| der Zusammenhang (connection) | Things hanging (hängen) together (zusammen) on one rope; blue, frozen in ice. |
| bei\|tragen (contribute) | You carry (tragen) one brick alongside (bei) the others to build a wall. |
| entlasten (relieve) | You take the load (Last) off (ent-) a tired donkey. |
| nachhaltig (sustainable) | A tree still holding (halten) the soil long after (nach) the storm. |
| überwiegen (outweigh) | One pan weighs (wiegen) over (über) the other and crashes down. |
| die Herausforderung (challenge) | A knight calls you out (heraus-fordern) to a duel; red, burning armour. |
| vor\|beugen (prevent) | You bend (beugen) in front (vor) of a falling vase and catch it. |
| ab\|lehnen (reject) | You lean (lehnen) away (ab) from an offer held out to you. |
| ein\|räumen (concede) | You make room (Raum) inside your argument for your partner's point. |
| vor\|schlagen (propose) | You strike (schlagen) a new idea onto the table in front (vor) of everyone. |
| um\|steigen auf (switch to) | You climb (steigen) round (um) from a car onto a bicycle. |
| der Aufwand (effort) | Walls (Wand) going up (auf) brick by brick: that takes effort. |
| der Engpass (bottleneck) | A narrow (eng) mountain pass where lorries get stuck. |
| die Nachfrage (demand) | A crowd keeps asking again (nach-fragen) at the counter. |
| der Wohlstand (prosperity) | A fat purse standing (Stand) comfortably (wohl) on its own. |
| die Wegwerfgesellschaft (throwaway society) | A whole society throws (werfen) things away (weg) out of the window. |
| der Fachkräftemangel (skills shortage) | An empty workshop: a lack (Mangel) of expert (Fach) forces (Kräfte). |
| die Chancengleichheit (equal opportunities) | Two runners at exactly the same (gleich) start line. |
| die Erreichbarkeit (being reachable) | Your phone ringing at midnight because you are reach-able (erreich-bar). |
| unverzichtbar (indispensable) | un-ver-zicht-bar: something you can never do without (verzichten). |
| auf der Hand liegen (be obvious) | The answer lies on your open palm; nobody can miss it. |

## B1-Check A: argument basics (day 1)

Tick what you already use correctly, with article and plural. Learn only what you miss.

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Meinung | -en | opinion | meiner Meinung nach |
| der Grund | Gründe | reason | aus diesem Grund |
| der Vorteil | -e | advantage | einen Vorteil haben |
| der Nachteil | -e | disadvantage | ein großer Nachteil |
| das Beispiel | -e | example | zum Beispiel |
| die Erfahrung | -en | experience | Erfahrungen sammeln |
| das Problem | -e | problem | ein Problem lösen |
| die Lösung | -en | solution | eine Lösung finden |
| die Möglichkeit | -en | possibility | die Möglichkeit haben, … zu … |
| die Gesellschaft | -en | society; company | in unserer Gesellschaft |
| die Umwelt | – | environment | die Umwelt schützen |
| die Zukunft | – | future | in Zukunft |
| die Entscheidung | -en | decision | eine Entscheidung treffen |
| der Unterschied | -e | difference | der Unterschied zwischen … |
| die Gefahr | -en | danger | in Gefahr sein |
| die Regel | -n | rule | sich an die Regeln halten |
| das Gesetz | -e | law | ein neues Gesetz |
| die Regierung | -en | government | die Regierung plant … |
| der Staat | -en | state | der Staat sollte … |
| die Steuer | -n | tax (das Steuer = steering wheel) | Steuern zahlen |
| die Kosten | Pl. | costs | die Kosten tragen |
| der Preis | -e | price; prize | die Preise steigen |
| das Verhalten | – | behaviour | umweltfreundliches Verhalten |
| die Ausbildung | -en | vocational training | eine Ausbildung machen |
| die Gesundheit | – | health | gut für die Gesundheit |
| die Freizeit | – | free time | in der Freizeit |
| der Verkehr | – | traffic | viel Verkehr |
| die Arbeitszeit | -en | working hours | flexible Arbeitszeiten |
| die Werbung | – | advertising | Werbung für … |
| das Angebot | -e | offer; range | ein großes Angebot an + Dativ |

## B1-Check B: everyday verbs and adjectives (day 2)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| sich interessieren | für + Akk | be interested in | Ich interessiere mich für Politik. |
| sich ärgern | über + Akk | be annoyed about | Ich ärgere mich über den Lärm. |
| sich kümmern | um + Akk | take care of | sich um die Kinder kümmern |
| teil\|nehmen | an + Dat | take part in | an einem Kurs teilnehmen |
| sich beschweren | über + Akk, bei + Dat | complain about / to | sich beim Chef beschweren |
| sich entscheiden | für / gegen + Akk | decide for / against | sich für das Fahrrad entscheiden |
| sich gewöhnen | an + Akk | get used to | sich an das Wetter gewöhnen |
| ab\|hängen | von + Dat | depend on | Das hängt vom Preis ab. |
| sich erinnern | an + Akk | remember | sich an etwas erinnern |
| warten | auf + Akk | wait for | auf den Bus warten |
| vergleichen | mit + Dat | compare with | Preise vergleichen |
| verbieten | jdm. etw. | forbid | Rauchen ist verboten. |
| erlauben | jdm. etw. | allow | Das ist nicht erlaubt. |
| verbessern | Akk | improve | die Situation verbessern |
| unterstützen | Akk | support | Familien unterstützen |
| schützen | vor + Dat | protect from | vor Gefahren schützen |
| sparen | Akk | save | Geld und Zeit sparen |
| verdienen | Akk | earn | gut verdienen |
| erreichen | Akk | reach, achieve | ein Ziel erreichen |
| (sich) entwickeln | Akk | develop | Die Stadt entwickelt sich. |
| (sich) verändern | Akk | change | Die Welt verändert sich. |
| nutzen / benutzen | Akk | use | das Internet nutzen |
| empfehlen | jdm. etw. (empfahl, empfohlen) | recommend | Ich empfehle dir … |
| behaupten | dass | claim | Viele behaupten, dass … |
| nützlich | adj | useful | ein nützliches Programm |
| schädlich | adj | harmful | schädlich für die Umwelt |
| notwendig | adj | necessary | Das ist nicht notwendig. |
| beliebt | adj | popular | sehr beliebt bei Jugendlichen |
| günstig | adj | cheap; favourable | ein günstiges Angebot |
| bequem | adj | comfortable, convenient | Online-Shopping ist bequem. |

## W01 · Konnektoren I: position 1, the verb comes next (day 1)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| deshalb / deswegen / daher / darum | Pos. 1 | therefore | Deshalb ziehen viele aufs Land. |
| folglich | Pos. 1 | consequently | Folglich steigen die Preise. |
| somit | Pos. 1 | thus, so | Somit ist das Problem gelöst. |
| infolgedessen | Pos. 1 (C1) | as a result | Infolgedessen kündigten viele. |
| trotzdem | Pos. 1 | nevertheless | Trotzdem bin ich dafür. |
| dennoch | Pos. 1 | nonetheless | Dennoch gibt es Nachteile. |
| außerdem | Pos. 1 | besides, moreover | Außerdem spart man Zeit. |
| zudem | Pos. 1 | in addition | Zudem ist es billiger. |
| darüber hinaus | Pos. 1 | furthermore | Darüber hinaus gibt es … |
| allerdings | Pos. 1 or middle | however; admittedly | Allerdings ist das teuer. |
| jedoch | Pos. 1 or middle | however | Das ist jedoch nicht alles. |
| hingegen / dagegen | Pos. 1 or middle | by contrast | Ältere Menschen hingegen … |
| stattdessen | Pos. 1 | instead | Stattdessen fahre ich Rad. |
| sonst / andernfalls | Pos. 1 | otherwise | Sonst wird es zu spät. |
| zunächst | Pos. 1 | first of all | Zunächst möchte ich … |
| anschließend | Pos. 1 | afterwards | Anschließend nenne ich … |
| schließlich | Pos. 1 | finally; after all | Schließlich muss jeder … |
| letztendlich | Pos. 1 | ultimately | Letztendlich entscheidet der Preis. |
| insgesamt | Pos. 1 | overall | Insgesamt überwiegen die Vorteile. |
| vielmehr | Pos. 1 | rather (correcting) | Das ist kein Luxus. Vielmehr ist es notwendig. |
| immerhin | Pos. 1 | at least, after all | Immerhin spart man Geld. |
| nämlich | never in position 1 | namely; you see | Es ist nämlich zu teuer. |

## W02 · Subjunktionen and two-part connectors (day 2)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| da | verb last | since, as | Da es regnet, bleibe ich zu Hause. |
| obwohl | verb last | although | obwohl es teuer ist |
| obgleich | verb last (C1) | although | obgleich viele dagegen sind |
| während | verb last | while; whereas | während die einen sparen, … |
| wohingegen | verb last (C1) | whereas | wohingegen Jüngere … |
| indem | verb last | by (doing) | indem man weniger heizt |
| sodass | verb last | so that (result) | sodass ich zu spät kam |
| damit | verb last | so that (purpose) | damit alle es verstehen |
| um … zu | infinitive | in order to | um Geld zu sparen |
| ohne … zu / ohne dass | infinitive / verb last | without (doing) | ohne nachzudenken |
| (an)statt … zu | infinitive | instead of (doing) | statt das Auto zu nehmen |
| falls | verb last | in case | falls der Zug ausfällt |
| sofern | verb last | provided that | sofern es möglich ist |
| solange | verb last | as long as | solange es nicht regnet |
| sobald | verb last | as soon as | sobald ich Zeit habe |
| nachdem | verb last | after | nachdem ich angekommen war |
| bevor | verb last | before | bevor man entscheidet |
| seitdem | verb last | since (time) | seitdem ich hier wohne |
| je … desto | verb last, then inversion | the more … the more | Je mehr man übt, desto sicherer wird man. |
| sowohl … als auch | pair | both … and | sowohl Kinder als auch Eltern |
| weder … noch | pair | neither … nor | weder billig noch gesund |
| nicht nur …, sondern auch | pair | not only … but also | nicht nur günstig, sondern auch praktisch |
| zwar …, aber | pair | admittedly … but | Zwar ist es bequem, aber … |
| einerseits …, andererseits | pair | on the one hand … on the other | Einerseits …, andererseits … |
| inwiefern | verb last | to what extent | Es ist fraglich, inwiefern das hilft. |

## W03 · Meinung und Bewertung (day 3)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Ansicht | -en | view | meiner Ansicht nach |
| die Auffassung | -en | opinion | die Auffassung vertreten |
| der Standpunkt | -e | standpoint | einen Standpunkt vertreten |
| die Sichtweise | -n | perspective | eine andere Sichtweise haben |
| die Überzeugung | -en | conviction | der festen Überzeugung sein |
| die Einstellung | -en, zu + Dat | attitude | eine positive Einstellung zur Arbeit |
| der Einwand | Einwände | objection | einen Einwand erheben |
| das Argument | -e | argument | ein überzeugendes Argument |
| die Behauptung | -en | claim | eine gewagte Behauptung |
| die Kritik | -en, an + Dat | criticism | Kritik an der Regierung |
| befürworten | Akk | support, advocate | einen Vorschlag befürworten |
| ab\|lehnen | Akk | reject | einen Vorschlag ablehnen |
| bezweifeln | Akk / dass | doubt | Ich bezweifle, dass … |
| ein\|wenden | dass (wandte ein, eingewandt) | object | Man könnte einwenden, dass … |
| betonen | Akk / dass | emphasise | Ich möchte betonen, dass … |
| hervor\|heben | Akk (hob hervor, hervorgehoben) | highlight | einen Punkt hervorheben |
| überzeugen | jdn. von + Dat | convince | Das hat mich überzeugt. |
| zu\|stimmen | + Dat | agree with | Ich stimme dir zu. |
| widersprechen | + Dat | contradict | Da muss ich dir widersprechen. |
| umstritten | adj | controversial | ein umstrittenes Thema |
| fragwürdig | adj | questionable | eine fragwürdige Methode |
| berechtigt | adj | justified | eine berechtigte Frage |
| eindeutig | adj | clear, unambiguous | eine eindeutige Antwort |
| nachvollziehbar | adj | understandable | Das ist gut nachvollziehbar. |

## W04 · Argumentieren: Nomen (day 4)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Ursache | -n | cause | die Ursache des Problems |
| die Folge | -n | consequence | zur Folge haben |
| die Auswirkung | -en, auf + Akk | effect, impact | Auswirkungen auf die Umwelt |
| der Einfluss | Einflüsse, auf + Akk | influence | großen Einfluss auf … haben |
| der Aspekt | -e | aspect | ein wichtiger Aspekt |
| der Gesichtspunkt | -e | point of view | unter diesem Gesichtspunkt |
| die Voraussetzung | -en | prerequisite | unter der Voraussetzung, dass … |
| die Bedingung | -en | condition | unter einer Bedingung |
| der Zusammenhang | Zusammenhänge | connection | in diesem Zusammenhang |
| die Entwicklung | -en | development | eine positive Entwicklung |
| die Tendenz | -en | tendency, trend | mit steigender Tendenz |
| die Maßnahme | -n | measure | Maßnahmen ergreifen |
| der Lösungsansatz | Lösungsansätze | approach to a solution | ein neuer Lösungsansatz |
| die Herausforderung | -en | challenge | eine große Herausforderung |
| das Risiko | Risiken | risk | ein Risiko eingehen |
| die Chance | -n | chance, opportunity | eine Chance nutzen |
| die Bedeutung | -en | importance; meaning | von großer Bedeutung |
| der Nutzen | – | benefit | der Nutzen für alle |
| der Aufwand | – | effort, expense | mit viel Aufwand |
| das Ausmaß | -e | extent, scale | das Ausmaß der Schäden |
| die Ausnahme | -n | exception | eine Ausnahme machen |
| der Kompromiss | -e | compromise | einen Kompromiss finden |
| die Verantwortung | – | responsibility | Verantwortung tragen |
| der Fortschritt | -e | progress | technischer Fortschritt |
| die Hinsicht | – | respect | in dieser Hinsicht |

## W05 · Argumentieren: Verben (day 5)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| beeinflussen | Akk | influence | die Meinung beeinflussen |
| sich aus\|wirken | auf + Akk | have an effect on | Das wirkt sich auf die Gesundheit aus. |
| führen | zu + Dat | lead to | Das führt zu Problemen. |
| verursachen | Akk | cause (ver- + Ursache) | Staus verursachen |
| ermöglichen | Akk | make possible (er- + möglich) | flexibles Arbeiten ermöglichen |
| verhindern | Akk | prevent | Unfälle verhindern |
| fördern | Akk | promote, support | junge Talente fördern |
| bewirken | Akk | bring about | eine Veränderung bewirken |
| verringern / reduzieren | Akk | reduce (ver- + gering) | den Verbrauch verringern |
| erhöhen / steigern | Akk | increase (er- + hoch) | die Preise erhöhen |
| steigen | ist gestiegen | rise | Die Mieten sind gestiegen. |
| sinken | ist gesunken | fall | Die Zahlen sinken. |
| zu\|nehmen / ab\|nehmen | – | increase / decrease | Der Verkehr nimmt zu. |
| betreffen | Akk (betraf, betroffen) | concern, affect | Das betrifft uns alle. |
| sich lohnen | – | be worth it | Das lohnt sich. |
| aus\|reichen | – | be enough | Das Geld reicht nicht aus. |
| bei\|tragen | zu + Dat | contribute to | zum Klimaschutz beitragen |
| berücksichtigen | Akk | take into account (be- + Rücksicht) | alle Interessen berücksichtigen |
| entstehen | ist entstanden | arise (ent- + stehen) | Dabei entstehen Kosten. |
| sich ergeben | aus + Dat | result from | Daraus ergibt sich ein Problem. |
| bestehen | aus / in + Dat | consist of / in | Der Vorteil besteht darin, dass … |
| dienen | + Dat / zu + Dat | serve | Das dient der Sicherheit. |
| verfügen | über + Akk | have at one's disposal | über genug Zeit verfügen |
| ersetzen | Akk | replace | Maschinen ersetzen Menschen. |
| gewährleisten | Akk (C1) | guarantee, ensure | die Sicherheit gewährleisten |

## W06 · Bewertende Adjektive und Adverbien (day 6)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| sinnvoll | adj | sensible, meaningful | eine sinnvolle Lösung |
| nachhaltig | adj | sustainable; lasting | nachhaltig wirtschaften |
| wesentlich | adj | essential; considerably | wesentlich besser |
| entscheidend | adj | decisive, crucial | ein entscheidender Vorteil |
| erheblich | adj | considerable | erhebliche Kosten |
| deutlich | adj | clear(ly), significant(ly) | deutlich weniger |
| zunehmend | adv | increasingly | zunehmend wichtig |
| vermutlich | adv | presumably | Vermutlich wird es teurer. |
| offensichtlich | adj | obvious(ly) | ein offensichtlicher Fehler |
| zweifellos | adv | undoubtedly | Das ist zweifellos richtig. |
| angemessen | adj | appropriate | eine angemessene Bezahlung |
| unverzichtbar | adj | indispensable | heute unverzichtbar |
| bedenklich | adj | worrying | eine bedenkliche Entwicklung |
| vorteilhaft | adj | advantageous | für beide Seiten vorteilhaft |
| wirksam | adj | effective | eine wirksame Maßnahme |
| effizient | adj | efficient | effizient arbeiten |
| langfristig / kurzfristig | adj | long-term / short-term | langfristig denken |
| grundsätzlich | adv | in principle | Grundsätzlich bin ich dafür. |
| weitgehend | adv | largely | weitgehend unbekannt |
| ausschließlich | adv | exclusively | ausschließlich online |
| tatsächlich | adv | actually, indeed | Das ist tatsächlich so. |
| ständig | adv | constantly | ständig erreichbar |
| kaum | adv | hardly | Ich habe kaum Zeit. |
| durchaus | adv | quite, definitely | Das ist durchaus möglich. |
| bewusst | adj | conscious(ly) | bewusst einkaufen |

## W07 · Nomen-Verb-Verbindungen I: Meinung und Diskussion (day 7)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| eine Rolle spielen | bei + Dat / für + Akk | play a role | Geld spielt dabei eine große Rolle. |
| die Auffassung / den Standpunkt vertreten | dass | hold the view | Ich vertrete die Auffassung, dass … |
| Kritik üben | an + Dat | criticise | Viele üben Kritik an dem Gesetz. |
| infrage kommen | – | be an option | Das kommt für mich nicht infrage. |
| infrage stellen | Akk | call into question | Das stellt alles infrage. |
| zur Diskussion stehen | – | be under discussion | Das steht zur Diskussion. |
| zur Sprache bringen | Akk | bring up | ein Problem zur Sprache bringen |
| Stellung nehmen | zu + Dat | comment on | zu einer Frage Stellung nehmen |
| Bezug nehmen | auf + Akk | refer to | auf Ihre E-Mail Bezug nehmen |
| zum Ausdruck bringen | Akk | express | seine Meinung zum Ausdruck bringen |
| in Betracht ziehen | Akk | consider | eine Alternative in Betracht ziehen |
| in Erwägung ziehen | Akk (C1) | consider | einen Umzug in Erwägung ziehen |
| eine Frage stellen | – | ask a question | Darf ich eine Frage stellen? |
| eine Antwort geben | auf + Akk | give an answer | eine klare Antwort geben |
| recht haben / jdm. recht geben | – | be right / agree that someone is right | Da muss ich dir recht geben. |
| Bedenken äußern | gegen + Akk | voice concerns | Bedenken gegen den Plan äußern |
| den Eindruck haben | dass | have the impression | Ich habe den Eindruck, dass … |
| außer Acht lassen | Akk | disregard | Das darf man nicht außer Acht lassen. |

## W08 · Formelle Kommunikation im Beruf (day 8)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Anliegen | - | concern, request | ein Anliegen haben |
| die Anfrage | -n | enquiry | Ihre Anfrage vom 3. Mai |
| die Rückmeldung | -en | reply, feedback | um eine baldige Rückmeldung bitten |
| der Bescheid | -e | notice, word | Bescheid geben |
| die Absage | -n | cancellation, refusal | eine kurzfristige Absage |
| die Zusage | -n | acceptance, confirmation | eine feste Zusage |
| die Frist | -en | deadline | eine Frist einhalten |
| der Termin | -e | appointment | einen Termin vereinbaren |
| verschieben | Akk (verschob, verschoben) | postpone | den Termin auf Montag verschieben |
| ab\|sagen | Akk | cancel | ein Treffen absagen |
| mit\|teilen | jdm. etw. | inform | Leider muss ich Ihnen mitteilen, dass … |
| sich entschuldigen | für + Akk, bei + Dat | apologise | sich beim Chef entschuldigen |
| das Versäumnis | -se | omission | mein Versäumnis |
| verhindert sein | – | be unable to attend | Ich bin leider verhindert. |
| die Unannehmlichkeit | -en | inconvenience | für die Unannehmlichkeiten |
| das Verständnis | – | understanding | um Verständnis bitten |
| bezüglich | + Gen | regarding | bezüglich Ihrer Anfrage |
| kurzfristig | adj | at short notice | kurzfristig absagen |
| umgehend | adv | immediately (formal) | Ich melde mich umgehend. |
| nach\|holen | Akk | make up for, catch up on | die Arbeit nachholen |
| sich erkundigen | nach + Dat | enquire about | sich nach dem Termin erkundigen |
| erledigen | Akk | deal with, complete | eine Aufgabe erledigen |
| die Unterlagen | Pl. | documents | die Unterlagen schicken |
| der / die Vorgesetzte | adj. noun | superior, boss | meine Vorgesetzte |

## W09 · Verben mit Präpositionen I: Akkusativ (day 9)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| achten | auf + Akk | pay attention to | auf die Gesundheit achten |
| sich verlassen | auf + Akk | rely on | sich auf Kollegen verlassen |
| sich konzentrieren | auf + Akk | concentrate on | sich auf die Arbeit konzentrieren |
| sich vor\|bereiten | auf + Akk | prepare for | sich auf die Prüfung vorbereiten |
| sich beziehen | auf + Akk (bezog, bezogen) | refer to | Ich beziehe mich auf Ihre E-Mail. |
| verzichten | auf + Akk | do without | auf das Auto verzichten |
| hin\|weisen | auf + Akk (wies hin, hingewiesen) | point out | darauf hinweisen, dass … |
| reagieren | auf + Akk | react to | auf Kritik reagieren |
| sich freuen | auf / über + Akk | look forward to / be glad about | sich auf die Ferien freuen |
| sich ein\|setzen | für + Akk | campaign for | sich für den Umweltschutz einsetzen |
| sich engagieren | für + Akk | be committed to | sich für Flüchtlinge engagieren |
| sorgen | für + Akk | ensure, provide | für Sicherheit sorgen |
| sich bewerben | um + Akk (bewarb, beworben) | apply for | sich um eine Stelle bewerben |
| sich bemühen | um + Akk | strive for | sich um eine Lösung bemühen |
| es geht | um + Akk | it is about | Es geht um die Zukunft. |
| kämpfen | für / gegen + Akk | fight for / against | für mehr Rechte kämpfen |
| protestieren | gegen + Akk | protest against | gegen das Gesetz protestieren |
| sich wehren | gegen + Akk | resist | sich gegen Vorurteile wehren |
| diskutieren | über + Akk | discuss | über ein Thema diskutieren |
| nach\|denken | über + Akk (dachte nach, nachgedacht) | think about | über eine Frage nachdenken |
| sich informieren | über + Akk | find out about | sich über Kurse informieren |
| verfügen | über + Akk | have at one's disposal | über Erfahrung verfügen |
| klagen | über + Akk | complain about | über Stress klagen |
| sich wenden | an + Akk (wandte, gewandt) | turn to, contact | sich an die Chefin wenden |

## W10 · Verben mit Präpositionen II: Dativ (day 10)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| ab\|hängen | von + Dat (hing ab, abgehangen) | depend on | Das hängt vom Wetter ab. |
| aus\|gehen | von + Dat (ist ausgegangen) | assume | Ich gehe davon aus, dass … |
| profitieren | von + Dat | benefit from | von der Erfahrung profitieren |
| überzeugt sein | von + Dat | be convinced of | Ich bin davon überzeugt, dass … |
| ab\|raten | von + Dat (riet ab, abgeraten) | advise against | jdm. von einem Kauf abraten |
| sich unterscheiden | von + Dat (unterschied, unterschieden) | differ from | sich deutlich unterscheiden |
| gehören | zu + Dat | be part of | Das gehört zum Alltag. |
| neigen | zu + Dat | tend to | zu Übertreibungen neigen |
| auf\|fordern | zu + Dat | call on | zum Handeln auffordern |
| teil\|nehmen | an + Dat | take part in | an der Diskussion teilnehmen |
| leiden | an / unter + Dat (litt, gelitten) | suffer from | unter Stress leiden |
| zweifeln | an + Dat | doubt | an der Wirkung zweifeln |
| es mangelt | an + Dat | there is a lack of | Es mangelt an Fachkräften. |
| sich beteiligen | an + Dat | participate in | sich an den Kosten beteiligen |
| liegen | an + Dat (lag, gelegen) | be due to | Das liegt daran, dass … |
| warnen | vor + Dat | warn against | vor den Folgen warnen |
| Angst haben | vor + Dat | be afraid of | Angst vor Prüfungen haben |
| sich erkundigen | nach + Dat | enquire about | sich nach dem Preis erkundigen |
| sich beschäftigen | mit + Dat | deal with, be busy with | sich mit einem Thema beschäftigen |
| rechnen | mit + Dat | expect | mit Verspätungen rechnen |
| um\|gehen | mit + Dat (ging um, ist umgegangen) | handle | mit Stress umgehen |
| helfen | bei + Dat | help with | beim Umzug helfen |
| sich bedanken | bei + Dat, für + Akk | thank | sich bei Ihnen für die Hilfe bedanken |
| bestehen | auf + Dat | insist on | auf einer Antwort bestehen |

## W11 · Nomen-Verb-Verbindungen II: Handeln und Entscheiden (day 11)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| eine Entscheidung treffen | – | make a decision | eine wichtige Entscheidung treffen |
| eine Wahl treffen | – | make a choice | die richtige Wahl treffen |
| Maßnahmen ergreifen | gegen + Akk | take measures | Maßnahmen gegen den Lärm ergreifen |
| Verantwortung übernehmen | für + Akk | take responsibility | Verantwortung für den Fehler übernehmen |
| Verantwortung tragen | für + Akk | bear responsibility | Die Eltern tragen die Verantwortung. |
| einen Beitrag leisten | zu + Dat | make a contribution | einen Beitrag zum Klimaschutz leisten |
| in Kauf nehmen | Akk | accept (a downside) | längere Fahrzeiten in Kauf nehmen |
| Rücksicht nehmen | auf + Akk | show consideration | auf ältere Menschen Rücksicht nehmen |
| Einfluss nehmen / ausüben | auf + Akk | exert influence | Einfluss auf die Politik nehmen |
| zur Folge haben | dass | result in | Das hat zur Folge, dass … |
| eine Lösung finden | für + Akk | find a solution | eine Lösung für das Problem finden |
| Wert legen | auf + Akk | attach importance to | Wert auf Qualität legen |
| in Anspruch nehmen | Akk | make use of; take up | Das nimmt viel Zeit in Anspruch. |
| Anspruch haben | auf + Akk | be entitled to | Anspruch auf Urlaub haben |
| sich Mühe geben | – | make an effort | Ich gebe mir viel Mühe. |
| in Gefahr bringen | Akk | endanger | die Gesundheit in Gefahr bringen |
| unter Druck setzen / stehen | – | put / be under pressure | Viele stehen unter Druck. |
| die Initiative ergreifen | – | take the initiative | in der Diskussion die Initiative ergreifen |

## W12 · Nomen-Verb-Verbindungen III: Beruf und Kommunikation (day 12)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| zur Verfügung stehen | jdm. | be available | Für Rückfragen stehe ich Ihnen gern zur Verfügung. |
| zur Verfügung stellen | jdm. etw. | make available | Die Firma stellt Laptops zur Verfügung. |
| Bescheid geben / sagen | jdm. | let someone know | Geben Sie mir bitte Bescheid. |
| einen Termin vereinbaren | mit + Dat | arrange an appointment | einen Termin mit dem Kunden vereinbaren |
| einen Antrag stellen | auf + Akk | apply formally | einen Antrag auf Elternzeit stellen |
| einen Vorschlag machen / unterbreiten | – | make a proposal | Ich möchte Ihnen einen Vorschlag machen. |
| eine Vereinbarung treffen | mit + Dat | make an agreement | eine Vereinbarung mit dem Team treffen |
| Kontakt aufnehmen | zu / mit + Dat | get in touch | Kontakt zu einem Kunden aufnehmen |
| in Verbindung stehen | mit + Dat | be in contact | mit der Firma in Verbindung stehen |
| zur Kenntnis nehmen | Akk | take note of | Ich habe Ihre Nachricht zur Kenntnis genommen. |
| Erfahrungen sammeln | – | gain experience | im Ausland Erfahrungen sammeln |
| einen Kurs belegen | – | enrol in a course | einen Deutschkurs belegen |
| eine Prüfung ablegen / bestehen | – | take / pass an exam | die B2-Prüfung ablegen |
| einen Vortrag halten | – | give a talk | einen Vortrag über … halten |
| Vorbereitungen treffen | für + Akk | make preparations | Vorbereitungen für das Fest treffen |
| in Kraft treten | – | come into force | Das Gesetz tritt 2027 in Kraft. |
| einen Fehler begehen | – | commit an error (formal) | einen schweren Fehler begehen |
| Gebrauch machen | von + Dat | make use of | von einem Angebot Gebrauch machen |

## W13 · Arbeit und Beruf I (day 13)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| der Arbeitnehmer / die Arbeitnehmerin | - / -nen | employee | die Rechte der Arbeitnehmer |
| der Arbeitgeber | - | employer | ein attraktiver Arbeitgeber |
| die Beschäftigten | Pl. (adj. noun) | employees | alle Beschäftigten |
| die Arbeitsbedingungen | Pl. | working conditions | bessere Arbeitsbedingungen |
| die Teilzeit / die Vollzeit | – | part-time / full-time | in Teilzeit arbeiten |
| die Gleitzeit | – | flexitime | Gleitzeit haben |
| das Homeoffice | – | working from home | im Homeoffice arbeiten |
| die Vereinbarkeit | – | compatibility | die Vereinbarkeit von Familie und Beruf |
| die Überstunde | -n | hour of overtime | Überstunden machen |
| die Stelle | -n | job, position | eine Stelle suchen |
| die Bewerbung | -en | application | eine Bewerbung schreiben |
| das Vorstellungsgespräch | -e | job interview | zum Vorstellungsgespräch eingeladen werden |
| die Qualifikation | -en | qualification | die nötigen Qualifikationen |
| die Fachkraft | Fachkräfte | skilled worker | Fachkräfte aus dem Ausland |
| der Fachkräftemangel | – | shortage of skilled workers | Es herrscht Fachkräftemangel. |
| das Gehalt | Gehälter | salary | ein gutes Gehalt |
| der Lohn | Löhne | wage | der Mindestlohn |
| die Gehaltserhöhung | -en | pay rise | um eine Gehaltserhöhung bitten |
| die Karriere | -n | career | Karriere machen |
| der Aufstieg | -e | promotion, rise | beruflicher Aufstieg |
| die Probezeit | -en | probation period | in der Probezeit |
| befristet / unbefristet | adj | fixed-term / permanent | ein unbefristeter Vertrag |
| selbstständig | adj | self-employed; independent | sich selbstständig machen |
| die Belastung | -en | strain, burden | eine hohe Belastung |
| die Kündigung | -en | dismissal; resignation | die Kündigung einreichen |

## W14 · Arbeit und Beruf II (day 14)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Leistung | -en | performance, achievement | gute Leistungen bringen |
| die Produktivität | – | productivity | die Produktivität steigern |
| die Motivation | – | motivation | die Motivation der Mitarbeiter |
| der Leistungsdruck | – | pressure to perform | unter Leistungsdruck stehen |
| die Weiterbildung / die Fortbildung | -en | further training | eine Weiterbildung machen |
| die Digitalisierung | – | digitalisation | die Digitalisierung der Arbeitswelt |
| die Arbeitslosigkeit | – | unemployment | die Arbeitslosigkeit sinkt |
| der Arbeitsplatz | Arbeitsplätze | job; workplace | Arbeitsplätze schaffen |
| die Branche | -n | industry, sector | in der IT-Branche |
| das Unternehmen | - | company | ein mittelständisches Unternehmen |
| die Abteilung | -en | department | die Personalabteilung |
| die Gewerkschaft | -en | trade union | Mitglied einer Gewerkschaft |
| der Kollege / die Kollegin | -n / -nen (n-Dekl.) | colleague | mit meinem Kollegen |
| die Teamarbeit | – | teamwork | Teamarbeit ist wichtig. |
| die Führungskraft | Führungskräfte | manager | Führungskräfte in Teilzeit |
| ein\|arbeiten | jdn. | train in (a new colleague) | einen neuen Kollegen einarbeiten |
| kündigen | Dat / Akk | resign; dismiss | Sie hat gekündigt. |
| pendeln | ist gependelt | commute | jeden Tag in die Stadt pendeln |
| die Work-Life-Balance | – | work-life balance | eine gute Work-Life-Balance |
| der Feierabend | -e | end of the working day | nach Feierabend |
| die Erschöpfung | – | exhaustion | völlige Erschöpfung |
| die Auszeit | -en | break, time out | eine Auszeit nehmen |

## W15 · Umwelt und Klima I (day 15)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| der Klimawandel | – | climate change | den Klimawandel bekämpfen |
| die Erderwärmung | – | global warming | die Erderwärmung begrenzen |
| der Umweltschutz | – | environmental protection | etwas für den Umweltschutz tun |
| die Nachhaltigkeit | – | sustainability | Nachhaltigkeit im Alltag |
| der CO₂-Ausstoß | – | CO₂ emissions | den CO₂-Ausstoß senken |
| die Emission | -en | emission | Emissionen reduzieren |
| das Treibhausgas | -e | greenhouse gas | Treibhausgase verursachen |
| die erneuerbaren Energien | Pl. | renewable energies | auf erneuerbare Energien setzen |
| die Energiewende | – | energy transition | die Energiewende vorantreiben |
| der Energieverbrauch | – | energy consumption | den Energieverbrauch senken |
| die Ressource | -n | resource | Ressourcen schonen |
| der Abfall | Abfälle | waste | Abfälle trennen |
| der Müll | – | rubbish | Müll vermeiden |
| die Mülltrennung | – | waste separation | Mülltrennung zu Hause |
| die Verpackung | -en | packaging | unnötige Verpackungen |
| das Mikroplastik | – | microplastics | Mikroplastik im Meer |
| die Verschmutzung | -en | pollution | die Verschmutzung der Luft |
| der Verzicht | auf + Akk | doing without | der Verzicht auf das Auto |
| der ökologische Fußabdruck | – | ecological footprint | den ökologischen Fußabdruck verkleinern |
| umweltbewusst | adj | environmentally aware | umweltbewusst leben |
| klimaneutral | adj | climate-neutral | bis 2045 klimaneutral |
| schonen | Akk | spare, protect | die Umwelt schonen |
| belasten | Akk | burden, pollute | die Umwelt belasten |
| vermeiden | Akk (vermied, vermieden) | avoid | Plastik vermeiden |

## W16 · Umwelt und Klima II (day 16)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Ökosystem | -e | ecosystem | empfindliche Ökosysteme |
| die Artenvielfalt | – | biodiversity | die Artenvielfalt schützen |
| aus\|sterben | ist ausgestorben | die out | vom Aussterben bedroht |
| der Lebensraum | Lebensräume | habitat | Lebensräume zerstören |
| die Dürre | -n | drought | lange Dürren |
| die Überschwemmung | -en | flood | schwere Überschwemmungen |
| das Unwetter | - | severe weather | ein heftiges Unwetter |
| der Meeresspiegel | – | sea level | der Meeresspiegel steigt |
| die Meeresverschmutzung | – | ocean pollution | Plastik und Meeresverschmutzung |
| die Überfischung | – | overfishing | die Überfischung der Meere |
| die Versauerung | – | acidification | die Versauerung der Ozeane |
| das Korallenriff | -e | coral reef | bedrohte Korallenriffe |
| die Naturkatastrophe | -n | natural disaster | nach einer Naturkatastrophe |
| die Wegwerfgesellschaft | – | throwaway society | in einer Wegwerfgesellschaft |
| recyceln | Akk | recycle | Flaschen recyceln |
| die Mehrwegflasche / die Einwegflasche | -n | reusable / single-use bottle | Mehrwegflaschen nutzen |
| verschwenden | Akk | waste | Energie verschwenden |
| die Verschwendung | – | waste | Verschwendung von Lebensmitteln |
| der Schadstoff | -e | pollutant | weniger Schadstoffe |
| schädlich | für + Akk | harmful to | schädlich für die Umwelt |
| begrenzen | Akk | limit | die Erderwärmung begrenzen |
| der Naturschutz | – | nature conservation | sich für den Naturschutz einsetzen |

## W17 · Verkehr und Mobilität (day 17)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Mobilität | – | mobility | Mobilität in der Stadt |
| die öffentlichen Verkehrsmittel | Pl. | public transport | mit öffentlichen Verkehrsmitteln fahren |
| der Nahverkehr | – | local transport | der öffentliche Nahverkehr (ÖPNV) |
| das Verkehrsmittel | - | means of transport | ein umweltfreundliches Verkehrsmittel |
| das Verkehrsaufkommen | – | volume of traffic | ein hohes Verkehrsaufkommen |
| der Stau | -s | traffic jam | im Stau stehen |
| die Fußgängerzone | -n | pedestrian zone | eine neue Fußgängerzone |
| der Radweg | -e | cycle path | sichere Radwege bauen |
| das Elektroauto | -s | electric car | ein Elektroauto fahren |
| der E-Roller | - | e-scooter | E-Roller ausleihen |
| das Carsharing | – | car sharing | Carsharing nutzen |
| die Fahrgemeinschaft | -en | car pool | eine Fahrgemeinschaft bilden |
| der Pendler / die Pendlerin | - / -nen | commuter | Millionen Pendler |
| die Infrastruktur | -en | infrastructure | die Infrastruktur ausbauen |
| das Tempolimit | -s | speed limit | ein Tempolimit auf Autobahnen |
| der Lärm | – | noise | Lärm und Abgase |
| die Abgase | Pl. | exhaust fumes | weniger Abgase |
| die Anbindung | -en | connection | eine gute Anbindung an die Stadt |
| die Verbindung | -en | (train) connection | eine direkte Verbindung |
| die Parkgebühr | -en | parking fee | die Parkgebühren erhöhen |
| um\|steigen | auf + Akk (ist umgestiegen) | switch to | aufs Fahrrad umsteigen |
| entlasten | Akk | relieve (ent- + Last) | die Straßen entlasten |
| aus\|bauen | Akk | expand | das Radnetz ausbauen |
| erreichbar | adj | reachable | gut mit dem Bus erreichbar |

## W18 · Bildung und Lernen I (day 18)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Bildungssystem | -e | education system | das deutsche Bildungssystem |
| die Chancengleichheit | – | equal opportunities | Chancengleichheit für alle Kinder |
| die Schulpflicht | – | compulsory schooling | Es gibt eine Schulpflicht. |
| die Ganztagsschule | -n | all-day school | eine Ganztagsschule besuchen |
| die Lehrkraft | Lehrkräfte | teacher | fehlende Lehrkräfte |
| der Unterricht | – | lessons | im Unterricht |
| die Note | -n | grade | gute Noten bekommen |
| das Zeugnis | -se | report; certificate | ein gutes Zeugnis |
| der Abschluss | Abschlüsse | degree, qualification | einen Abschluss machen |
| das Studium | Studien | studies | das Studium finanzieren |
| die Studiengebühren | Pl. | tuition fees | Studiengebühren abschaffen |
| die Hochschule | -n | university, college | an einer Hochschule studieren |
| die Ausbildung | -en | vocational training | eine Ausbildung zum Koch |
| das Fernstudium | Fernstudien | distance learning | ein Fernstudium beginnen |
| die Volkshochschule | -n | adult education centre (VHS) | ein Kurs an der Volkshochschule |
| das lebenslange Lernen | – | lifelong learning | Lebenslanges Lernen ist heute normal. |
| die Lernplattform | -en | learning platform | Aufgaben auf der Lernplattform |
| der Präsenzunterricht | – | face-to-face teaching | Präsenzunterricht statt online |
| die Nachhilfe | – | private tutoring | Nachhilfe geben |
| das Stipendium | Stipendien | scholarship | ein Stipendium bekommen |
| benachteiligt | adj | disadvantaged | benachteiligte Kinder |
| fördern | Akk | support, foster | Talente fördern |
| vermitteln | Akk | impart; arrange | Wissen vermitteln |
| sich an\|eignen | Akk (Dat reflexive) | acquire | sich neue Kenntnisse aneignen |

## W19 · Bildung und Lernen II (day 19)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Kenntnisse | Pl. | knowledge | gute Deutschkenntnisse |
| die Fähigkeit | -en | ability | die Fähigkeit, im Team zu arbeiten |
| die Fertigkeit | -en | skill | praktische Fertigkeiten |
| die Kompetenz | -en | competence | soziale Kompetenz |
| die Medienkompetenz | – | media literacy | Medienkompetenz fördern |
| die Selbstständigkeit | – | independence | die Selbstständigkeit der Kinder |
| die Leistungsbereitschaft | – | willingness to perform | eine hohe Leistungsbereitschaft |
| der Lernerfolg | -e | learning success | schnelle Lernerfolge |
| die Prüfungsangst | Prüfungsängste | exam anxiety | unter Prüfungsangst leiden |
| die Bewertung | -en | evaluation, grading | eine faire Bewertung |
| beurteilen | Akk | assess, judge | Lehrer beurteilen |
| die Schuluniform | -en | school uniform | Schuluniformen einführen |
| der Bildungsweg | -e | educational path | der zweite Bildungsweg |
| der Quereinsteiger / die Quereinsteigerin | - / -nen | career changer | als Quereinsteiger in die IT |
| sich weiter\|bilden | – | continue one's education | sich beruflich weiterbilden |
| sich um\|schulen lassen | – | retrain | sich zum Programmierer umschulen lassen |
| die Umschulung | -en | retraining | eine Umschulung machen |
| nach\|lernen | Akk | catch up on (lessons) | den Stoff nachlernen |
| auswendig lernen | Akk | learn by heart | Vokabeln auswendig lernen |
| begabt | adj | gifted | ein begabtes Kind |

## W20 · Digitalisierung und Medien I (day 20)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die künstliche Intelligenz (KI) | – | artificial intelligence | KI im Alltag |
| die Technologie | -n | technology | neue Technologien |
| der technische Fortschritt | – | technological progress | Der technische Fortschritt ist schnell. |
| das Gerät / das Endgerät | -e | device | mobile Endgeräte |
| die Anwendung | -en | application | eine nützliche Anwendung |
| die sozialen Netzwerke / Medien | Pl. | social networks / media | in den sozialen Medien |
| der Nutzer / die Nutzerin | - / -nen | user | Millionen Nutzer |
| die Bildschirmzeit | – | screen time | die Bildschirmzeit begrenzen |
| die Erreichbarkeit | – | being reachable | ständige Erreichbarkeit |
| die Privatsphäre | – | privacy | die Privatsphäre schützen |
| der Datenschutz | – | data protection | Probleme mit dem Datenschutz |
| die Daten | Pl. | data | persönliche Daten |
| die Falschmeldung | -en | false report | Falschmeldungen erkennen |
| die Abhängigkeit | -en, von + Dat | dependence | die Abhängigkeit vom Handy |
| die Sucht | Süchte | addiction | die Handysucht |
| süchtig | nach + Dat | addicted to | süchtig nach Spielen |
| die Werbung | – | advertising | personalisierte Werbung |
| der Algorithmus | Algorithmen | algorithm | Algorithmen entscheiden mit. |
| herunter\|laden | Akk | download | eine App herunterladen |
| teilen | Akk | share | Fotos teilen |
| vernetzt | adj | connected | weltweit vernetzt |
| allgegenwärtig | adj | omnipresent | Smartphones sind allgegenwärtig. |
| manipulieren | Akk | manipulate | Meinungen manipulieren |
| automatisieren | Akk | automate | Arbeitsprozesse automatisieren |

## W21 · Digitalisierung und Medien II (day 21)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Cybermobbing | – | cyberbullying | Opfer von Cybermobbing |
| die Informationsflut | – | flood of information | die tägliche Informationsflut |
| die Reizüberflutung | – (C1) | sensory overload | Reizüberflutung im Alltag |
| die Quelle | -n | source | eine zuverlässige Quelle |
| zuverlässig | adj | reliable | zuverlässige Informationen |
| seriös | adj | reputable | eine seriöse Zeitung |
| recherchieren | Akk | research | im Internet recherchieren |
| die Nachricht | -en | news; message | die Nachrichten sehen |
| die Schlagzeile | -n | headline | in den Schlagzeilen |
| die Mediennutzung | – | media use | die Mediennutzung von Kindern |
| der Influencer / die Influencerin | - / -nen | influencer | Influencer machen Werbung. |
| die Plattform | -en | platform | eine digitale Plattform |
| das Videotelefonat | -e | video call | ein Videotelefonat mit der Familie |
| der Messenger | - | messaging app | über einen Messenger schreiben |
| die Online-Bewertung | -en | online review | Online-Bewertungen lesen |
| das Passwort | Passwörter | password | ein sicheres Passwort |
| der Hackerangriff | -e | hacker attack | Opfer eines Hackerangriffs |
| die Sicherheitslücke | -n | security gap | eine Sicherheitslücke schließen |
| überwachen | Akk | monitor, watch over | Kinder online überwachen |
| digital | adj | digital | digitale Medien |

## W22 · Gesundheit und Ernährung I (day 22)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Ernährung | – | diet, nutrition | eine gesunde Ernährung |
| sich ernähren | von + Dat | eat, live on | sich vegetarisch ernähren |
| ausgewogen | adj | balanced | ausgewogen essen |
| der Fleischkonsum | – | meat consumption | den Fleischkonsum reduzieren |
| vegetarisch / vegan | adj | vegetarian / vegan | vegane Gerichte |
| die Massentierhaltung | – | factory farming | gegen Massentierhaltung |
| das Tierwohl | – | animal welfare | mehr Tierwohl |
| regional / saisonal | adj | regional / seasonal | regionale Produkte |
| das Bioprodukt | -e | organic product | Bioprodukte kaufen |
| das Fertiggericht | -e | ready meal | zu viele Fertiggerichte |
| das Fast Food | – | fast food | ungesundes Fast Food |
| das Übergewicht | – | overweight | Übergewicht bei Kindern |
| der Bewegungsmangel | – | lack of exercise | Bewegungsmangel im Büro |
| die Bewegung | – | exercise, movement | mehr Bewegung im Alltag |
| vor\|beugen | + Dat | prevent | Krankheiten vorbeugen |
| die Vorbeugung | – | prevention | Vorbeugung ist besser als Heilung. |
| das Wohlbefinden | – | well-being | das körperliche Wohlbefinden |
| die Lebensqualität | – | quality of life | mehr Lebensqualität |
| die Lebenserwartung | – | life expectancy | Die Lebenserwartung steigt. |
| die Inhaltsstoffe | Pl. | ingredients | auf die Inhaltsstoffe achten |
| der Zuckergehalt | – | sugar content | ein hoher Zuckergehalt |
| die Lebensmittelverschwendung | – | food waste | Lebensmittelverschwendung vermeiden |
| das Mindesthaltbarkeitsdatum | -daten | best-before date | Das Mindesthaltbarkeitsdatum ist abgelaufen. |
| der Ersatz | – | substitute | Fleischersatz aus Soja |

## W23 · Gesundheit und Ernährung II (day 23)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Gesundheitssystem | -e | health system | das deutsche Gesundheitssystem |
| die Krankenversicherung | -en | health insurance | die gesetzliche Krankenversicherung |
| die Vorsorgeuntersuchung | -en | check-up | regelmäßig zur Vorsorgeuntersuchung gehen |
| die psychische Gesundheit | – | mental health | die psychische Gesundheit stärken |
| der Stress | – | stress | Stress im Beruf |
| stressbedingt | adj | stress-related | stressbedingte Krankheiten |
| die Erholung | – | rest, recovery | Zeit zur Erholung |
| sich erholen | von + Dat | recover from | sich vom Stress erholen |
| der Schlafmangel | – | lack of sleep | unter Schlafmangel leiden |
| das Burn-out | -s | burnout | ein Burn-out haben |
| der Leistungssport / der Breitensport | – | competitive / recreational sport | den Breitensport fördern |
| die Schönheitsoperation | -en | cosmetic surgery | Schönheitsoperationen bei Jugendlichen |
| das Selbstwertgefühl | – | self-esteem | ein gesundes Selbstwertgefühl |
| der Körperkult | – | body cult | der Körperkult in sozialen Medien |
| der Alkoholkonsum | – | alcohol consumption | den Alkoholkonsum reduzieren |
| schädigen | Akk | damage | die Gesundheit schädigen |
| die Nebenwirkung | -en | side effect | Nebenwirkungen haben |
| die Heilmethode | -n | healing method | alternative Heilmethoden |
| die Pflege | – | care, nursing | in der Pflege arbeiten |
| pflegebedürftig | adj | in need of care | pflegebedürftige Eltern |

## W24 · Konsum, Geld und Wirtschaft I (day 24)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| der Konsum | – | consumption | bewusster Konsum |
| konsumieren | Akk | consume | weniger konsumieren |
| der Verbraucher / die Verbraucherin | - / -nen | consumer | die Rechte der Verbraucher |
| das Konsumverhalten | – | consumer behaviour | das Konsumverhalten ändern |
| der Onlinehandel | – | online retail | der wachsende Onlinehandel |
| der Einzelhandel | – | retail | der lokale Einzelhandel |
| die Lieferung | -en | delivery | eine schnelle Lieferung |
| die Rücksendung | -en | return (of goods) | kostenlose Rücksendungen |
| das Angebot / die Nachfrage | -e / – | supply / demand | Angebot und Nachfrage |
| die Marke | -n | brand | eine teure Marke |
| die Qualität | -en | quality | auf Qualität achten |
| die Produktionsbedingungen | Pl. | production conditions | faire Produktionsbedingungen |
| der faire Handel | – | fair trade | Produkte aus fairem Handel |
| das Schnäppchen | - | bargain | ein Schnäppchen machen |
| der Rabatt | -e | discount | zehn Prozent Rabatt |
| sich leisten können | Akk (Dat reflexive) | be able to afford | sich ein Auto leisten können |
| die Ausgaben / die Einnahmen | Pl. | expenditure / income | die Ausgaben senken |
| die Lebenshaltungskosten | Pl. | cost of living | steigende Lebenshaltungskosten |
| die Inflation | – | inflation | eine hohe Inflation |
| die Miete | -n | rent | die Miete zahlen |
| bezahlbar | adj | affordable | bezahlbarer Wohnraum |
| das Bargeld | – | cash | mit Bargeld bezahlen |
| bargeldlos | adj | cashless | bargeldlos bezahlen |
| die Schulden | Pl. | debts | Schulden machen |

## W25 · Konsum, Geld und Wirtschaft II (day 25)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| der Betrieb | -e | business, company | ein kleiner Betrieb |
| der Wettbewerb | – | competition | starker Wettbewerb |
| der Gewinn / der Verlust | -e | profit / loss | Gewinn machen |
| die Globalisierung | – | globalisation | Folgen der Globalisierung |
| die Subvention | -en | subsidy | staatliche Subventionen |
| subventionieren | Akk | subsidise | die Bahn subventionieren |
| besteuern | Akk | tax | Flugreisen stärker besteuern |
| der Wohlstand | – | prosperity | Wohlstand für alle |
| die Armut | – | poverty | Armut bekämpfen |
| die Kluft | Klüfte | gap | die Kluft zwischen Arm und Reich |
| der Kaufpreis | -e | purchase price | den Kaufpreis erstatten |
| die Garantie | -n | warranty | zwei Jahre Garantie |
| reklamieren | Akk | complain about (a product) | ein defektes Gerät reklamieren |
| die Reklamation | -en | complaint | eine Reklamation bearbeiten |
| der Kundenservice | – | customer service | den Kundenservice anrufen |
| die Kaufentscheidung | -en | purchase decision | eine bewusste Kaufentscheidung |
| der Second-Hand-Laden | Second-Hand-Läden | second-hand shop | im Second-Hand-Laden einkaufen |
| reparieren | Akk | repair | Kleidung reparieren |
| die Reparatur | -en | repair | eine teure Reparatur |
| die Altersvorsorge | – | pension provision | die private Altersvorsorge |

## W26 · Gesellschaft, Familie und Wohnen I (day 26)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| das Zusammenleben | – | living together | das Zusammenleben der Generationen |
| die Generation | -en | generation | die junge Generation |
| der demografische Wandel | – | demographic change | Folgen des demografischen Wandels |
| die Einsamkeit | – | loneliness | Einsamkeit im Alter |
| der Zusammenhalt | – | cohesion | der gesellschaftliche Zusammenhalt |
| die Nachbarschaft | -en | neighbourhood | eine gute Nachbarschaft |
| die Wohngemeinschaft (WG) | -en | shared flat | in einer WG wohnen |
| das Mehrgenerationenhaus | Mehrgenerationenhäuser | multigenerational house | im Mehrgenerationenhaus leben |
| das betreute Wohnen | – | assisted living | ins betreute Wohnen ziehen |
| das Pflegeheim | -e | care home | im Pflegeheim leben |
| die Wohnungsnot | – | housing shortage | Wohnungsnot in Großstädten |
| der Wohnraum | – | living space | bezahlbarer Wohnraum |
| die Großstadt / die Kleinstadt | -städte | city / small town | in einer Großstadt leben |
| auf dem Land | – | in the countryside | aufs Land ziehen |
| die Kinderbetreuung | – | childcare | die Kinderbetreuung organisieren |
| die Kita | -s | day-care centre | einen Kitaplatz finden |
| die Elternzeit | – | parental leave | Elternzeit nehmen |
| der / die Alleinerziehende | adj. noun | single parent | Alleinerziehende unterstützen |
| die Patchworkfamilie | -n | blended family | in einer Patchworkfamilie leben |
| die Gleichberechtigung | – | equal rights | die Gleichberechtigung von Frauen und Männern |
| die Erziehung | – | upbringing | die Erziehung der Kinder |
| erziehen | Akk (erzog, erzogen) | bring up | Kinder erziehen |
| das Vorbild | -er | role model | ein gutes Vorbild sein |
| der Generationenkonflikt | -e | generation conflict | ein typischer Generationenkonflikt |

## W27 · Gesellschaft, Familie und Wohnen II (day 27)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Integration | – | integration | die Integration von Zuwanderern |
| sich integrieren | in + Akk | integrate | sich in die Gesellschaft integrieren |
| die Zuwanderung | – | immigration | die Zuwanderung von Fachkräften |
| die Vielfalt | – | diversity | kulturelle Vielfalt |
| die Toleranz | – | tolerance | Toleranz zeigen |
| das Vorurteil | -e | prejudice | Vorurteile abbauen |
| die Diskriminierung | -en | discrimination | gegen Diskriminierung kämpfen |
| das Ehrenamt | Ehrenämter | volunteer work | ein Ehrenamt übernehmen |
| ehrenamtlich | adj | voluntary | ehrenamtlich arbeiten |
| sich engagieren | für + Akk | get involved | sich für andere engagieren |
| das Engagement | – | commitment | soziales Engagement |
| der Freiwilligendienst | -e | voluntary service | ein Freiwilligendienst im Ausland |
| das Pflichtjahr | -e | compulsory year | ein soziales Pflichtjahr |
| die Gemeinschaft | -en | community | in der Gemeinschaft |
| die Solidarität | – | solidarity | Solidarität mit Schwächeren |
| die Nachbarschaftshilfe | – | neighbourly help | Nachbarschaftshilfe organisieren |
| der Lebensstil | -e | lifestyle | ein gesunder Lebensstil |
| die Anonymität | – | anonymity | die Anonymität der Großstadt |
| der Rentner / die Rentnerin | - / -nen | pensioner | Rentner in einer WG |
| die Rente | -n | pension | in Rente gehen |

## W28 · Freizeit, Reisen und Kultur (day 29)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| die Freizeitgestaltung | – | leisure activities | eine sinnvolle Freizeitgestaltung |
| der Ausgleich | – | balance, compensation | als Ausgleich zum Beruf |
| sich entspannen | – | relax | beim Lesen entspannen |
| die Entspannung | – | relaxation | zur Entspannung |
| der Verein | -e | club | in einem Verein Sport treiben |
| die Mitgliedschaft | -en | membership | die Mitgliedschaft im Fitnessstudio |
| der Tourismus | – | tourism | sanfter Tourismus |
| der Massentourismus | – | mass tourism | die Folgen des Massentourismus |
| die Pauschalreise | -n | package holiday | eine Pauschalreise buchen |
| die Individualreise | -n | independent travel | eine Individualreise planen |
| die Kreuzfahrt | -en | cruise | eine Kreuzfahrt machen |
| die Unterkunft | Unterkünfte | accommodation | eine günstige Unterkunft |
| das Reiseziel | -e | destination | beliebte Reiseziele |
| die Sehenswürdigkeit | -en | sight | Sehenswürdigkeiten besichtigen |
| das Erlebnis | -se | experience (event) | ein unvergessliches Erlebnis |
| die Abwechslung | – | variety, change | zur Abwechslung |
| den Horizont erweitern | – | broaden one's horizons | Reisen erweitert den Horizont. |
| die Gastfreundschaft | – | hospitality | die Gastfreundschaft der Menschen |
| der Brauch | Bräuche | custom | alte Bräuche |
| die Tradition | -en | tradition | eine lange Tradition |
| die Veranstaltung | -en | event | eine kulturelle Veranstaltung |
| erholsam | adj | restful | ein erholsamer Urlaub |
| bereichernd | adj | enriching | eine bereichernde Erfahrung |
| das Abenteuer | - | adventure | ein echtes Abenteuer |

## W29 · Staat, Regeln und Politik (day 30)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| staatlich | adj | state, public | staatliche Förderung |
| das Verbot | -e | ban | ein Verbot einführen |
| die Pflicht | -en | obligation | eine Pflicht für alle |
| verpflichtend | adj | compulsory | ein verpflichtender Kurs |
| die Vorschrift | -en | regulation | strenge Vorschriften |
| ein\|führen | Akk | introduce | eine neue Steuer einführen |
| die Einführung | -en | introduction | die Einführung der Vier-Tage-Woche |
| ab\|schaffen | Akk | abolish | Noten abschaffen |
| die Abschaffung | -en | abolition | die Abschaffung des Bargelds |
| die Strafe | -n | punishment, fine | eine hohe Strafe |
| bestrafen | Akk | punish | Verstöße bestrafen |
| die Freiheit | -en | freedom | die persönliche Freiheit |
| die Selbstbestimmung | – | self-determination | das Recht auf Selbstbestimmung |
| die Gerechtigkeit | – | justice, fairness | soziale Gerechtigkeit |
| gerecht / ungerecht | adj | fair / unfair | eine gerechte Lösung |
| der Bürger / die Bürgerin | - / -nen | citizen | die Bürger entscheiden |
| die Behörde | -n | authority | die zuständige Behörde |
| die Kontrolle | -n | control, check | strenge Kontrollen |
| die Umsetzung | -en | implementation | Die Umsetzung ist schwierig. |
| um\|setzen | Akk | implement | einen Plan umsetzen |
| die Öffentlichkeit | – | the public | in der Öffentlichkeit |
| die Wahl | -en | election; choice | bei der nächsten Wahl |
| das Wahlrecht | – | right to vote | das Wahlrecht ab 16 |
| die Mehrheit / die Minderheit | -en | majority / minority | die Mehrheit der Menschen |

## W30 · Präpositionen mit Genitiv und Nominalstil (day 31)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| aufgrund | + Gen | due to | aufgrund der hohen Kosten |
| wegen | + Gen | because of | wegen des Wetters |
| trotz | + Gen | despite | trotz der Nachteile |
| während | + Gen | during | während der Arbeit |
| innerhalb | + Gen | within | innerhalb eines Jahres |
| außerhalb | + Gen | outside | außerhalb der Stadt |
| statt / anstelle | + Gen | instead of | statt eines Autos |
| infolge | + Gen | as a result of | infolge des Klimawandels |
| bezüglich | + Gen | regarding | bezüglich Ihres Angebots |
| mithilfe | + Gen | with the help of | mithilfe neuer Technologien |
| angesichts | + Gen (C1) | in view of | angesichts der steigenden Preise |
| hinsichtlich | + Gen (C1) | with regard to | hinsichtlich der Kosten |
| zugunsten | + Gen (C1) | in favour of | zugunsten der Umwelt |
| die Nutzung | -en | use | die Nutzung des Autos |
| die Einschränkung | -en | restriction | ohne Einschränkungen |
| die Verbesserung | -en | improvement | eine deutliche Verbesserung |
| die Erhöhung | -en | increase | die Erhöhung der Preise |
| die Verringerung | -en | reduction | die Verringerung des Verkehrs |
| die Vermeidung | – | avoidance | die Vermeidung von Müll |
| die Förderung | -en | promotion, funding | die Förderung erneuerbarer Energien |

## W31 · Gesprächswörter für Sprechen (day 32)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| ergänzen | Akk | add, complement | Ich möchte noch etwas ergänzen. |
| unterbrechen | Akk (unterbrach, unterbrochen) | interrupt | Darf ich kurz unterbrechen? |
| zusammen\|fassen | Akk | summarise | Ich fasse kurz zusammen. |
| erläutern | Akk | explain in detail | Könntest du das genauer erläutern? |
| veranschaulichen | Akk (C1) | illustrate | mit einem Beispiel veranschaulichen |
| an\|sprechen | Akk | raise (a topic) | ein wichtiges Thema ansprechen |
| auf\|greifen | Akk (griff auf, aufgegriffen) | take up (a point) | Ich greife deinen Punkt auf. |
| zurück\|kommen | auf + Akk (ist zurückgekommen) | come back to | auf die Kosten zurückkommen |
| nach\|fragen | – | ask a follow-up question | Darf ich noch einmal nachfragen? |
| klar\|stellen | Akk | clarify | Ich möchte etwas klarstellen. |
| zu\|geben | Akk / dass (gab zu, zugegeben) | admit | Ich gebe zu, dass das schwierig ist. |
| ein\|räumen | dass (C1) | concede | Ich räume ein, dass … |
| sich einigen | auf + Akk | agree on | sich auf einen Kompromiss einigen |
| der Konsens | -e | consensus | einen Konsens finden |
| die Gegenseite | -n | the other side | die Argumente der Gegenseite |
| das Gegenargument | -e | counter-argument | ein starkes Gegenargument |
| das Fazit | -s | conclusion | ein Fazit ziehen |
| nachdenklich | adj | thoughtful | Das hat mich nachdenklich gemacht. |
| überzeugend | adj | convincing | ein überzeugendes Argument |
| einverstanden sein | mit + Dat | agree with | Damit bin ich einverstanden. |

## W32 · C1 touch I: Konnektoren und Präpositionen (day 33)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| dementsprechend | Pos. 1 | accordingly | Dementsprechend hoch sind die Kosten. |
| nichtsdestotrotz | Pos. 1 | nonetheless | Nichtsdestotrotz bin ich dafür. |
| zumal | verb last | especially since | Ich bin dagegen, zumal es teuer ist. |
| es sei denn | + main clause | unless | Das klappt nicht, es sei denn, wir ändern den Plan. |
| vorausgesetzt, dass | verb last | provided that | vorausgesetzt, dass alle mitmachen |
| geschweige denn | – | let alone | Ich kann kaum laufen, geschweige denn rennen. |
| im Hinblick auf | + Akk | with regard to | im Hinblick auf die Zukunft |
| in Anbetracht | + Gen | in view of | in Anbetracht der Lage |
| seitens | + Gen | on the part of | seitens der Regierung |
| ungeachtet | + Gen | regardless of | ungeachtet der Kritik |
| zulasten | + Gen | at the expense of | zulasten der Umwelt |
| mittels | + Gen | by means of | mittels einer App |
| nicht zuletzt | – | not least | nicht zuletzt wegen der Kosten |
| unter Umständen | – | possibly | Das kann unter Umständen teuer werden. |
| letzten Endes | – | in the end | Letzten Endes entscheidet jeder selbst. |
| demgegenüber | Pos. 1 | in contrast | Demgegenüber stehen hohe Kosten. |

## W33 · C1 touch II: Verben (day 34)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| ab\|wägen | Akk (wog ab, abgewogen) | weigh up | Vor- und Nachteile abwägen |
| erörtern | Akk | discuss in depth | ein Problem erörtern |
| hinterfragen | Akk | question critically | Informationen hinterfragen |
| verdeutlichen | Akk | make clear | ein Problem verdeutlichen |
| bemängeln | Akk | find fault with | die Qualität bemängeln |
| beanstanden | Akk | object to | eine Rechnung beanstanden |
| plädieren | für + Akk | argue for | für ein Verbot plädieren |
| appellieren | an + Akk | appeal to | an die Vernunft appellieren |
| sich auseinander\|setzen | mit + Dat | engage with | sich mit einem Thema auseinandersetzen |
| beeinträchtigen | Akk | impair | die Gesundheit beeinträchtigen |
| begünstigen | Akk | favour, encourage | Krankheiten begünstigen |
| erschweren / erleichtern | Akk | make harder / easier | den Alltag erleichtern |
| voran\|treiben | Akk | push forward | die Digitalisierung vorantreiben |
| mit sich bringen | Akk | entail | Das bringt Nachteile mit sich. |
| nach sich ziehen | Akk | result in | Das zieht Kosten nach sich. |
| in den Vordergrund rücken | – | come to the fore | Der Klimaschutz rückt in den Vordergrund. |
| an Bedeutung gewinnen / verlieren | – | gain / lose importance | Bargeld verliert an Bedeutung. |
| zu kurz kommen | – | be neglected | Die Freizeit kommt zu kurz. |

## W34 · C1 touch III: Nomen und Adjektive (day 36)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| der Zielkonflikt | -e | trade-off | ein Zielkonflikt zwischen Umwelt und Wirtschaft |
| die Kehrseite | -n | downside | die Kehrseite der Medaille |
| der Spagat | -e | balancing act | der Spagat zwischen Familie und Beruf |
| das Spannungsfeld | -er | area of tension | im Spannungsfeld zwischen Freiheit und Sicherheit |
| die Akzeptanz | – | acceptance | die Akzeptanz in der Bevölkerung |
| die Tragweite | – | scope, consequences | die Tragweite einer Entscheidung |
| der Stellenwert | – | importance, status | einen hohen Stellenwert haben |
| der Anreiz | -e | incentive | Anreize schaffen |
| die Rahmenbedingungen | Pl. | framework conditions | bessere Rahmenbedingungen |
| der Ansatzpunkt | -e | starting point | ein guter Ansatzpunkt |
| maßgeblich | adj | decisive, significant | maßgeblich beteiligt |
| ausschlaggebend | adj | decisive | der ausschlaggebende Grund |
| gravierend | adj | serious | gravierende Folgen |
| tiefgreifend | adj | profound | tiefgreifende Veränderungen |
| vielschichtig | adj | complex | ein vielschichtiges Problem |
| zwiespältig | adj | ambivalent | zwiespältige Gefühle |
| unabdingbar | adj | indispensable | unabdingbar für den Erfolg |
| nachweislich | adv | demonstrably | nachweislich wirksam |

## W35 · C1 touch IV: Wendungen (day 37)

| Deutsch | Grammar | English | Example |
| --- | --- | --- | --- |
| auf der Hand liegen | – | be obvious | Die Vorteile liegen auf der Hand. |
| ins Gewicht fallen | – | carry weight | Die Kosten fallen kaum ins Gewicht. |
| Abhilfe schaffen | – | remedy | Hier muss Abhilfe geschaffen werden. |
| Rechnung tragen | + Dat | take into account | den Bedürfnissen der Kunden Rechnung tragen |
| nicht von der Hand zu weisen sein | – | be undeniable | Dieses Argument ist nicht von der Hand zu weisen. |
| Hand in Hand gehen | – | go hand in hand | Bildung und Erfolg gehen Hand in Hand. |
| das A und O sein | – | be the be-all and end-all | Übung ist das A und O. |
| den Rahmen sprengen | – | go beyond the scope | Das würde den Rahmen sprengen. |
| auf den Punkt bringen | Akk | sum up precisely | Du hast es auf den Punkt gebracht. |
| Bilanz ziehen | – | take stock | nach einem Jahr Bilanz ziehen |
| Fuß fassen | – | gain a foothold | im Beruf Fuß fassen |
| unter einen Hut bringen | Akk | reconcile | Familie und Beruf unter einen Hut bringen |
| eine zentrale Rolle einnehmen | – | play a central role | Bildung nimmt eine zentrale Rolle ein. |
| zum Einsatz kommen | – | be used | KI kommt immer häufiger zum Einsatz. |
| auf Kritik stoßen | – | meet with criticism | Der Plan stößt auf Kritik. |
| Anklang finden | – | be well received | Die Idee findet großen Anklang. |
